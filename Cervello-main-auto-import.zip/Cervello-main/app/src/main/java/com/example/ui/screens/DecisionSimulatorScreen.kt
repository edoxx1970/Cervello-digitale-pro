package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.DecisionSimulationResult
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.BrainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DecisionSimulatorScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val dilemmaText by viewModel.decisionDilemma.collectAsState()
    val isSimulating by viewModel.isSimulatingDecision.collectAsState()
    val result by viewModel.decisionResult.collectAsState()
    val allMemories by viewModel.allItems.collectAsState()

    var inputDilemma by remember(dilemmaText) { mutableStateOf(dilemmaText) }

    val presetDilemmas = listOf(
        "💼 Offerta di lavoro" to "Dovrei accettare una nuova proposta di carriera che offre più compenso ma richiede trasferimento?",
        "🚀 Nuovo Progetto" to "Dovrei iniziare a sviluppare una nuova idea imprenditoriale nei fine settimana?",
        "💰 Investimento" to "Conviene investire una parte consistente dei miei risparmi in formazione avanzata?",
        "🧭 Scelta di Valori" to "Come dovrei impostare i miei confini tra lavoro e vita personale nei prossimi 6 mesi?",
        "⚡ Focus & Priorità" to "Quale tra i miei progetti correnti dovrei mettere in pausa per massimizzare il rendimento?"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Banner
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                VioletNeon.copy(alpha = 0.15f),
                                CyanNeon.copy(alpha = 0.12f),
                                BackgroundDark
                            )
                        )
                    )
                    .border(1.dp, VioletNeon.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VioletNeon.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = VioletNeon,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "SIMULATORE DI DECISIONI",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = VioletNeon,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Deliberazione Cognitiva Multi-Lobo",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    if (result != null) {
                        IconButton(
                            onClick = { viewModel.clearDecisionSimulation() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Nuova Simulazione",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Presenta un dilemma o una decisione importante. Il tuo Clone AI confronterà la scelta con gli obiettivi del Lobo Frontale, i valori del Lobo Parietale e le memorie del Lobo Temporale.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )
            }
        }

        // Input Dilemma Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "IL TUO DILEMMA DECISIONALE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputDilemma,
                    onValueChange = {
                        inputDilemma = it
                        viewModel.setDecisionDilemma(it)
                    },
                    placeholder = {
                        Text(
                            text = "Descrivi la scelta, opzioni in gioco o dubbio strategico...",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Presets Scenarios
                Text(
                    text = "Scenari Guida:",
                    fontSize = 11.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetDilemmas.forEach { (label, dilemmaText) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceCardElevated)
                                .border(1.dp, SurfaceCardBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    inputDilemma = dilemmaText
                                    viewModel.setDecisionDilemma(dilemmaText)
                                }
                                .padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Run Simulation Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (inputDilemma.isNotBlank() && !isSimulating) {
                                Brush.horizontalGradient(listOf(CyanNeon, VioletNeon))
                            } else {
                                Brush.horizontalGradient(listOf(SurfaceCardElevated, SurfaceCardElevated))
                            }
                        )
                        .clickable(enabled = inputDilemma.isNotBlank() && !isSimulating) {
                            viewModel.runDecisionSimulation(inputDilemma)
                        }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSimulating) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "Consultazione dei Lobi in corso...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (inputDilemma.isNotBlank()) Color.Black else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Simula Deliberazione Neurale",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (inputDilemma.isNotBlank()) Color.Black else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // Simulation Results View
        if (result != null) {
            val res = result!!

            // Section 1: Score & Verdict Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "VERDETTO NEURALE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMuted,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = res.verdict,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (res.alignmentScore >= 80) EmeraldNeon else if (res.alignmentScore >= 50) AmberNeon else PinkVault
                            )
                        }

                        // Alignment Percentage Gauge
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(
                                    if (res.alignmentScore >= 80) EmeraldNeon.copy(alpha = 0.15f)
                                    else if (res.alignmentScore >= 50) AmberNeon.copy(alpha = 0.15f)
                                    else PinkVault.copy(alpha = 0.15f)
                                )
                                .border(
                                    2.dp,
                                    if (res.alignmentScore >= 80) EmeraldNeon
                                    else if (res.alignmentScore >= 50) AmberNeon
                                    else PinkVault,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${res.alignmentScore}%",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (res.alignmentScore >= 80) EmeraldNeon else if (res.alignmentScore >= 50) AmberNeon else PinkVault
                                )
                                Text(
                                    text = "Allineato",
                                    fontSize = 8.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Final Recommendation Speech Bubble
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        VioletNeon.copy(alpha = 0.2f),
                                        CyanNeon.copy(alpha = 0.15f)
                                    )
                                )
                            )
                            .border(1.dp, CyanNeon.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = CyanNeon,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Raccomandazione del Tuo Clone:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanNeon
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = res.recommendation,
                                fontSize = 13.sp,
                                color = TextPrimary,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            // Section 2: Lobe-by-Lobe Cognitive Breakdown
            item {
                Text(
                    text = "DECOMPOSIZIONE PER LOBI CEREBRALI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            item {
                LobeAnalysisCard(
                    title = "Lobo Frontale • Visione & Obiettivi",
                    description = res.frontalAnalysis,
                    color = CyanNeon,
                    icon = Icons.Default.AccountTree
                )
            }

            item {
                LobeAnalysisCard(
                    title = "Lobo Parietale • Principi & Valori",
                    description = res.parietalAnalysis,
                    color = VioletNeon,
                    icon = Icons.Default.Shield
                )
            }

            item {
                LobeAnalysisCard(
                    title = "Lobo Temporale • Trascorsi & Esperienze",
                    description = res.temporalAnalysis,
                    color = AmberNeon,
                    icon = Icons.Default.HistoryEdu
                )
            }

            item {
                LobeAnalysisCard(
                    title = "Lobo Occipitale • Scenari & Impatto Visivo",
                    description = res.occipitalAnalysis,
                    color = EmeraldNeon,
                    icon = Icons.Default.Visibility
                )
            }

            // Section 3: Pros & Cons Comparison
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Pros Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCard)
                            .border(1.dp, EmeraldNeon.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldNeon,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "VANTAGGI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldNeon
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        res.pros.forEach { pro ->
                            Text(
                                text = "• $pro",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }

                    // Cons Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCard)
                            .border(1.dp, PinkVault.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = PinkVault,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "RISCHI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PinkVault
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        res.cons.forEach { con ->
                            Text(
                                text = "• $con",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Section 4: Save as Memory Action
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceCardElevated)
                        .border(1.dp, CyanNeon.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .clickable {
                            viewModel.saveDecisionAsMemory(inputDilemma, res)
                        }
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BookmarkAdd,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Archivia nel Lobo Frontale (Decisioni)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
private fun LobeAnalysisCard(
    title: String,
    description: String,
    color: Color,
    icon: ImageVector
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = description,
            fontSize = 12.5.sp,
            color = TextSecondary,
            lineHeight = 17.sp
        )
    }
}
