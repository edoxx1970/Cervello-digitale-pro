package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.BrainViewModel
import kotlinx.coroutines.launch

@Composable
fun SecuritySettingsScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val cryptoPrefs = viewModel.cryptoPrefs
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val scope = rememberCoroutineScope()

    var showChangePinDialog by remember { mutableStateOf(false) }
    var newPinInput by remember { mutableStateOf("") }
    var pinHintInput by remember { mutableStateOf("") }

    var showExportDialog by remember { mutableStateOf(false) }
    var exportedPayload by remember { mutableStateOf("") }

    var showResetDialog by remember { mutableStateOf(false) }
    var biometricEnabled by remember { mutableStateOf(cryptoPrefs.isBiometricEnabled) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Sicurezza & Crittografia E2EE",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = "Configura le chiavi di cifratura PBKDF2, i backup crittografati e l'accesso biometrico.",
                fontSize = 12.5.sp,
                color = TextSecondary
            )
        }

        // Vault Status Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(
                        1.dp,
                        if (isVaultUnlocked) EmeraldNeon.copy(alpha = 0.5f) else PinkVault.copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (isVaultUnlocked) EmeraldNeon.copy(alpha = 0.2f) else PinkVault.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isVaultUnlocked) Icons.Default.Shield else Icons.Default.Lock,
                                contentDescription = "Lock Status",
                                tint = if (isVaultUnlocked) EmeraldNeon else PinkVault,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Text(
                                text = if (isVaultUnlocked) "Caveau Neurale: Sbloccato" else "Caveau Neurale: Bloccato",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Algoritmo: AES-256-GCM + PBKDF2",
                                fontSize = 11.5.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (isVaultUnlocked) viewModel.lockVault() else viewModel.openUnlockDialog()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isVaultUnlocked) SurfaceCardElevated else PinkVault
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (isVaultUnlocked) "Blocca" else "Sblocca",
                            color = if (isVaultUnlocked) TextPrimary else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // PIN & Passphrase Master
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Key",
                            tint = CyanNeon,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "PIN Master di Crittografia",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = "Il PIN master viene utilizzato per derivare la chiave di decifrazione del Caveau. Attuale suggerimento: ${cryptoPrefs.passphraseHint}",
                        fontSize = 12.5.sp,
                        color = TextSecondary
                    )

                    Button(
                        onClick = { showChangePinDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "Modifica PIN Master", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Biometric & App Lock Settings
        item {
            var appLockEnabled by remember { mutableStateOf(cryptoPrefs.isAppLockEnabled) }
            val context = androidx.compose.ui.platform.LocalContext.current
            val bioStatus = remember { com.example.crypto.BiometricAuthManager.checkBiometricAvailability(context) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "AUTENTICAZIONE BIOMETRICA & BLOCCO APP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )

                    // Toggle App Lock on Launch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Shield",
                                tint = CyanNeon,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "Protezione Avvio 'Cervello Digitale'",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Richiedi biometria o PIN prima di accedere alle memorie o al Clone AI",
                                    fontSize = 11.5.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Switch(
                            checked = appLockEnabled,
                            onCheckedChange = {
                                appLockEnabled = it
                                cryptoPrefs.isAppLockEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanNeon,
                                checkedTrackColor = CyanNeon.copy(alpha = 0.3f)
                            )
                        )
                    }

                    // Toggle Biometric vs PIN
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Biometric",
                                tint = EmeraldNeon,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "Sensore Impronta / Riconoscimento Volto",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = when (bioStatus) {
                                        com.example.crypto.BiometricStatus.AVAILABLE -> "Hardware biometrico attivo e pronto"
                                        com.example.crypto.BiometricStatus.NOT_ENROLLED -> "Nessuna biometria configurata nel dispositivo"
                                        else -> "Sensore biometrico non rilevato (usa PIN Master)"
                                    },
                                    fontSize = 11.5.sp,
                                    color = if (bioStatus == com.example.crypto.BiometricStatus.AVAILABLE) EmeraldNeon else TextMuted
                                )
                            }
                        }

                        Switch(
                            checked = biometricEnabled,
                            onCheckedChange = {
                                biometricEnabled = it
                                cryptoPrefs.isBiometricEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = EmeraldNeon,
                                checkedTrackColor = EmeraldNeon.copy(alpha = 0.3f)
                            )
                        )
                    }

                    // Lock Immediately Button
                    Button(
                        onClick = { viewModel.lockApp() },
                        colors = ButtonDefaults.buttonColors(containerColor = PinkVault.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, PinkVault.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            tint = PinkVault,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Blocca Subito il Cervello Digitale",
                            color = PinkVault,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Encrypted Backup Export & Import
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "BACKUP & MIGRAZIONE E2EE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Text(
                        text = "Genera un payload crittografato AES-256 contenente tutte le sinapsi, foto e memorie del tuo cervello.",
                        fontSize = 12.5.sp,
                        color = TextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val backup = viewModel.repository.exportEncryptedBackup("2026")
                                    exportedPayload = backup
                                    showExportDialog = true
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Export",
                                tint = CyanNeon,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Esporta Backup", color = CyanNeon, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showResetDialog = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PinkVault.copy(alpha = 0.2f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset",
                                tint = PinkVault,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Ripristina Dati", color = PinkVault, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Change PIN Dialog
    if (showChangePinDialog) {
        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text("Nuovo PIN Master", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { newPinInput = it },
                        label = { Text("Nuovo PIN (es. 4 cifre)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceCardBorder
                        )
                    )
                    OutlinedTextField(
                        value = pinHintInput,
                        onValueChange = { pinHintInput = it },
                        label = { Text("Suggerimento Passphrase (opzionale)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceCardBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPinInput.isNotBlank()) {
                            cryptoPrefs.setMasterPin(newPinInput.trim(), pinHintInput.trim())
                            showChangePinDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon)
                ) {
                    Text("Salva", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showChangePinDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated)
                ) {
                    Text("Annulla", color = TextSecondary)
                }
            }
        )
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Backup Cifrato Generato (AES-256)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ecco la stringa crittografata del tuo cervello. Puoi copiarla o scaricarla via porta 8888:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BackgroundDark)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = exportedPayload.take(240) + "...",
                            fontSize = 11.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            color = CyanNeon
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showExportDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon)
                ) {
                    Text("Chiudi", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Reset Confirm Dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Ripristinare le Sinapsi di Default?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Questa operazione ricaricherà i nodi di esempio del clone cerebrale.", fontSize = 13.sp)
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetBrainToDefaults()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkVault)
                ) {
                    Text("Ripristina", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showResetDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated)
                ) {
                    Text("Annulla", color = TextSecondary)
                }
            }
        )
    }
}
