package com.example.data.repository

import com.example.crypto.CryptoEngine
import com.example.crypto.CryptoPreferences
import com.example.data.db.ChatDao
import com.example.data.model.EncryptedChatMessage
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ChatRepository(
    private val chatDao: ChatDao,
    private val cryptoPrefs: CryptoPreferences
) {
    private val defaultKey: String
        get() = cryptoPrefs.masterPinHash.ifEmpty { "neural_clone_e2ee_salt_key_2026" }

    // Come per le foto: deriva la chiave una sola volta invece che ad ogni
    // messaggio, altrimenti una cronologia lunga rifarebbe la PBKDF2 (ora 600.000
    // iterazioni) per ogni singolo messaggio caricato.
    private val cachedChatKey: javax.crypto.SecretKey by lazy {
        val salt = android.util.Base64.decode(cryptoPrefs.systemDataKeySaltBase64, android.util.Base64.NO_WRAP)
        CryptoEngine.deriveKey(defaultKey, salt)
    }

    fun getDecryptedChatHistory(): Flow<List<ChatMessage>> {
        return chatDao.getAllMessages().map { list ->
            list.map { entity ->
                // Prova il formato veloce; se il messaggio è stato salvato prima di
                // questo aggiornamento, ricade sul vecchio formato per non perderlo.
                val fastResult = CryptoEngine.decryptWithKey(entity.encryptedPayload, cachedChatKey)
                val decryptedText = (if (fastResult.isSuccess) fastResult else CryptoEngine.decrypt(entity.encryptedPayload, defaultKey))
                    .getOrDefault("[Messaggio Cifrato non decifrabile]")
                val senderEnum = if (entity.sender == "USER") MessageSender.USER else MessageSender.CLONE
                ChatMessage(
                    id = entity.id.toString(),
                    sender = senderEnum,
                    text = decryptedText,
                    timestamp = entity.timestamp,
                    isProtected = entity.isProtected,
                    modelUsed = entity.modelName
                )
            }
        }
    }

    suspend fun saveEncryptedMessage(
        sender: MessageSender,
        plainText: String,
        modelName: String = "gemini-3.5-flash"
    ): Long = withContext(Dispatchers.IO) {
        val ciphertext = CryptoEngine.encryptWithKey(plainText, cachedChatKey)
        val entity = EncryptedChatMessage(
            sender = if (sender == MessageSender.USER) "USER" else "CLONE",
            encryptedPayload = ciphertext,
            timestamp = System.currentTimeMillis(),
            modelName = modelName,
            isProtected = true
        )
        chatDao.insertMessage(entity)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        chatDao.deleteAllMessages()
    }

    suspend fun deleteMessage(id: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(id)
    }
}
