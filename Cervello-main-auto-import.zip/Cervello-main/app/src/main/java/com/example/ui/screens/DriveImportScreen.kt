package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.drive.DriveFileItem
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.BrainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DriveImportScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val driveAccessToken by viewModel.driveAccessToken.collectAsState()
    val driveFiles by viewModel.driveFiles.collectAsState()
    val isLoadingDriveFiles by viewModel.isLoadingDriveFiles.collectAsState()
    val isImportingDocument by viewModel.isImportingDocument.collectAsState()
    val importedPreview by viewModel.importedDocumentPreview.collectAsState()
    val importedSourceName by viewModel.importedSourceFileName.collectAsState()

    var showTokenConfigDialog by remember { mutableStateOf(false) }
    var tokenInput by remember { mutableStateOf(driveAccessToken) }

    // SAF File Picker for Local Files (PDF, TXT, MD, JSON, CSV, Docs)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importLocalFile(uri)
        }
    }

    LaunchedEffect(driveAccessToken) {
        if (driveAccessToken.isNotBlank() && driveFiles.isEmpty()) {
            viewModel.loadDriveFiles()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header: Cloud Sync & Document Import
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                CyanNeon.copy(alpha = 0.16f),
                                VioletNeon.copy(alpha = 0.12f),
                                BackgroundDark
                            )
                        )
                    )
                    .border(1.dp, CyanNeon.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(CyanNeon.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "IMPORTAZIONE CLOUD & DRIVE",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Google Drive • File SAF • Documenti & Appunti",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    // Refresh Button
                    if (driveAccessToken.isNotBlank()) {
                        IconButton(
                            onClick = { viewModel.loadDriveFiles() },
                            enabled = !isLoadingDriveFiles,
                            modifier = Modifier.size(32.dp)
                        ) {
                            if (isLoadingDriveFiles) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyanNeon, strokeWidth = 2.dp)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Ricarica Drive",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Importa i tuoi documenti, saggi, verbali o file personali: l'AI analizzerà il contenuto con Gemini, ne sintetizzerà i concetti chiave e li classificherà automaticamente nel lobo cerebrale idoneo.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )
            }
        }

        // Primary Import Action Hub (2 Big Buttons: Google Drive + Local File Storage)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Local File Picker (SAF)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCard)
                        .border(1.dp, VioletNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .clickable {
                            filePickerLauncher.launch(
                                arrayOf(
                                    "text/plain",
                                    "text/markdown",
                                    "application/json",
                                    "text/csv",
                                    "application/pdf",
                                    "*/*"
                                )
                            )
                        }
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(VioletNeon.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "Esplora File",
                                    tint = VioletNeon,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Text(
                                text = "FILE LOCALE / SAF",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VioletNeon
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "TXT, MD, JSON, Appunti dal dispositivo",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }

                // Google Drive Connection Token Config
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCard)
                        .border(1.dp, AmberNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .clickable {
                            tokenInput = driveAccessToken
                            showTokenConfigDialog = !showTokenConfigDialog
                        }
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(AmberNeon.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = "Token OAuth",
                                    tint = AmberNeon,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Text(
                                text = if (driveAccessToken.isNotBlank()) "OAUTH ATTIVO" else "CONFIG DRIVE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberNeon
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (driveAccessToken.isNotBlank()) "Token OAuth collegato • Gestisci" else "Collega token OAuth Google Drive",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Token Input Panel (Collapsible)
        if (showTokenConfigDialog || driveAccessToken.isBlank()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCardElevated)
                        .border(1.dp, AmberNeon.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = "CONNESSIONE GOOGLE DRIVE OAUTH",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberNeon,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Il setup OAuth per Google Workspace è stato abilitato. Inserisci il token di accesso o collegati con il tuo account.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it },
                        placeholder = { Text("Incolla Bearer Access Token OAuth2 (es. ya29....)", color = TextMuted, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberNeon,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = BackgroundDark,
                            unfocusedContainerColor = BackgroundDark
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(AmberNeon)
                                .clickable {
                                    viewModel.setDriveAccessToken(tokenInput.trim())
                                    if (tokenInput.isNotBlank()) {
                                        viewModel.loadDriveFiles()
                                    }
                                    showTokenConfigDialog = false
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Salva & Sincronizza Drive",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }

        // Importing In-Progress Loader
        if (isImportingDocument) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCardElevated)
                        .border(1.dp, CyanNeon, RoundedCornerShape(16.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(color = CyanNeon, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
                        Text(
                            text = "Analisi e categorizzazione neurale di '$importedSourceName' in corso con Gemini...",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }

        // Extracted Document Memory Result Preview
        if (importedPreview != null) {
            val res = importedPreview!!
            val targetLobeEnum = try {
                BrainLobe.valueOf(res.targetLobe)
            } catch (e: Exception) {
                BrainLobe.FRONTAL
            }
            val lobeColor = when (targetLobeEnum) {
                BrainLobe.FRONTAL -> CyanNeon
                BrainLobe.PARIETAL -> VioletNeon
                BrainLobe.TEMPORAL -> AmberNeon
                BrainLobe.OCCIPITAL -> EmeraldNeon
                BrainLobe.NEURAL_VAULT -> PinkVault
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SurfaceCard)
                        .border(1.5.dp, lobeColor, RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "DOCUMENTO ANALIZZATO DA GEMINI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = lobeColor,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = res.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        IconButton(
                            onClick = { viewModel.clearImportPreview() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Chiudi", tint = TextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Lobe Allocation Badge
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(lobeColor.copy(alpha = 0.2f))
                                .border(1.dp, lobeColor, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Lobo Assegnato: ${targetLobeEnum.title}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = lobeColor
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceCardElevated)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = res.category,
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Content Summary
                    Text(
                        text = res.content,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Key Insights Bullet List
                    if (res.keyInsights.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceCardElevated)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "✨ Punti Salienti & Dati Estratti:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            res.keyInsights.forEach { insight ->
                                Text(
                                    text = "• $insight",
                                    fontSize = 11.5.sp,
                                    color = TextPrimary,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(vertical = 1.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tags
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        res.tags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SurfaceCardElevated)
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "#$tag",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Commit Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.horizontalGradient(listOf(lobeColor, EmeraldNeon)))
                            .clickable {
                                viewModel.commitImportedDocumentToBrain(res)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BookmarkAdd,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Salva nel Secondo Cervello (${targetLobeEnum.title})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }

        // Google Drive Files List Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FILE GOOGLE DRIVE RECENTI (${driveFiles.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Drive Files Empty or Populated
        if (driveFiles.isEmpty() && !isLoadingDriveFiles) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(14.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (driveAccessToken.isBlank()) "Nessun token Drive configurato" else "Nessun documento trovato o aggiorna la lista",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        if (driveAccessToken.isBlank()) {
                            Text(
                                text = "Tocca 'CONFIG DRIVE' in alto per inserire il token o usa 'FILE LOCALE / SAF'",
                                fontSize = 11.sp,
                                color = AmberNeon
                            )
                        }
                    }
                }
            }
        } else {
            items(driveFiles, key = { it.id }) { file ->
                DriveFileCard(
                    file = file,
                    onImport = { viewModel.importDriveFile(file) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun DriveFileCard(
    file: DriveFileItem,
    onImport: () -> Unit
) {
    val icon = when (file.iconType) {
        "sheet" -> Icons.Default.Storage
        "pdf" -> Icons.Default.Description
        else -> Icons.Default.Description
    }

    val iconTint = when (file.iconType) {
        "sheet" -> EmeraldNeon
        "pdf" -> PinkVault
        else -> CyanNeon
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(14.dp))
            .clickable { onImport() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = file.name,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (file.modifiedTime.length > 10) "Modificato: ${file.modifiedTime.take(10)}" else file.mimeType.substringAfterLast("."),
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyanNeon.copy(alpha = 0.15f))
                    .border(1.dp, CyanNeon.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .clickable { onImport() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDownload,
                        contentDescription = null,
                        tint = CyanNeon,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Importa",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                }
            }
        }
    }
}
