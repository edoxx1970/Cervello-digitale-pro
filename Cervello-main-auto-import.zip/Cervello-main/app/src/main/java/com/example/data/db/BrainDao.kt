package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BrainItem
import kotlinx.coroutines.flow.Flow

@Dao
interface BrainDao {
    @Query("SELECT * FROM brain_items ORDER BY createdAt DESC")
    fun getAllItems(): Flow<List<BrainItem>>

    @Query("SELECT DISTINCT category FROM brain_items WHERE category IS NOT NULL AND category != '' ORDER BY category ASC")
    fun getAllCategories(): Flow<List<String>>

    @Query("SELECT * FROM brain_items WHERE category = :category ORDER BY createdAt DESC")
    fun getItemsByCategory(category: String): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE tags LIKE '%' || :tag || '%' ORDER BY createdAt DESC")
    fun getItemsByTag(tag: String): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE (:lobeType IS NULL OR lobeType = :lobeType) AND (:category IS NULL OR category = :category) AND (:tag IS NULL OR tags LIKE '%' || :tag || '%') AND (:query IS NULL OR :query = '' OR title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%') ORDER BY createdAt DESC")
    fun filterItems(lobeType: String?, category: String?, tag: String?, query: String?): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): BrainItem?

    @Query("SELECT * FROM brain_items WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchItems(query: String): Flow<List<BrainItem>>

    @Query("SELECT * FROM brain_items WHERE photoUri IS NOT NULL AND photoUri != '' ORDER BY createdAt DESC")
    fun getVisualMemories(): Flow<List<BrainItem>>

    @Query("SELECT COUNT(*) FROM brain_items")
    fun getItemsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM brain_items WHERE lobeType = :lobeType")
    fun getLobeCount(lobeType: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: BrainItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<BrainItem>)

    @Update
    suspend fun updateItem(item: BrainItem)

    @Delete
    suspend fun deleteItem(item: BrainItem)

    @Query("DELETE FROM brain_items WHERE id = :id")
    suspend fun deleteItemById(id: Long)

    @Query("DELETE FROM brain_items")
    suspend fun deleteAll()
}
