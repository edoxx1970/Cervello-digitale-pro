package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AddEditMemoryDialog
import com.example.ui.components.MemoryDetailSheet
import com.example.ui.components.SecurityMasterDialog
import com.example.ui.components.SynapticCameraDialog
import com.example.ui.components.VoiceQueryBrainDialog
import com.example.ui.components.VoiceThoughtRecorderDialog
import com.example.ui.screens.AutoIngestScreen
import com.example.ui.screens.BiometricLockScreen
import com.example.ui.screens.BrainCloneChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DecisionSimulatorScreen
import com.example.ui.screens.DriveImportScreen
import com.example.ui.screens.EncryptedGalleryScreen
import com.example.ui.screens.LobesScreen
import com.example.ui.screens.NeuralGraphScreen
import com.example.ui.screens.RemoteAccessScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.screens.SocraticInterviewScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.BrainViewModel

class MainActivity : FragmentActivity() {

    private var viewModelInstance: BrainViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val viewModel: BrainViewModel = viewModel()
                viewModelInstance = viewModel
                MainAppScreen(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModelInstance?.remoteServer?.stopServer()
    }
}

data class NavItem(
    val tab: AppNavTab,
    val label: String,
    val icon: ImageVector
)

@Composable
fun MainAppScreen(viewModel: BrainViewModel) {
    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val isAddDialogOpen by viewModel.isAddMemoryDialogOpen.collectAsState()
    val memoryToEdit by viewModel.memoryToEdit.collectAsState()
    val activeDetailItem by viewModel.activeDetailItem.collectAsState()
    val isUnlockDialogOpen by viewModel.isUnlockDialogOpen.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val isCameraOpen by viewModel.isCameraDialogOpen.collectAsState()
    val cameraTargetLobe by viewModel.cameraTargetLobe.collectAsState()
    val isVoiceOpen by viewModel.isVoiceDialogOpen.collectAsState()
    val voiceTargetLobe by viewModel.voiceTargetLobe.collectAsState()
    val isVoiceQueryOpen by viewModel.isVoiceQueryDialogOpen.collectAsState()
    val voiceQueryPrompt by viewModel.voiceQueryPrompt.collectAsState()
    val voiceQueryAiAnswer by viewModel.voiceQueryAiAnswer.collectAsState()
    val isVoiceQueryLoading by viewModel.isVoiceQueryLoading.collectAsState()
    val voiceQueryMatches by viewModel.voiceQueryMatches.collectAsState()
    val toastNotice by viewModel.toastNotice.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastNotice) {
        toastNotice?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearToastNotice()
        }
    }

    val currentUser by viewModel.currentUser.collectAsState()
    val isLoginSkipped by viewModel.isLoginSkipped.collectAsState()

    // Gate access: If App is Locked, show Biometric Authentication Screen first
    if (isAppLocked) {
        BiometricLockScreen(viewModel = viewModel)
        return
    }
    
    // Auth Check: If not logged in and not skipped, show Login Screen
    if (currentUser == null && !isLoginSkipped) {
        com.example.ui.screens.LoginScreen(
            viewModel = viewModel,
            onSkip = { viewModel.skipLogin() }
        )
        return
    }

    val navItems = listOf(
        NavItem(AppNavTab.DASHBOARD, "Cervello", Icons.Default.Psychology),
        NavItem(AppNavTab.NEURAL_GRAPH, "Sinapsi", Icons.Default.Hub),
        NavItem(AppNavTab.SOCRATIC_INTERVIEW, "Socrate", Icons.Default.QuestionAnswer),
        NavItem(AppNavTab.DRIVE_IMPORT, "Drive", Icons.Default.CloudDownload),
        NavItem(AppNavTab.DECISION_SIMULATOR, "Decisioni", Icons.Default.AccountTree),
        NavItem(AppNavTab.LOBES, "Lobi", Icons.Default.ViewModule),
        NavItem(AppNavTab.CHAT, "Clone AI", Icons.Default.AutoAwesome),
        NavItem(AppNavTab.GALLERY, "Galleria", Icons.Default.PhotoLibrary),
        NavItem(AppNavTab.REMOTE_PORTAL, "Ponte", Icons.Default.Public),
        NavItem(AppNavTab.AUTO_IMPORT, "Acquisizione", Icons.Default.DocumentScanner),
        NavItem(AppNavTab.SECURITY, "Sicurezza", Icons.Default.Shield)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceCard,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            ) {
                navItems.forEach { item ->
                    val isSelected = currentTab == item.tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setNavTab(item.tab) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = if (isSelected) CyanNeon else TextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) CyanNeon else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CyanNeon.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = currentTab == AppNavTab.DASHBOARD || currentTab == AppNavTab.LOBES || currentTab == AppNavTab.GALLERY
            ) {
                FloatingActionButton(
                    onClick = {
                        if (currentTab == AppNavTab.GALLERY) {
                            viewModel.openCameraDialog()
                        } else {
                            viewModel.openAddMemoryDialog(null)
                        }
                    },
                    containerColor = CyanNeon,
                    contentColor = Color.Black,
                    shape = CircleShape,
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        imageVector = if (currentTab == AppNavTab.GALLERY) Icons.Default.PhotoCamera else Icons.Default.Add,
                        contentDescription = "Azione",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                AppNavTab.NEURAL_GRAPH -> NeuralGraphScreen(viewModel = viewModel)
                AppNavTab.SOCRATIC_INTERVIEW -> SocraticInterviewScreen(viewModel = viewModel)
                AppNavTab.DRIVE_IMPORT -> DriveImportScreen(viewModel = viewModel)
                AppNavTab.DECISION_SIMULATOR -> DecisionSimulatorScreen(viewModel = viewModel)
                AppNavTab.LOBES -> LobesScreen(viewModel = viewModel)
                AppNavTab.GALLERY -> EncryptedGalleryScreen(
                    viewModel = viewModel,
                    onOpenAddMemory = { item -> viewModel.openAddMemoryDialog(item) }
                )
                AppNavTab.CHAT -> BrainCloneChatScreen(viewModel = viewModel)
                AppNavTab.REMOTE_PORTAL -> RemoteAccessScreen(viewModel = viewModel)
                AppNavTab.AUTO_IMPORT -> AutoIngestScreen(viewModel = viewModel)
                AppNavTab.SECURITY -> SecuritySettingsScreen(viewModel = viewModel)
            }
        }
    }

    // Modal: Add / Edit Memory
    if (isAddDialogOpen) {
        AddEditMemoryDialog(
            initialItem = memoryToEdit,
            onDismiss = { viewModel.closeAddMemoryDialog() },
            onSave = { savedItem -> viewModel.saveMemory(savedItem) }
        )
    }

    // Modal: Memory Details
    activeDetailItem?.let { item ->
        MemoryDetailSheet(
            item = item,
            isVaultUnlocked = isVaultUnlocked,
            onDismiss = { viewModel.closeDetail() },
            onEdit = { viewModel.openAddMemoryDialog(item) },
            onDelete = { viewModel.deleteMemory(item) },
            onRequestUnlock = { viewModel.openUnlockDialog() },
            onCategoryClick = { category ->
                viewModel.closeDetail()
                viewModel.selectCategory(category)
                viewModel.setNavTab(AppNavTab.DASHBOARD)
            },
            onTagClick = { tag ->
                viewModel.closeDetail()
                viewModel.selectTag(tag)
                viewModel.setNavTab(AppNavTab.DASHBOARD)
            }
        )
    }

    // Modal: Security Master PIN Unlock
    if (isUnlockDialogOpen) {
        SecurityMasterDialog(
            onDismiss = { viewModel.closeUnlockDialog() },
            onVerifyPin = { pin -> viewModel.verifyAndUnlockVault(pin) },
            onBiometricUnlock = { viewModel.unlockWithBiometrics() }
        )
    }

    // Modal: CameraX Real-time Capture Dialog
    if (isCameraOpen) {
        SynapticCameraDialog(
            initialLobe = cameraTargetLobe,
            onDismiss = { viewModel.closeCameraDialog() },
            onSavePhotoMemory = { bytes, rotation, title, content, lobe, tags, isEncrypted ->
                viewModel.saveCapturedPhotoMemory(bytes, rotation, title, content, lobe, tags, isEncrypted)
            }
        )
    }

    // Modal: Voice-to-Text Recording Dialog
    if (isVoiceOpen) {
        VoiceThoughtRecorderDialog(
            initialLobe = voiceTargetLobe,
            onDismiss = { viewModel.closeVoiceDialog() },
            onSaveMemory = { title, content, lobe, category, tags, isEncrypted ->
                viewModel.saveVoiceMemory(title, content, lobe, category, tags, isEncrypted)
            }
        )
    }

    // Modal: Voice Interrogation & Cognitive AI Synthesis Dialog
    if (isVoiceQueryOpen) {
        VoiceQueryBrainDialog(
            initialQuery = voiceQueryPrompt,
            isQueryLoading = isVoiceQueryLoading,
            aiAnswer = voiceQueryAiAnswer,
            matchedMemories = voiceQueryMatches,
            onQuerySubmit = { query -> viewModel.executeVoiceBrainQuery(query) },
            onOpenMemoryDetail = { item ->
                viewModel.closeVoiceQueryDialog()
                viewModel.openDetail(item)
            },
            onNavigateToChat = { query ->
                viewModel.closeVoiceQueryDialog()
                viewModel.setNavTab(AppNavTab.CHAT)
                if (query.isNotBlank()) {
                    viewModel.sendChatMessage(query)
                }
            },
            onDismiss = { viewModel.closeVoiceQueryDialog() }
        )
    }
}
