package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.BrainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EncryptedGalleryScreen(
    viewModel: BrainViewModel,
    onOpenAddMemory: (BrainItem?) -> Unit,
    modifier: Modifier = Modifier
) {
    val allItems by viewModel.allItems.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()

    // Filter items that have photos or belong to Occipital Lobe
    val visualItems = allItems.filter { item ->
        !item.photoUri.isNullOrBlank() || item.lobeType == BrainLobe.OCCIPITAL.id
    }

    var selectedItemForDetail by remember { mutableStateOf<BrainItem?>(null) }
    var selectedFilterLobe by remember { mutableStateOf<BrainLobe?>(null) }

    val filteredList = if (selectedFilterLobe == null) {
        visualItems
    } else {
        visualItems.filter { it.lobeType == selectedFilterLobe?.id }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            item(span = { GridItemSpan(2) }) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Galleria Criptata",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(EmeraldNeon.copy(alpha = 0.2f))
                                        .border(1.dp, EmeraldNeon.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("AES-256", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldNeon)
                                }
                            }
                            Text(
                                text = "Sinapsi visive e foto catturate con CameraX, cifrate su device.",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }

                        // Camera Quick Action Button
                        Button(
                            onClick = { viewModel.openCameraDialog(BrainLobe.OCCIPITAL) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = "Scatta", tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scatta", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Lobe Filter Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // All Chip
                        FilterChipItem(
                            title = "Tutte (${visualItems.size})",
                            isSelected = selectedFilterLobe == null,
                            activeColor = CyanNeon,
                            onClick = { selectedFilterLobe = null }
                        )
                        // Occipital Chip
                        FilterChipItem(
                            title = "Lobo Occipitale",
                            isSelected = selectedFilterLobe == BrainLobe.OCCIPITAL,
                            activeColor = BrainLobe.OCCIPITAL.color,
                            onClick = { selectedFilterLobe = BrainLobe.OCCIPITAL }
                        )
                        // Vault Chip
                        FilterChipItem(
                            title = "Caveau Cifrato",
                            isSelected = selectedFilterLobe == BrainLobe.NEURAL_VAULT,
                            activeColor = PinkVault,
                            onClick = { selectedFilterLobe = BrainLobe.NEURAL_VAULT }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            if (filteredList.isEmpty()) {
                item(span = { GridItemSpan(2) }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(16.dp))
                            .padding(vertical = 40.dp, horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                tint = CyanNeon.copy(alpha = 0.7f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Nessuna foto memorizzata",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Usa CameraX per scattare una foto e archiviarla con crittografia end-to-end all'interno del tuo cervello.",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.openCameraDialog(BrainLobe.OCCIPITAL) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Scatta Prima Foto", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { item ->
                    EncryptedPhotoTile(
                        item = item,
                        viewModel = viewModel,
                        isVaultUnlocked = isVaultUnlocked,
                        onClick = { selectedItemForDetail = item }
                    )
                }
            }
        }
    }

    // Detail Dialog for selected photo
    selectedItemForDetail?.let { item ->
        EncryptedPhotoDetailDialog(
            item = item,
            viewModel = viewModel,
            isVaultUnlocked = isVaultUnlocked,
            onDismiss = { selectedItemForDetail = null },
            onEdit = {
                selectedItemForDetail = null
                onOpenAddMemory(item)
            },
            onDelete = {
                viewModel.deleteMemory(item)
                selectedItemForDetail = null
            },
            onRequestUnlock = {
                viewModel.openUnlockDialog()
            }
        )
    }
}

@Composable
fun FilterChipItem(
    title: String,
    isSelected: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) activeColor.copy(alpha = 0.2f) else SurfaceCard)
            .border(1.dp, if (isSelected) activeColor else SurfaceCardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) activeColor else TextSecondary
        )
    }
}

@Composable
fun EncryptedPhotoTile(
    item: BrainItem,
    viewModel: BrainViewModel,
    isVaultUnlocked: Boolean,
    onClick: () -> Unit
) {
    var decryptedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val isLockedVault = (item.lobeType == BrainLobe.NEURAL_VAULT.id || item.isEncrypted) && !isVaultUnlocked

    LaunchedEffect(item.photoUri, isLockedVault) {
        val uri = item.photoUri
        if (!isLockedVault && uri != null && uri.startsWith("enc_synapse://")) {
            isLoading = true
            decryptedBitmap = viewModel.photoStorage.loadDecryptedBitmap(uri)
            isLoading = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        if (isLockedVault) {
            // Locked Vault Tile
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            listOf(PinkVault.copy(alpha = 0.25f), SurfaceCard)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = "Locked", tint = PinkVault, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Foto Cifrata", fontSize = 11.sp, color = PinkVault, fontWeight = FontWeight.Bold)
                    Text("Richiede PIN", fontSize = 9.sp, color = TextMuted)
                }
            }
        } else if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CyanNeon, modifier = Modifier.size(24.dp))
            }
        } else if (decryptedBitmap != null) {
            // Decrypted Camera Photo
            Image(
                bitmap = decryptedBitmap!!.asImageBitmap(),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Preset / Abstract neural visual representation
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.linearGradient(
                            listOf(item.getLobe().color.copy(alpha = 0.3f), SurfaceCardElevated)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = null,
                    tint = item.getLobe().color,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Bottom gradient info overlay
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
                .padding(8.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isLockedVault) "••••••••" else item.title,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Icon(
                        imageVector = if (item.isEncrypted) Icons.Default.Lock else Icons.Default.PhotoCamera,
                        contentDescription = null,
                        tint = if (item.isEncrypted) EmeraldNeon else CyanNeon,
                        modifier = Modifier.size(12.dp)
                    )
                }
                Text(
                    text = item.getLobe().title,
                    fontSize = 9.sp,
                    color = item.getLobe().color
                )
            }
        }
    }
}

@Composable
fun EncryptedPhotoDetailDialog(
    item: BrainItem,
    viewModel: BrainViewModel,
    isVaultUnlocked: Boolean,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRequestUnlock: () -> Unit
) {
    val isLockedVault = (item.lobeType == BrainLobe.NEURAL_VAULT.id || item.isEncrypted) && !isVaultUnlocked
    var decryptedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isDecrypting by remember { mutableStateOf(false) }

    LaunchedEffect(item.photoUri, isLockedVault) {
        val uri = item.photoUri
        if (!isLockedVault && uri != null && uri.startsWith("enc_synapse://")) {
            isDecrypting = true
            decryptedBitmap = viewModel.photoStorage.loadDecryptedBitmap(uri)
            isDecrypting = false
        }
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.ITALIAN) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark),
            color = BackgroundDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Header Controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Chiudi", tint = TextPrimary)
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCard)
                            .border(1.dp, EmeraldNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(12.dp))
                        Text("AES-256-GCM Protetto", fontSize = 10.5.sp, color = EmeraldNeon, fontWeight = FontWeight.Bold)
                    }

                    Row {
                        IconButton(onClick = onEdit) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Modifica", tint = CyanNeon)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Elimina", tint = TextMuted)
                        }
                    }
                }

                // Full-size Photo View or Locked Vault placeholder
                if (isLockedVault) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                            .background(SurfaceCardElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Bloccato",
                                tint = PinkVault,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Foto Criptata nel Caveau Neurale",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Questa immagine è protetta con crittografia end-to-end. Inserisci il Master PIN per decifrarla in memoria.",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onRequestUnlock,
                                colors = ButtonDefaults.buttonColors(containerColor = PinkVault),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sblocca con Master PIN", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (isDecrypting) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                            .background(SurfaceCard),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = CyanNeon)
                    }
                } else if (decryptedBitmap != null) {
                    Image(
                        bitmap = decryptedBitmap!!.asImageBitmap(),
                        contentDescription = item.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .background(Color.Black),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(item.getLobe().color.copy(alpha = 0.4f), SurfaceCard)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = item.getLobe().color, modifier = Modifier.size(64.dp))
                    }
                }

                // Metadata and reflection details
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isLockedVault) "Memoria Criptata" else item.title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(item.getLobe().color.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = item.getLobe().title.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = item.getLobe().color
                            )
                        }

                        Text(
                            text = dateFormatter.format(Date(item.createdAt)),
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "NOTE & IMPRESSIONE SINAPTICA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isLockedVault) "••••••••••••••••••••••••••••••••••••" else item.content.ifBlank { "Nessuna annotazione registrata per questa sinapsi visiva." },
                        fontSize = 14.sp,
                        color = TextSecondary,
                        lineHeight = 22.sp
                    )

                    if (item.tags.isNotBlank() && !isLockedVault) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "TAG COGNITIVI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = item.tags,
                            fontSize = 12.sp,
                            color = VioletNeon
                        )
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
