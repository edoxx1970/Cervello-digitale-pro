package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainLobe
import com.example.ui.components.LobeCard
import com.example.ui.components.MemoryCard
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.BrainViewModel

@Composable
fun LobesScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val allItems by viewModel.allItems.collectAsState()
    val lobeCounts by viewModel.lobeCounts.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()

    var activeLobe by remember { mutableStateOf(BrainLobe.FRONTAL) }

    val lobeItems = allItems.filter { it.lobeType == activeLobe.id }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Architettura dei Lobi Cerebrali",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = "Le informazioni del tuo clone sono organizzate nei 5 lobi cognitivi on-device.",
                fontSize = 12.5.sp,
                color = TextSecondary
            )
        }

        // Lobe Selector Cards
        items(BrainLobe.entries.toTypedArray()) { lobe ->
            val count = lobeCounts[lobe] ?: 0
            val isSelected = activeLobe == lobe
            LobeCard(
                lobe = lobe,
                itemCount = count,
                isSelected = isSelected,
                onClick = { activeLobe = lobe }
            )
        }

        // Active Lobe Description Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(1.dp, activeLobe.color.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeLobe.title.uppercase(),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeLobe.color,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "${lobeItems.size} sinapsi attive",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = activeLobe.description,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { viewModel.openVoiceQueryDialog("Cosa ho salvato nel ${activeLobe.title}?") },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon.copy(alpha = 0.2f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyanNeon),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Chiedi",
                                tint = CyanNeon,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 2.dp))
                            Text(
                                text = "Chiedi",
                                color = CyanNeon,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.openVoiceDialog(activeLobe) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice",
                                tint = activeLobe.color,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 2.dp))
                            Text(
                                text = "Voce",
                                color = activeLobe.color,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.openCameraDialog(activeLobe) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "Camera",
                                tint = EmeraldNeon,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 2.dp))
                            Text(
                                text = "Foto",
                                color = EmeraldNeon,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.openAddMemoryDialog(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = activeLobe.color),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 2.dp))
                            Text(
                                text = "Scrivi",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Items for Active Lobe
        if (lobeItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Nessun dato registrato in questo lobo cerebrale.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(lobeItems, key = { it.id }) { item ->
                MemoryCard(
                    item = item,
                    isVaultUnlocked = isVaultUnlocked,
                    onClick = { viewModel.openDetail(item) },
                    onCategoryClick = { category ->
                        viewModel.selectCategory(category)
                        viewModel.setNavTab(com.example.ui.viewmodel.AppNavTab.DASHBOARD)
                    },
                    onTagClick = { tag ->
                        viewModel.selectTag(tag)
                        viewModel.setNavTab(com.example.ui.viewmodel.AppNavTab.DASHBOARD)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
