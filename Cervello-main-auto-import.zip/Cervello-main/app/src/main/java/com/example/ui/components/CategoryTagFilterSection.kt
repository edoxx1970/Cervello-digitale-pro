package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoryTagFilterSection(
    categories: List<Pair<String, Int>>,
    tags: List<Pair<String, Int>>,
    selectedCategory: String?,
    selectedTag: String?,
    selectedLobe: BrainLobe? = null,
    searchQuery: String = "",
    matchingCount: Int,
    onSelectCategory: (String?) -> Unit,
    onSelectTag: (String?) -> Unit,
    onClearLobe: () -> Unit = {},
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasActiveFilter = selectedCategory != null || selectedTag != null || selectedLobe != null || searchQuery.isNotBlank()
    var isTagsExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(18.dp))
            .padding(14.dp)
    ) {
        // Active Filter Indicators Banner
        AnimatedVisibility(
            visible = hasActiveFilter,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Filtri attivi",
                            tint = CyanNeon,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Filtri attivi ($matchingCount ${if (matchingCount == 1) "risultato" else "risultati"})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyanNeon
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(PinkVault.copy(alpha = 0.15f))
                            .border(1.dp, PinkVault.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .clickable { onClearAll() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Azzera Tutto",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PinkVault
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Active badges row
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Lobe badge
                    if (selectedLobe != null) {
                        ActiveFilterBadge(
                            text = "Lobo: ${selectedLobe.title}",
                            color = selectedLobe.color,
                            onRemove = onClearLobe
                        )
                    }

                    // Category badge
                    if (selectedCategory != null) {
                        ActiveFilterBadge(
                            text = "Cat: $selectedCategory",
                            color = EmeraldNeon,
                            onRemove = { onSelectCategory(null) }
                        )
                    }

                    // Tag badge
                    if (selectedTag != null) {
                        ActiveFilterBadge(
                            text = "#$selectedTag",
                            color = AmberNeon,
                            onRemove = { onSelectTag(null) }
                        )
                    }

                    // Search query badge
                    if (searchQuery.isNotBlank()) {
                        ActiveFilterBadge(
                            text = "\"$searchQuery\"",
                            color = CyanNeon,
                            onRemove = onClearAll
                        )
                    }
                }
            }
        }

        // Section 1: Categories
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Category,
                    contentDescription = "Categorie",
                    tint = EmeraldNeon,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "CATEGORIE NEURALI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldNeon,
                    letterSpacing = 0.5.sp
                )
            }
            if (selectedCategory != null) {
                Text(
                    text = "Deseleziona",
                    fontSize = 11.sp,
                    color = TextMuted,
                    modifier = Modifier.clickable { onSelectCategory(null) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal Category Chips Scroll
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // "Tutte" chip
            val isAllSelected = selectedCategory == null
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isAllSelected) EmeraldNeon.copy(alpha = 0.2f) else SurfaceCardElevated)
                    .border(
                        1.dp,
                        if (isAllSelected) EmeraldNeon else SurfaceCardBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .clickable { onSelectCategory(null) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Tutte",
                    fontSize = 12.sp,
                    fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isAllSelected) EmeraldNeon else TextSecondary
                )
            }

            categories.forEach { (catName, count) ->
                val isSelected = selectedCategory.equals(catName, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) EmeraldNeon.copy(alpha = 0.25f) else SurfaceCardElevated)
                        .border(
                            1.dp,
                            if (isSelected) EmeraldNeon else SurfaceCardBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectCategory(if (isSelected) null else catName) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = catName,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) EmeraldNeon else TextPrimary
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (isSelected) EmeraldNeon else SurfaceCardBorder)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = count.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else TextMuted
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section 2: Tags Cloud
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocalOffer,
                    contentDescription = "Tag",
                    tint = AmberNeon,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "TAG SINAPTICI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AmberNeon,
                    letterSpacing = 0.5.sp
                )
            }

            if (tags.size > 5) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isTagsExpanded = !isTagsExpanded }
                ) {
                    Text(
                        text = if (isTagsExpanded) "Mostra Meno" else "Tutti i ${tags.size} tag",
                        fontSize = 11.sp,
                        color = AmberNeon
                    )
                    Icon(
                        imageVector = if (isTagsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = AmberNeon,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val displayedTags = if (isTagsExpanded || tags.size <= 8) tags else tags.take(8)

        if (displayedTags.isEmpty()) {
            Text(
                text = "Nessun tag memorizzato.",
                fontSize = 12.sp,
                color = TextMuted,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        } else {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                displayedTags.forEach { (tagName, count) ->
                    val isSelected = selectedTag.equals(tagName, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) {
                                    Brush.horizontalGradient(
                                        listOf(AmberNeon.copy(alpha = 0.3f), VioletNeon.copy(alpha = 0.2f))
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        listOf(SurfaceCardElevated, SurfaceCardElevated)
                                    )
                                }
                            )
                            .border(
                                1.dp,
                                if (isSelected) AmberNeon else SurfaceCardBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onSelectTag(if (isSelected) null else tagName) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "#$tagName",
                                fontSize = 11.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) AmberNeon else TextSecondary
                            )
                            Text(
                                text = "($count)",
                                fontSize = 10.sp,
                                color = if (isSelected) AmberNeon.copy(alpha = 0.8f) else TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveFilterBadge(
    text: String,
    color: Color,
    onRemove: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = text,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Icon(
                imageVector = Icons.Default.Clear,
                contentDescription = "Rimuovi filtro",
                tint = color,
                modifier = Modifier
                    .size(14.dp)
                    .clickable { onRemove() }
            )
        }
    }
}
