package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BrainItem
import com.example.data.model.EncryptedChatMessage
import com.example.data.model.ScannedFileEntity

@Database(
    entities = [BrainItem::class, EncryptedChatMessage::class, ScannedFileEntity::class],
    version = 3,
    exportSchema = false
)
abstract class BrainDatabase : RoomDatabase() {
    abstract fun brainDao(): BrainDao
    abstract fun chatDao(): ChatDao
    abstract fun scannedFileDao(): ScannedFileDao

    companion object {
        @Volatile
        private var INSTANCE: BrainDatabase? = null

        fun getDatabase(context: Context): BrainDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BrainDatabase::class.java,
                    "digital_brain_database.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
