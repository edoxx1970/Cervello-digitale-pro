package com.example.auth

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

class FirebaseAuthManager(private val context: Context) {
    val auth: FirebaseAuth? = try {
        FirebaseAuth.getInstance()
    } catch (e: IllegalStateException) {
        Log.e("FirebaseAuth", "FirebaseApp not initialized. Missing google-services.json?")
        null
    }
    private val credentialManager = CredentialManager.create(context)

    suspend fun signInWithGoogle(): Result<FirebaseUser> {
        return try {
            val rawNonce = UUID.randomUUID().toString()
            val bytes = rawNonce.toByteArray()
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            val hashedNonce = digest.fold("") { str, it -> str + "%02x".format(it) }

            // L'ID del client Web deve essere configurato nei Secrets di AI Studio
            val webClientId = try { 
                com.example.BuildConfig::class.java.getField("WEB_CLIENT_ID").get(null) as String 
            } catch (e: Exception) { 
                "YOUR_WEB_CLIENT_ID" 
            }

            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setNonce(hashedNonce)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(context = context, request = request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                
                val authInstance = auth ?: return Result.failure(Exception("Firebase non configurato (google-services.json mancante)"))
                
                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = authInstance.signInWithCredential(firebaseCredential).await()
                
                authResult.user?.let {
                    Result.success(it)
                } ?: Result.failure(Exception("Utente null dopo l'autenticazione"))
            } else {
                Result.failure(Exception("Credenziale ricevuta non valida o tipo errato"))
            }
        } catch (e: GetCredentialException) {
            Log.e("FirebaseAuth", "GetCredentialException", e)
            Result.failure(e)
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Exception during sign in", e)
            Result.failure(e)
        }
    }
    
    fun signOut() {
        auth?.signOut()
    }
}
