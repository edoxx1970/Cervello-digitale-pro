package com.example.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Chiave AES-256 residente nell'Android Keystore (hardware-backed dove
 * disponibile), usata esclusivamente per "avvolgere" (wrap) la chiave del
 * Caveau Neurale così che possa essere salvata su disco senza mai esporla in
 * chiaro. Questa chiave non lascia mai il chip sicuro del dispositivo.
 *
 * Serve a permettere lo sblocco biometrico del caveau: dopo un primo sblocco
 * col PIN, la chiave del caveau viene cifrata con questa chiave e salvata
 * (cifrata) nelle preferenze. Un successivo BiometricPrompt riuscito autorizza
 * l'app a recuperarla e decifrarla, senza dover richiedere di nuovo il PIN.
 *
 * Nota: qui non usiamo setUserAuthenticationRequired(true) sulla chiave di
 * wrapping stessa — l'autenticazione avviene tramite BiometricPrompt a livello
 * applicativo prima di chiamare unwrap(). Un irrobustimento futuro possibile è
 * legare direttamente questa chiave alla biometria via Keystore, così che sia
 * il sistema operativo (non solo il codice dell'app) a impedirne l'uso senza
 * autenticazione fresca.
 */
object VaultKeystoreCipher {
    private const val KEYSTORE_ALIAS = "cervello_vault_wrapping_key"
    private const val PROVIDER = "AndroidKeyStore"

    fun getOrCreateWrappingKey(): SecretKey {
        val keyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
