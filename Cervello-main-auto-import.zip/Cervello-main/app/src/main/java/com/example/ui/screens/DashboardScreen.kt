package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainLobe
import com.example.ui.components.E2EEBadge
import com.example.ui.components.MemoryCard
import com.example.ui.components.NeuralSynapseCanvas
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.BrainViewModel

@Composable
fun DashboardScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val items by viewModel.filteredItems.collectAsState()
    val allItems by viewModel.allItems.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedLobe by viewModel.selectedLobe.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedTag by viewModel.selectedTag.collectAsState()
    val availableCategories by viewModel.availableCategories.collectAsState()
    val availableTags by viewModel.availableTags.collectAsState()
    val lobeCounts by viewModel.lobeCounts.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    Box(modifier = modifier.fillMaxSize().background(BackgroundDark)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Brain Clone Identity & E2EE Status
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    brush = Brush.linearGradient(listOf(CyanNeon, VioletNeon))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = "Brain",
                                tint = Color.Black,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Clone Cerebrale",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${allItems.size} Sinapsi On-Device",
                                fontSize = 12.sp,
                                color = CyanNeon,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Auth login / logout
                        IconButton(
                            onClick = {
                                if (currentUser != null) viewModel.signOut() else viewModel.signInWithGoogle()
                            }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (currentUser != null) EmeraldNeon.copy(alpha = 0.15f) else Color.DarkGray.copy(alpha = 0.5f))
                                    .border(1.dp, if (currentUser != null) EmeraldNeon else Color.Gray, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "Auth",
                                    tint = if (currentUser != null) EmeraldNeon else Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Vault lock toggle / E2EE status
                        IconButton(
                            onClick = {
                                if (isVaultUnlocked) viewModel.lockVault() else viewModel.openUnlockDialog()
                            }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (isVaultUnlocked) EmeraldNeon.copy(alpha = 0.15f) else PinkVault.copy(alpha = 0.15f))
                                    .border(1.dp, if (isVaultUnlocked) EmeraldNeon else PinkVault, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isVaultUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                    contentDescription = "Vault",
                                    tint = if (isVaultUnlocked) EmeraldNeon else PinkVault,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Interactive Neural Synapse Canvas Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(22.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "MAPPA SINAPTICA INTERATTIVA",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon,
                                letterSpacing = 0.5.sp
                            )
                            E2EEBadge(
                                isServerActive = isServerRunning,
                                onClick = { viewModel.setNavTab(AppNavTab.REMOTE_PORTAL) }
                            )
                        }

                        NeuralSynapseCanvas(
                            selectedLobe = selectedLobe,
                            lobeCounts = lobeCounts,
                            onLobeSelected = { lobe ->
                                viewModel.selectLobe(if (selectedLobe == lobe) null else lobe)
                            }
                        )

                        Text(
                            text = if (selectedLobe != null) "Lobo Selezionato: ${selectedLobe!!.title} (Tocca di nuovo per resettare)" else "Tocca un nodo cerebrale per filtrare le sinapsi",
                            fontSize = 11.sp,
                            color = TextMuted,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }

            // Search Bar with Voice Interrogation Mic
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Cerca o interroga il cervello a voce...", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = CyanNeon
                        )
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = TextSecondary
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.openVoiceQueryDialog(searchQuery) }) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Interrogazione Vocale",
                                    tint = CyanNeon,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = SurfaceCard,
                        unfocusedContainerColor = SurfaceCard
                    )
                )
            }

            // Horizontal Lobes Quick Switcher
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        val isAllSelected = selectedLobe == null
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isAllSelected) CyanNeon.copy(alpha = 0.2f) else SurfaceCard)
                                .border(1.dp, if (isAllSelected) CyanNeon else SurfaceCardBorder, RoundedCornerShape(12.dp))
                                .clickable { viewModel.selectLobe(null) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Tutte (${allItems.size})",
                                fontSize = 12.sp,
                                fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isAllSelected) CyanNeon else TextSecondary
                            )
                        }
                    }

                    items(BrainLobe.entries.toTypedArray()) { lobe ->
                        val isSelected = selectedLobe == lobe
                        val count = lobeCounts[lobe] ?: 0
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) lobe.color.copy(alpha = 0.2f) else SurfaceCard)
                                .border(1.dp, if (isSelected) lobe.color else SurfaceCardBorder, RoundedCornerShape(12.dp))
                                .clickable { viewModel.selectLobe(if (isSelected) null else lobe) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "${lobe.title} ($count)",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) lobe.color else TextSecondary
                            )
                        }
                    }
                }
            }

            // Categories & Synaptic Tags Filter Panel
            item {
                com.example.ui.components.CategoryTagFilterSection(
                    categories = availableCategories,
                    tags = availableTags,
                    selectedCategory = selectedCategory,
                    selectedTag = selectedTag,
                    selectedLobe = selectedLobe,
                    searchQuery = searchQuery,
                    matchingCount = items.size,
                    onSelectCategory = { viewModel.selectCategory(it) },
                    onSelectTag = { viewModel.selectTag(it) },
                    onClearLobe = { viewModel.selectLobe(null) },
                    onClearAll = { viewModel.clearAllFilters() }
                )
            }

            // Quick Actions: Voice Interrogation, Voice Note, AI Clone, CameraX
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Voice Interrogation Card (Primary AI Voice Query)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        CyanNeon.copy(alpha = 0.22f),
                                        SurfaceCardElevated
                                    )
                                )
                            )
                            .border(1.dp, CyanNeon, RoundedCornerShape(16.dp))
                            .clickable { viewModel.openVoiceQueryDialog() }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Chiedi a Voce",
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Chiedi a Voce",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                            Text(
                                text = "Query Rapida",
                                fontSize = 9.5.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // Voice Note Recording Card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        VioletNeon.copy(alpha = 0.22f),
                                        SurfaceCardElevated
                                    )
                                )
                            )
                            .border(1.dp, VioletNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .clickable { viewModel.openVoiceDialog(BrainLobe.TEMPORAL) }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice Input",
                                tint = VioletNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Nota Vocale",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Dettatura",
                                fontSize = 9.5.sp,
                                color = VioletNeon
                            )
                        }
                    }

                    // AI Clone Chat
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCardElevated)
                            .border(1.dp, AmberNeon.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                            .clickable { viewModel.setNavTab(AppNavTab.CHAT) }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI",
                                tint = AmberNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Clone AI",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Gemini 3.5",
                                fontSize = 9.5.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // CameraX Photo
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceCardElevated)
                            .border(1.dp, EmeraldNeon.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                            .clickable { viewModel.openCameraDialog(BrainLobe.OCCIPITAL) }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "CameraX",
                                tint = EmeraldNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Scatto E2EE",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "CameraX",
                                fontSize = 9.5.sp,
                                color = EmeraldNeon
                            )
                        }
                    }
                }
            }

            // Advanced Cognitive Engines: Neural Graph, Socratic Interview & Decision Simulator
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Socratic Banner Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        AmberNeon.copy(alpha = 0.18f),
                                        VioletNeon.copy(alpha = 0.15f),
                                        SurfaceCardElevated
                                    )
                                )
                            )
                            .border(1.dp, AmberNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .clickable { viewModel.setNavTab(AppNavTab.SOCRATIC_INTERVIEW) }
                            .padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(AmberNeon.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QuestionAnswer,
                                        contentDescription = "Intervista Socratica",
                                        tint = AmberNeon,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "INTERVISTA SOCRATICA & ESTRAZIONE",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmberNeon,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Rispondi a voce alle domande guida: Gemini sintetizza ed archivia automaticamente i ricordi.",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    // Google Drive & Cloud Import Banner Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        CyanNeon.copy(alpha = 0.18f),
                                        EmeraldNeon.copy(alpha = 0.12f),
                                        SurfaceCardElevated
                                    )
                                )
                            )
                            .border(1.dp, CyanNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .clickable { viewModel.setNavTab(AppNavTab.DRIVE_IMPORT) }
                            .padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(CyanNeon.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudDownload,
                                        contentDescription = "Importazione Drive",
                                        tint = CyanNeon,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "IMPORTAZIONE GOOGLE DRIVE & FILE SAF",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanNeon,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Importa documenti Google Drive, PDF o file di testo con categorizzazione neurale istantanea.",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Neural Graph Card
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            CyanNeon.copy(alpha = 0.18f),
                                            SurfaceCardElevated
                                        )
                                    )
                                )
                                .border(1.dp, CyanNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable { viewModel.setNavTab(AppNavTab.NEURAL_GRAPH) }
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(CyanNeon.copy(alpha = 0.25f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Hub,
                                            contentDescription = "Mappa Neurale",
                                            tint = CyanNeon,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = "MAPPA NEURALE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanNeon
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Costellazione 3D e grafo delle sinapsi",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    lineHeight = 14.sp
                                )
                            }
                        }

                        // Decision Simulator Card
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            VioletNeon.copy(alpha = 0.18f),
                                            SurfaceCardElevated
                                        )
                                    )
                                )
                                .border(1.dp, VioletNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable { viewModel.setNavTab(AppNavTab.DECISION_SIMULATOR) }
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(VioletNeon.copy(alpha = 0.25f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountTree,
                                            contentDescription = "Simulatore Decisioni",
                                            tint = VioletNeon,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = "SIMULATORE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VioletNeon
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Deliberazione e consiglio dai tuoi lobi",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // Section Title: Memories
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (selectedLobe != null) "Sinapsi: ${selectedLobe!!.title}" else "Sinapsi & Memorie Recenti",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${items.size} elementi",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }

            // List of items
            if (items.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Nessuna sinapsi trovata",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tocca il pulsante '+' per registrare un nuovo pensiero o ricordo.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            } else {
                items(items, key = { it.id }) { item ->
                    MemoryCard(
                        item = item,
                        isVaultUnlocked = isVaultUnlocked,
                        onClick = { viewModel.openDetail(item) },
                        onCategoryClick = { viewModel.selectCategory(it) },
                        onTagClick = { viewModel.selectTag(it) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
