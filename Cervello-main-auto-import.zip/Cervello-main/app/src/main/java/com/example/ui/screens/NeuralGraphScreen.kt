package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.BrainViewModel
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private data class NodePosition(
    val item: BrainItem,
    val basePos: Offset,
    val color: Color,
    val radius: Float
)

private data class SynapticLink(
    val startIndex: Int,
    val endIndex: Int,
    val strength: Float, // 0.1 to 1.0
    val color: Color
)

@Composable
fun NeuralGraphScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val allItems by viewModel.allItems.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val selectedNode by viewModel.selectedGraphNode.collectAsState()
    val lobeFilter by viewModel.graphLobeFilter.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var zoomScale by remember { mutableFloatStateOf(1.0f) }

    // Infinite animation for pulsing synaptic signals
    val infiniteTransition = rememberInfiniteTransition(label = "synaptic_pulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_phase"
    )
    val glowBreath by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_breath"
    )

    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        zoomScale = (zoomScale * zoomChange).coerceIn(0.4f, 3.0f)
        panOffset += panChange
    }

    // Filter items based on lobe filter, search, and encryption privacy
    val visibleItems = remember(allItems, lobeFilter, searchQuery, isVaultUnlocked) {
        allItems.filter { item ->
            val matchesLobe = lobeFilter == null || item.lobeType == lobeFilter?.id
            val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.category.contains(searchQuery, ignoreCase = true) ||
                item.tags.contains(searchQuery, ignoreCase = true)
            matchesLobe && matchesSearch
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        val canvasWidth = constraints.maxWidth.toFloat()
        val canvasHeight = constraints.maxHeight.toFloat()
        val center = Offset(canvasWidth / 2f, canvasHeight / 2f)

        // Calculate constellation coordinates for nodes
        val (nodePositions, links) = remember(visibleItems, canvasWidth, canvasHeight) {
            val nodes = mutableListOf<NodePosition>()
            val linksList = mutableListOf<SynapticLink>()

            if (visibleItems.isEmpty()) {
                return@remember Pair(nodes, linksList)
            }

            val count = visibleItems.size
            val radiusStep = (minOf(canvasWidth, canvasHeight) * 0.35f)

            // Lobe center offsets to create structured neural lobes clustering
            val lobeCenters = mapOf(
                BrainLobe.FRONTAL.id to Offset(-0.35f, -0.4f),
                BrainLobe.PARIETAL.id to Offset(0.35f, -0.35f),
                BrainLobe.TEMPORAL.id to Offset(-0.3f, 0.35f),
                BrainLobe.OCCIPITAL.id to Offset(0.35f, 0.35f),
                BrainLobe.NEURAL_VAULT.id to Offset(0.0f, 0.0f)
            )

            visibleItems.forEachIndexed { index, item ->
                val lobeCenterFactor = lobeCenters[item.lobeType] ?: Offset(0f, 0f)
                val angle = (index.toDouble() / count.toDouble()) * 2.0 * Math.PI + (index * 0.7)
                val distance = radiusStep * (0.45f + 0.55f * ((index % 5) / 5f))

                val clusterCenterX = center.x + lobeCenterFactor.x * canvasWidth * 0.45f
                val clusterCenterY = center.y + lobeCenterFactor.y * canvasHeight * 0.4f

                val posX = (clusterCenterX + cos(angle) * distance * 0.6f).toFloat()
                val posY = (clusterCenterY + sin(angle) * distance * 0.6f).toFloat()

                val lobeColor = item.getLobe().color
                val nodeRadius = if (item.isEncrypted) 16f else (18f + (item.content.length.coerceAtMost(300) / 30f))

                nodes.add(
                    NodePosition(
                        item = item,
                        basePos = Offset(posX, posY),
                        color = lobeColor,
                        radius = nodeRadius
                    )
                )
            }

            // Build synaptic connection links between nodes sharing lobe, category, or tags
            for (i in 0 until nodes.size) {
                for (j in (i + 1) until nodes.size) {
                    val itemA = nodes[i].item
                    val itemB = nodes[j].item
                    var connectionWeight = 0f

                    if (itemA.lobeType == itemB.lobeType) {
                        connectionWeight += 0.3f
                    }
                    if (itemA.category.isNotBlank() && itemA.category.equals(itemB.category, ignoreCase = true)) {
                        connectionWeight += 0.5f
                    }

                    // Check shared tags
                    val tagsA = itemA.getTagsList().map { it.lowercase().trim() }
                    val tagsB = itemB.getTagsList().map { it.lowercase().trim() }
                    val commonTags = tagsA.intersect(tagsB.toSet())
                    if (commonTags.isNotEmpty()) {
                        connectionWeight += 0.4f * commonTags.size
                    }

                    if (connectionWeight > 0.25f) {
                        val mixedColor = nodes[i].color
                        linksList.add(
                            SynapticLink(
                                startIndex = i,
                                endIndex = j,
                                strength = connectionWeight.coerceIn(0.2f, 1.0f),
                                color = mixedColor
                            )
                        )
                    }
                }
            }

            Pair(nodes, linksList)
        }

        // Interactive Canvas Layer
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .transformable(state = transformState)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        panOffset += dragAmount
                    }
                }
                .pointerInput(nodePositions, panOffset, zoomScale) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val tapPos = event.changes.firstOrNull()?.position ?: continue
                            if (event.changes.any { it.isConsumed }) continue

                            // Check if a node was tapped
                            var clickedNode: BrainItem? = null
                            for (node in nodePositions) {
                                val transformedNodePos = (node.basePos - center) * zoomScale + center + panOffset
                                val dx = tapPos.x - transformedNodePos.x
                                val dy = tapPos.y - transformedNodePos.y
                                val dist = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (dist <= (node.radius * zoomScale * 1.6f).coerceAtLeast(36f)) {
                                    clickedNode = node.item
                                    break
                                }
                            }
                            if (clickedNode != null && event.changes.first().pressed.not()) {
                                viewModel.selectGraphNode(if (selectedNode?.id == clickedNode.id) null else clickedNode)
                            }
                        }
                    }
                }
        ) {
            // Draw decorative neural grid background
            val gridSpacing = 60f * zoomScale
            val startX = (panOffset.x % gridSpacing)
            val startY = (panOffset.y % gridSpacing)
            var curX = startX
            while (curX < size.width) {
                drawLine(
                    color = SurfaceCardBorder.copy(alpha = 0.15f),
                    start = Offset(curX, 0f),
                    end = Offset(curX, size.height),
                    strokeWidth = 1f
                )
                curX += gridSpacing
            }
            var curY = startY
            while (curY < size.height) {
                drawLine(
                    color = SurfaceCardBorder.copy(alpha = 0.15f),
                    start = Offset(0f, curY),
                    end = Offset(size.width, curY),
                    strokeWidth = 1f
                )
                curY += gridSpacing
            }

            // Draw central brain core ring
            val transformedCenter = center + panOffset
            drawCircle(
                color = CyanNeon.copy(alpha = 0.04f * glowBreath),
                radius = 180f * zoomScale,
                center = transformedCenter
            )
            drawCircle(
                color = VioletNeon.copy(alpha = 0.15f),
                radius = 120f * zoomScale,
                center = transformedCenter,
                style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)))
            )

            // Draw Synaptic Connection Lines
            links.forEach { link ->
                if (link.startIndex < nodePositions.size && link.endIndex < nodePositions.size) {
                    val nodeA = nodePositions[link.startIndex]
                    val nodeB = nodePositions[link.endIndex]

                    val posA = (nodeA.basePos - center) * zoomScale + center + panOffset
                    val posB = (nodeB.basePos - center) * zoomScale + center + panOffset

                    val isHighlighted = selectedNode != null && (nodeA.item.id == selectedNode?.id || nodeB.item.id == selectedNode?.id)
                    val lineAlpha = if (selectedNode == null) {
                        (0.18f * link.strength)
                    } else if (isHighlighted) {
                        0.85f
                    } else {
                        0.05f
                    }

                    val strokeW = if (isHighlighted) 2.5f * zoomScale else (1.2f * link.strength * zoomScale)

                    drawLine(
                        color = if (isHighlighted) CyanNeon.copy(alpha = lineAlpha) else link.color.copy(alpha = lineAlpha),
                        start = posA,
                        end = posB,
                        strokeWidth = strokeW
                    )

                    // Draw animated traveling energy spark along the link
                    if (isHighlighted || (selectedNode == null && link.strength > 0.4f)) {
                        val sparkT = (pulsePhase + (link.startIndex * 0.17f)) % 1f
                        val sparkX = posA.x + (posB.x - posA.x) * sparkT
                        val sparkY = posA.y + (posB.y - posA.y) * sparkT
                        drawCircle(
                            color = if (isHighlighted) Color.White else link.color,
                            radius = (if (isHighlighted) 3.5f else 2.2f) * zoomScale,
                            center = Offset(sparkX, sparkY)
                        )
                    }
                }
            }

            // Draw Nodes
            nodePositions.forEach { node ->
                val transformedPos = (node.basePos - center) * zoomScale + center + panOffset
                val isSelected = selectedNode?.id == node.item.id
                val isDimmed = selectedNode != null && !isSelected && links.none { link ->
                    (nodePositions.getOrNull(link.startIndex)?.item?.id == selectedNode?.id && nodePositions.getOrNull(link.endIndex)?.item?.id == node.item.id) ||
                    (nodePositions.getOrNull(link.endIndex)?.item?.id == selectedNode?.id && nodePositions.getOrNull(link.startIndex)?.item?.id == node.item.id)
                }

                val nodeAlpha = if (isDimmed) 0.25f else 1.0f
                val effectiveRadius = (node.radius * zoomScale) * (if (isSelected) 1.35f else 1.0f)

                // Outer Halo Glow
                drawCircle(
                    color = node.color.copy(alpha = (if (isSelected) 0.5f else 0.18f * glowBreath) * nodeAlpha),
                    radius = effectiveRadius * (if (isSelected) 2.2f else 1.7f),
                    center = transformedPos
                )

                // Outer Ring
                drawCircle(
                    color = if (isSelected) Color.White else node.color.copy(alpha = nodeAlpha),
                    radius = effectiveRadius,
                    center = transformedPos,
                    style = Stroke(width = if (isSelected) 3f else 1.8f)
                )

                // Inner Core
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            if (isSelected) Color.White else node.color,
                            node.color.copy(alpha = 0.6f * nodeAlpha),
                            SurfaceCardElevated
                        ),
                        center = transformedPos,
                        radius = effectiveRadius
                    ),
                    radius = effectiveRadius * 0.85f,
                    center = transformedPos
                )

                // Encrypted vault lock indicator
                if (node.item.isEncrypted) {
                    drawCircle(
                        color = PinkVault,
                        radius = effectiveRadius * 0.4f,
                        center = transformedPos
                    )
                }
            }
        }

        // Top Overlay: HUD, Filters & Search
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            // HUD Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceCard.copy(alpha = 0.92f))
                    .border(1.dp, SurfaceCardBorder, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Hub,
                        contentDescription = "Mappa Neurale",
                        tint = CyanNeon,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "MAPPA NEURALE SINAPTICA",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "${visibleItems.size} Nodi • ${links.size} Connessioni",
                            fontSize = 10.5.sp,
                            color = TextMuted
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Reset Pan/Zoom Button
                    IconButton(
                        onClick = {
                            panOffset = Offset.Zero
                            zoomScale = 1.0f
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CenterFocusStrong,
                            contentDescription = "Centra Mappa",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Lobe Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // "Tutti i Lobi" chip
                val isAllSelected = lobeFilter == null
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isAllSelected) CyanNeon.copy(alpha = 0.2f) else SurfaceCard.copy(alpha = 0.85f))
                        .border(1.dp, if (isAllSelected) CyanNeon else SurfaceCardBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setGraphLobeFilter(null) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Tutti (${allItems.size})",
                        fontSize = 11.sp,
                        fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isAllSelected) CyanNeon else TextSecondary
                    )
                }

                BrainLobe.values().forEach { lobe ->
                    val isSelected = lobeFilter == lobe
                    val count = allItems.count { it.lobeType == lobe.id }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) lobe.color.copy(alpha = 0.25f) else SurfaceCard.copy(alpha = 0.85f))
                        .border(1.dp, if (isSelected) lobe.color else SurfaceCardBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setGraphLobeFilter(if (isSelected) null else lobe) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(lobe.color)
                            )
                            Text(
                                text = "${lobe.title} ($count)",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) lobe.color else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Empty Search / Filter State
        if (visibleItems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Nessuna sinapsi attiva per questi filtri",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Azzera i filtri o aggiungi nuovi ricordi",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Bottom Selected Node Holographic Sheet
        AnimatedVisibility(
            visible = selectedNode != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            selectedNode?.let { item ->
                val lobe = item.getLobe()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceCard.copy(alpha = 0.96f))
                        .border(1.5.dp, lobe.color.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    // Header with Lobe & Close
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(lobe.color.copy(alpha = 0.2f))
                                    .border(1.dp, lobe.color, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = lobe.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = lobe.color
                                )
                            }

                            if (item.category.isNotBlank()) {
                                Text(
                                    text = "• ${item.category}",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.selectGraphNode(null) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Chiudi",
                                tint = TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = item.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (item.isEncrypted && !isVaultUnlocked) "🔒 Contenuto protetto da chiave crittografica hardware." else item.content,
                        fontSize = 12.5.sp,
                        color = TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Open full Detail
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyanNeon)
                                .clickable {
                                    viewModel.openDetail(item)
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInFull,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Espandi Sinapsi",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        // Chat with this memory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceCardElevated)
                                .border(1.dp, SurfaceCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    viewModel.setNavTab(com.example.ui.viewmodel.AppNavTab.CHAT)
                                    viewModel.sendChatMessage("Approfondisci e rifletti su questa memoria del mio cervello: ${item.title}")
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Chiedi al Clone",
                                tint = VioletNeon,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
