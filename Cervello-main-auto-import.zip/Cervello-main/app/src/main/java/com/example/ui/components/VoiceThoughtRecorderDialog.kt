package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.audio.SpeechState
import com.example.audio.SpeechToTextManager
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import kotlinx.coroutines.launch
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceThoughtRecorderDialog(
    initialLobe: BrainLobe = BrainLobe.TEMPORAL,
    onDismiss: () -> Unit,
    onSaveMemory: (
        title: String,
        content: String,
        lobe: BrainLobe,
        category: String,
        tags: String,
        isEncrypted: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val speechManager = remember { SpeechToTextManager(context) }

    val speechState by speechManager.speechState.collectAsState()
    val transcribedText by speechManager.transcribedText.collectAsState()
    val partialText by speechManager.partialText.collectAsState()
    val audioRmsDb by speechManager.audioRmsDb.collectAsState()
    val errorMessage by speechManager.errorMessage.collectAsState()

    var manualText by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var selectedLobe by remember { mutableStateOf(initialLobe) }
    var category by remember { mutableStateOf("Pensiero Vocale") }
    var tags by remember { mutableStateOf("#voce, #audio-memo, #pensiero-rapido") }
    var isEncrypted by remember { mutableStateOf(false) }
    var selectedLang by remember { mutableStateOf("it-IT") }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            speechManager.selectedLanguage = selectedLang
            speechManager.startListening(manualText)
        }
    }

    // Keep manual text in sync with transcribed text
    DisposableEffect(transcribedText) {
        if (transcribedText.isNotBlank()) {
            manualText = transcribedText
            if (title.isBlank()) {
                // Auto generate a clean title from the first 5-6 words
                val words = transcribedText.trim().split("\\s+".toRegex())
                title = words.take(6).joinToString(" ").replaceFirstChar { it.uppercase() }
                if (words.size > 6) title += "..."
            }
        }
        onDispose { }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechManager.destroyRecognizer()
        }
    }

    // Waveform & Pulse Animations
    val infiniteTransition = rememberInfiniteTransition(label = "mic_waves")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_pulse"
    )
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Dialog(
        onDismissRequest = {
            speechManager.destroyRecognizer()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .imePadding()
                .clip(RoundedCornerShape(24.dp))
                .background(SurfaceCard)
                .border(1.dp, SurfaceCardBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(VioletNeon.copy(alpha = 0.2f))
                                .border(1.dp, VioletNeon, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Voice",
                                tint = VioletNeon,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Acquisizione Pensiero Vocale",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Dettatura & Trascrizione Neurale Live",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    IconButton(onClick = {
                        speechManager.destroyRecognizer()
                        onDismiss()
                    }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Chiudi",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Language Selection Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        Pair("it-IT", "Italiano 🇮🇹"),
                        Pair("en-US", "English 🇬🇧"),
                        Pair("es-ES", "Español 🇪🇸")
                    ).forEach { (code, label) ->
                        val isSelected = selectedLang == code
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CyanNeon.copy(alpha = 0.2f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) CyanNeon else SurfaceCardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedLang = code
                                    speechManager.selectedLanguage = code
                                    if (speechState == SpeechState.LISTENING) {
                                        speechManager.stopListening()
                                        speechManager.startListening(manualText)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) CyanNeon else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Main Pulsing Mic Visualizer Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(
                                    SurfaceCardElevated,
                                    BackgroundDark
                                )
                            )
                        )
                        .border(
                            1.dp,
                            if (speechState == SpeechState.LISTENING) VioletNeon else SurfaceCardBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .padding(vertical = 20.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Big Mic Button with Dynamic Pulsing Halo
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .scale(if (speechState == SpeechState.LISTENING) (pulseScale + (audioRmsDb * 0.25f)) else 1f)
                                .clip(CircleShape)
                                .background(
                                    if (speechState == SpeechState.LISTENING)
                                        Brush.linearGradient(listOf(VioletNeon, CyanNeon))
                                    else
                                        Brush.linearGradient(listOf(SurfaceCardElevated, SurfaceCard))
                                )
                                .border(
                                    2.dp,
                                    if (speechState == SpeechState.LISTENING) CyanNeon else SurfaceCardBorder,
                                    CircleShape
                                )
                                .clickable {
                                    if (!hasAudioPermission) {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        if (speechState == SpeechState.LISTENING) {
                                            speechManager.stopListening()
                                        } else {
                                            speechManager.selectedLanguage = selectedLang
                                            speechManager.startListening(manualText)
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (speechState == SpeechState.LISTENING) Icons.Default.Mic else Icons.Default.MicOff,
                                contentDescription = "Mic",
                                tint = if (speechState == SpeechState.LISTENING) Color.Black else CyanNeon,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        // Real-time Sound Wave Equalizer Bars
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.height(36.dp)
                        ) {
                            for (i in 0 until 16) {
                                val dynamicHeight = if (speechState == SpeechState.LISTENING) {
                                    val wave = (sin(wavePhase + i * 0.45f) + 1f) / 2f
                                    val dbFactor = (audioRmsDb * 24.dp.value)
                                    (6.dp.value + (wave * 14.dp.value) + dbFactor).coerceIn(4f, 34f).dp
                                } else {
                                    4.dp
                                }

                                val barColor = when {
                                    speechState == SpeechState.LISTENING -> if (i % 2 == 0) CyanNeon else VioletNeon
                                    else -> TextMuted.copy(alpha = 0.4f)
                                }

                                Box(
                                    modifier = Modifier
                                        .width(3.5.dp)
                                        .height(dynamicHeight)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(barColor)
                                )
                            }
                        }

                        // State & Guide Label
                        Text(
                            text = when (speechState) {
                                SpeechState.LISTENING -> "In ascolto attivo... Parla liberamente!"
                                SpeechState.PROCESSING -> "Elaborazione trascrizione audio..."
                                SpeechState.ERROR -> errorMessage ?: "Errore audio"
                                else -> "Tocca il microfono per iniziare a parlare"
                            },
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = when (speechState) {
                                SpeechState.LISTENING -> EmeraldNeon
                                SpeechState.PROCESSING -> AmberNeon
                                SpeechState.ERROR -> PinkVault
                                else -> TextSecondary
                            },
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Real-time transcription or partial text preview
                if (partialText.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyanNeon.copy(alpha = 0.1f))
                            .border(1.dp, CyanNeon.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Trascrizione in corso: \"$partialText\"",
                            fontSize = 12.sp,
                            color = CyanNeon,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Title field (auto-populated or edited)
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Titolo Pensiero") },
                    placeholder = { Text("Es. Idea progetto, Riflessione...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Transcribed Content Field
                OutlinedTextField(
                    value = manualText,
                    onValueChange = { manualText = it },
                    label = { Text("Testo Trascritto / Pensiero Completo") },
                    placeholder = { Text("Il tuo audio trascritto apparirà qui. Puoi anche modificarlo a mano...") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick AI Classification Assistant Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(VioletNeon.copy(alpha = 0.15f))
                        .border(1.dp, VioletNeon.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .clickable {
                            if (manualText.isNotBlank()) {
                                // Smart local heuristic auto-categorizer & tag extractor
                                val lower = manualText.lowercase()
                                if (lower.contains("viaggio") || lower.contains("foto") || lower.contains("posto") || lower.contains("visto")) {
                                    selectedLobe = BrainLobe.OCCIPITAL
                                    category = "Memoria Visiva"
                                } else if (lower.contains("obiettivo") || lower.contains("decisione") || lower.contains("strategia") || lower.contains("task")) {
                                    selectedLobe = BrainLobe.FRONTAL
                                    category = "Obiettivo"
                                } else if (lower.contains("emozione") || lower.contains("corpo") || lower.contains("sensazione") || lower.contains("salute")) {
                                    selectedLobe = BrainLobe.PARIETAL
                                    category = "Sensazione"
                                } else {
                                    selectedLobe = BrainLobe.TEMPORAL
                                    category = "Pensiero Vocale"
                                }

                                if (title.isBlank()) {
                                    val words = manualText.trim().split("\\s+".toRegex())
                                    title = words.take(5).joinToString(" ").replaceFirstChar { it.uppercase() }
                                }

                                tags = "#voce, #audio-memo, #${selectedLobe.name.lowercase()}, #${category.lowercase().replace(" ", "-")}"
                            }
                        }
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI",
                                tint = VioletNeon,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Auto-Classifica Lobo & Tag con AI",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "Applica ➔",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = VioletNeon
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Lobe Selection Row
                Text(
                    text = "LOBO CEREBRALE DI DESTINAZIONE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BrainLobe.entries.forEach { lobe ->
                        val isSelected = selectedLobe == lobe
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) lobe.color.copy(alpha = 0.25f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) lobe.color else SurfaceCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedLobe = lobe }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(lobe.color)
                                )
                                Text(
                                    text = lobe.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Encryption Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceCardElevated)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            tint = if (isEncrypted) PinkVault else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "Cifra nel Caveau Neurale (AES-256)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Richiederà biometria o PIN Master per la lettura",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Switch(
                        checked = isEncrypted,
                        onCheckedChange = { isEncrypted = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PinkVault,
                            checkedTrackColor = PinkVault.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            speechManager.resetTranscript()
                            manualText = ""
                            title = ""
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Azzera", color = TextSecondary, fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            val finalTitle = if (title.isNotBlank()) title else "Pensiero Vocale ${System.currentTimeMillis() % 10000}"
                            val finalContent = if (manualText.isNotBlank()) manualText else "(Registrazione vocale)"
                            onSaveMemory(
                                finalTitle,
                                finalContent,
                                selectedLobe,
                                category,
                                tags,
                                isEncrypted
                            )
                            speechManager.destroyRecognizer()
                            onDismiss()
                        },
                        enabled = manualText.isNotBlank() || title.isNotBlank(),
                        modifier = Modifier.weight(2f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = selectedLobe.color,
                            disabledContainerColor = SurfaceCardElevated
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "Save",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Memorizza nel Cervello",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
