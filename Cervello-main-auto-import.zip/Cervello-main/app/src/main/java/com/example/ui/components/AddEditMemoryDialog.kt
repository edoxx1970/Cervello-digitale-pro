package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.audio.SpeechState
import com.example.audio.SpeechToTextManager
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditMemoryDialog(
    initialItem: BrainItem? = null,
    defaultLobe: BrainLobe = BrainLobe.PARIETAL,
    onDismiss: () -> Unit,
    onSave: (BrainItem) -> Unit
) {
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var content by remember { mutableStateOf(initialItem?.content ?: "") }
    var selectedLobe by remember { mutableStateOf(initialItem?.getLobe() ?: defaultLobe) }
    var category by remember { mutableStateOf(initialItem?.category ?: "") }
    var tags by remember { mutableStateOf(initialItem?.tags ?: "") }
    var importance by remember { mutableIntStateOf(initialItem?.importance ?: 3) }
    var emotionLevel by remember { mutableFloatStateOf(initialItem?.emotionLevel?.toFloat() ?: 50f) }
    var isEncrypted by remember { mutableStateOf(initialItem?.isEncrypted ?: (selectedLobe == BrainLobe.NEURAL_VAULT)) }
    var selectedPhotoPreset by remember { mutableStateOf(initialItem?.photoUri) }

    val context = LocalContext.current
    val speechManager = remember { SpeechToTextManager(context) }
    val speechState by speechManager.speechState.collectAsState()
    val transcribedText by speechManager.transcribedText.collectAsState()

    var activeVoiceField by remember { mutableStateOf<String?>(null) } // "title" or "content"

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted && activeVoiceField != null) {
            val initialPrefix = if (activeVoiceField == "title") title else content
            speechManager.startListening(initialPrefix)
        }
    }

    DisposableEffect(transcribedText) {
        if (transcribedText.isNotBlank()) {
            if (activeVoiceField == "title") {
                title = transcribedText
            } else if (activeVoiceField == "content") {
                content = transcribedText
            }
        }
        onDispose { }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechManager.destroyRecognizer()
        }
    }

    val presetCategories = listOf(
        "Principi", "Obiettivo 2026", "Viaggi", "Sviluppo Tech", "Finanze", "Salute & Biohacking", "Famiglia", "Filosofia"
    )

    val photoPresets = listOf(
        Pair("preset_mountains", "🏔️ Dolomiti"),
        Pair("preset_japan", "⛩️ Kyoto"),
        Pair("preset_neural_map", "🧠 Schema Neurale"),
        Pair("preset_workspace", "💻 Workstation"),
        Pair("preset_library", "📚 Biblioteca")
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .imePadding()
                .clip(RoundedCornerShape(24.dp))
                .background(SurfaceCard)
                .border(1.dp, SurfaceCardBorder, RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (initialItem == null) "🧠 Registra Nuova Sinapsi" else "✏️ Modifica Sinapsi",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Chiudi",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Lobe Selector
                Text(
                    text = "LOBO CEREBRALE DI DESTINAZIONE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrainLobe.entries.forEach { lobe ->
                        val isSelected = selectedLobe == lobe
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) lobe.color.copy(alpha = 0.2f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) lobe.color else SurfaceCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    selectedLobe = lobe
                                    if (lobe == BrainLobe.NEURAL_VAULT) isEncrypted = true
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = lobe.title,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) lobe.color else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Title field
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Titolo Pensiero o Ricordo") },
                    placeholder = { Text("Es. Strategia 2026 o Ricordo d'infanzia...") },
                    trailingIcon = {
                        IconButton(onClick = {
                            if (activeVoiceField == "title" && speechState == SpeechState.LISTENING) {
                                speechManager.stopListening()
                                activeVoiceField = null
                            } else {
                                activeVoiceField = "title"
                                if (!hasAudioPermission) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    speechManager.startListening(title)
                                }
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Dettatura Vocale",
                                tint = if (activeVoiceField == "title" && speechState == SpeechState.LISTENING) CyanNeon else TextMuted
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Category presets + input
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Categoria Neurale") },
                    placeholder = { Text("Es. Filosofia, Obiettivi, Viaggi...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    presetCategories.forEach { cat ->
                        val isCatSelected = category.equals(cat, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCatSelected) EmeraldNeon.copy(alpha = 0.25f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isCatSelected) EmeraldNeon else SurfaceCardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { category = cat }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isCatSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCatSelected) EmeraldNeon else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content field
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Contenuto & Dettagli Neurali") },
                    placeholder = { Text("Scrivi tutti i dettagli o premi il microfono per dettare a voce...") },
                    trailingIcon = {
                        IconButton(onClick = {
                            if (activeVoiceField == "content" && speechState == SpeechState.LISTENING) {
                                speechManager.stopListening()
                                activeVoiceField = null
                            } else {
                                activeVoiceField = "content"
                                if (!hasAudioPermission) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    speechManager.startListening(content)
                                }
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Dettatura Vocale",
                                tint = if (activeVoiceField == "content" && speechState == SpeechState.LISTENING) CyanNeon else TextMuted
                            )
                        }
                    },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Tags field + Suggestions
                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Tag Sinaptici (separati da virgola)") },
                    placeholder = { Text("es. ai, futuro, focus, privacy") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AmberNeon,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BackgroundDark,
                        unfocusedContainerColor = BackgroundDark
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                val popularTagPills = listOf("ai", "visione", "focus", "privacy", "obiettivi", "salute", "coding", "viaggi", "finanze", "e2ee")
                val currentTagList = tags.split(",").map { it.trim().removePrefix("#").lowercase() }.filter { it.isNotEmpty() }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    popularTagPills.forEach { pill ->
                        val isContained = currentTagList.contains(pill.lowercase())
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isContained) AmberNeon.copy(alpha = 0.25f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isContained) AmberNeon else SurfaceCardBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    if (isContained) {
                                        val remaining = currentTagList.filter { it != pill.lowercase() }
                                        tags = remaining.joinToString(", ")
                                    } else {
                                        val updated = if (tags.isBlank()) pill else "$tags, $pill"
                                        tags = updated
                                    }
                                }
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isContained) "✓ #$pill" else "+ #$pill",
                                fontSize = 11.sp,
                                fontWeight = if (isContained) FontWeight.Bold else FontWeight.Normal,
                                color = if (isContained) AmberNeon else TextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Photo Presets Selection
                Text(
                    text = "COLLEGAMENTO VISIVO / FOTO RICORDO",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (selectedPhotoPreset?.startsWith("enc_synapse://") == true) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyanNeon.copy(alpha = 0.15f))
                            .border(1.dp, CyanNeon, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null, tint = CyanNeon)
                            Text("Foto Criptata CameraX Collegata", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { selectedPhotoPreset = null }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Rimuovi", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    photoPresets.forEach { (id, label) ->
                        val isSelected = selectedPhotoPreset == id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CyanNeon.copy(alpha = 0.2f) else SurfaceCardElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) CyanNeon else SurfaceCardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedPhotoPreset = if (isSelected) null else id
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                color = if (isSelected) CyanNeon else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Importance Stars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Livello Importanza", fontSize = 13.sp, color = TextSecondary)
                    Row {
                        (1..5).forEach { star ->
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Star $star",
                                tint = if (star <= importance) AmberNeon else SurfaceCardBorder,
                                modifier = Modifier
                                    .size(24.dp)
                                    .clickable { importance = star }
                                    .padding(2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Emotion intensity slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Intensità Emotiva / Impatto", fontSize = 13.sp, color = TextSecondary)
                    Text(text = "${emotionLevel.toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyanNeon)
                }
                Slider(
                    value = emotionLevel,
                    onValueChange = { emotionLevel = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyanNeon,
                        activeTrackColor = CyanNeon,
                        inactiveTrackColor = SurfaceCardElevated
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // E2EE encryption toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceCardElevated)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            tint = PinkVault,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "Crittografa nel Caveau Neurale",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Protetto da crittografia AES-256 locale",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                    Switch(
                        checked = isEncrypted,
                        onCheckedChange = { isEncrypted = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PinkVault,
                            checkedTrackColor = PinkVault.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardElevated)
                    ) {
                        Text(text = "Annulla", color = TextSecondary)
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank() && content.isNotBlank()) {
                                val itemToSave = initialItem?.copy(
                                    title = title.trim(),
                                    content = content.trim(),
                                    lobeType = selectedLobe.id,
                                    category = category.trim().ifBlank { selectedLobe.title },
                                    tags = tags.trim(),
                                    photoUri = selectedPhotoPreset,
                                    importance = importance,
                                    emotionLevel = emotionLevel.toInt(),
                                    isEncrypted = isEncrypted,
                                    updatedAt = System.currentTimeMillis()
                                ) ?: BrainItem(
                                    title = title.trim(),
                                    content = content.trim(),
                                    lobeType = selectedLobe.id,
                                    category = category.trim().ifBlank { selectedLobe.title },
                                    tags = tags.trim(),
                                    photoUri = selectedPhotoPreset,
                                    importance = importance,
                                    emotionLevel = emotionLevel.toInt(),
                                    isEncrypted = isEncrypted
                                )
                                onSave(itemToSave)
                            }
                        },
                        enabled = title.isNotBlank() && content.isNotBlank(),
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanNeon,
                            contentColor = Color.Black
                        )
                    ) {
                        Text(
                            text = if (initialItem == null) "Memorizza Sinapsi" else "Aggiorna Sinapsi",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
