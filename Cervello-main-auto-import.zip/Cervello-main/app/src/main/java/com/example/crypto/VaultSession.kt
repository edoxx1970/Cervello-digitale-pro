package com.example.crypto

import javax.crypto.SecretKey

/**
 * Tiene la chiave AES-256 del Caveau Neurale SOLO in RAM, per tutta la durata in
 * cui il caveau resta sbloccato. Non viene mai scritta su disco in chiaro:
 * - viene derivata dal PIN via PBKDF2 al momento dello sblocco (verifyAndUnlockVault)
 * - viene azzerata quando il caveau o l'app si bloccano
 *
 * Prima di questa modifica, "isVaultUnlocked" era solo un booleano di UI: i
 * contenuti marcati come cifrati (isEncrypted = true) venivano comunque salvati
 * in chiaro nel database Room. Ora BrainRepository usa questa sessione per
 * cifrare/decifrare davvero il campo `content` degli elementi del caveau.
 */
class VaultSession {
    var key: SecretKey? = null
        private set

    val isUnlocked: Boolean get() = key != null

    fun set(newKey: SecretKey) {
        key = newKey
    }

    fun clear() {
        key = null
    }
}
