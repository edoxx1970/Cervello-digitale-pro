package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.BrainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AutoIngestScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isEnabled by viewModel.isAutoIngestEnabled.collectAsState()
    val imagesEnabled by viewModel.isAutoIngestImagesEnabled.collectAsState()
    val docsEnabled by viewModel.isAutoIngestDocsEnabled.collectAsState()
    val importedCount by viewModel.autoIngestImportedCount.collectAsState()
    val recentScans by viewModel.autoIngestRecentScans.collectAsState()
    val isManualScanRunning by viewModel.isManualScanRunning.collectAsState()

    var hasMediaPermission by remember { mutableStateOf(hasMediaPermission(context)) }
    var hasAllFilesAccess by remember { mutableStateOf(viewModel.hasAllFilesAccess()) }

    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { hasMediaPermission = hasMediaPermission(context) }

    val allFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { hasAllFilesAccess = viewModel.hasAllFilesAccess() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Acquisizione Automatica",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = "Il Cervello osserva foto e documenti del dispositivo e li trasforma in nuove memorie, in background.",
                fontSize = 12.5.sp,
                color = TextSecondary
            )
        }

        // Interruttore generale
        item {
            SettingsCard(borderColor = if (isEnabled) EmeraldNeon else SurfaceCardBorder) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Scansione automatica",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Ogni ~6 ore, se connesso e con batteria sufficiente",
                            fontSize = 11.5.sp,
                            color = TextMuted
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { viewModel.setAutoIngestEnabled(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = EmeraldNeon)
                    )
                }
            }
        }

        // Permessi
        item {
            SettingsCard {
                Text(
                    text = "Permessi richiesti",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))

                PermissionRow(
                    icon = Icons.Default.Photo,
                    label = "Foto e video (Galleria)",
                    granted = hasMediaPermission,
                    actionLabel = "Concedi",
                    onAction = { mediaPermissionLauncher.launch(mediaPermissionsArray()) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                PermissionRow(
                    icon = Icons.Default.Description,
                    label = "Accesso a tutti i file (documenti)",
                    granted = hasAllFilesAccess,
                    actionLabel = "Concedi",
                    onAction = {
                        val intent = allFilesAccessIntent(context)
                        allFilesLauncher.launch(intent)
                    }
                )

                if (!hasAllFilesAccess) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Senza questo permesso i documenti (PDF, testo) non vengono scansionati: resta attiva solo l'acquisizione foto.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Cosa includere
        item {
            SettingsCard {
                Text(
                    text = "Cosa includere",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                ToggleRow(
                    label = "Foto e video della galleria",
                    checked = imagesEnabled,
                    onCheckedChange = { viewModel.setAutoIngestImagesEnabled(it) }
                )
                Spacer(modifier = Modifier.height(6.dp))
                ToggleRow(
                    label = "Documenti (PDF, testo)",
                    checked = docsEnabled,
                    onCheckedChange = { viewModel.setAutoIngestDocsEnabled(it) }
                )
            }
        }

        // Stato / scansione manuale
        item {
            SettingsCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$importedCount memorie acquisite finora",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        val lastRun = viewModel.getLastAutoIngestRunMillis()
                        Text(
                            text = if (lastRun > 0) "Ultima scansione: ${formatTimestamp(lastRun)}" else "Nessuna scansione eseguita ancora",
                            fontSize = 11.5.sp,
                            color = TextMuted
                        )
                    }
                    Button(
                        onClick = { viewModel.triggerManualIngestScan() },
                        enabled = !isManualScanRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (isManualScanRunning) "Avviata..." else "Scansiona ora",
                            color = androidx.compose.ui.graphics.Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Elementi recenti
        if (recentScans.isNotEmpty()) {
            item {
                Text(
                    text = "Attività recente",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            }
            items(recentScans) { entry ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceCard)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (entry.status == "IMPORTED") Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (entry.status == "IMPORTED") EmeraldNeon else TextMuted,
                        modifier = Modifier.height(18.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = entry.fileName, fontSize = 12.5.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(text = statusLabel(entry.status), fontSize = 10.5.sp, color = TextMuted)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun SettingsCard(
    borderColor: androidx.compose.ui.graphics.Color = SurfaceCardBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceCard)
            .border(1.dp, borderColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column { content() }
    }
}

@Composable
private fun PermissionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.height(18.dp))
            Text(text = label, fontSize = 12.5.sp, color = TextPrimary)
        }

        if (granted) {
            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Concesso", tint = EmeraldNeon)
        } else {
            OutlinedButton(onClick = onAction, shape = RoundedCornerShape(8.dp)) {
                Text(text = actionLabel, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.5.sp, color = TextPrimary)
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedTrackColor = CyanNeon))
    }
}

private fun statusLabel(status: String): String = when (status) {
    "IMPORTED" -> "Acquisito come nuova memoria"
    "SKIPPED_TOO_LARGE" -> "Saltato: file troppo grande"
    "SKIPPED_UNSUPPORTED" -> "Saltato: formato non supportato"
    "ERROR" -> "Errore durante l'analisi"
    else -> status
}

private fun formatTimestamp(millis: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALIAN)
    return sdf.format(Date(millis))
}

private fun hasMediaPermission(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

private fun mediaPermissionsArray(): Array<String> {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

private fun allFilesAccessIntent(context: android.content.Context): Intent {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
            data = Uri.parse("package:${context.packageName}")
        }
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
    }
}
