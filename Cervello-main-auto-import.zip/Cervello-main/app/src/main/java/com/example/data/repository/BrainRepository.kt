package com.example.data.repository

import com.example.crypto.CryptoEngine
import com.example.crypto.VaultSession
import com.example.data.db.BrainDao
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class BrainRepository(
    private val brainDao: BrainDao,
    private val vaultSession: VaultSession
) {
    companion object {
        // Prefisso che distingue un contenuto realmente cifrato con questa versione
        // dell'app da un vecchio elemento marcato isEncrypted=true ma salvato ancora
        // in chiaro (dati demo/seed o dati creati prima di questo aggiornamento).
        // Senza questo marcatore non sapremmo distinguere "chiave sbagliata" da
        // "contenuto legacy non ancora migrato".
        private const val ENC_PREFIX = "ENCv1:"
        const val VAULT_LOCKED_PLACEHOLDER = "🔒 Contenuto cifrato — sblocca il Caveau Neurale per leggerlo."
        private const val VAULT_UNDECIPHERABLE_PLACEHOLDER = "🔒 Impossibile decifrare questo contenuto con la chiave attuale."
    }

    /**
     * Cifra il campo `content` prima di salvarlo, solo per elementi marcati
     * isEncrypted = true, usando la chiave di sessione del caveau (mai persistita
     * in chiaro). Se il caveau è bloccato, il salvataggio viene rifiutato invece
     * di scrivere il contenuto in chiaro per errore.
     */
    private fun encryptForStorage(item: BrainItem): BrainItem {
        if (!item.isEncrypted) return item
        val key = vaultSession.key
            ?: throw IllegalStateException("Sblocca il Caveau Neurale col PIN prima di salvare un contenuto cifrato.")
        return item.copy(content = ENC_PREFIX + CryptoEngine.encryptWithKey(item.content, key))
    }

    /**
     * Decifra il campo `content` per la visualizzazione. Gestisce tre casi:
     * 1. Elemento non cifrato -> restituito così com'è.
     * 2. Elemento cifrato ma caveau bloccato -> placeholder, mai il ciphertext grezzo.
     * 3. Elemento cifrato, caveau sbloccato -> decifrato con la chiave di sessione.
     * Il contenuto legacy (isEncrypted=true ma senza prefisso ENCv1, es. dati demo
     * creati prima di questa modifica) viene mostrato invariato per compatibilità:
     * verrà cifrato per davvero al primo salvataggio/modifica successivo.
     */
    private fun decryptForDisplay(item: BrainItem): BrainItem {
        if (!item.isEncrypted) return item
        val raw = item.content
        if (!raw.startsWith(ENC_PREFIX)) return item
        val key = vaultSession.key ?: return item.copy(content = VAULT_LOCKED_PLACEHOLDER)
        val cipherPart = raw.removePrefix(ENC_PREFIX)
        return CryptoEngine.decryptWithKey(cipherPart, key).fold(
            onSuccess = { item.copy(content = it) },
            onFailure = { item.copy(content = VAULT_UNDECIPHERABLE_PLACEHOLDER) }
        )
    }

    private fun Flow<List<BrainItem>>.decryptingEach(): Flow<List<BrainItem>> =
        this.map { list -> list.map { decryptForDisplay(it) } }

    val allItems: Flow<List<BrainItem>> = brainDao.getAllItems().decryptingEach()
    val allCategories: Flow<List<String>> = brainDao.getAllCategories()
    val visualMemories: Flow<List<BrainItem>> = brainDao.getVisualMemories().decryptingEach()
    val totalCount: Flow<Int> = brainDao.getItemsCount()

    fun getItemsByLobe(lobe: BrainLobe): Flow<List<BrainItem>> {
        return brainDao.filterItems(lobe.id, null, null, null).decryptingEach()
    }

    fun getItemsByCategory(category: String): Flow<List<BrainItem>> {
        return brainDao.getItemsByCategory(category).decryptingEach()
    }

    fun getItemsByTag(tag: String): Flow<List<BrainItem>> {
        return brainDao.getItemsByTag(tag).decryptingEach()
    }

    fun filter(lobe: BrainLobe?, category: String?, tag: String?, query: String?): Flow<List<BrainItem>> {
        return brainDao.filterItems(lobe?.id, category, tag, query).decryptingEach()
    }

    fun search(query: String): Flow<List<BrainItem>> {
        // NB: la ricerca full-text lato SQL opera sulla colonna `content` grezza.
        // Per gli elementi del caveau, quella colonna ora contiene ciphertext, quindi
        // una query non troverà più corrispondenze nel testo cifrato (solo in
        // titolo/categoria/tag). È il comportamento corretto per dati davvero
        // cifrati, ma è un cambio visibile rispetto a prima: vale la pena saperlo.
        return brainDao.searchItems(query).decryptingEach()
    }

    suspend fun getItemById(id: Long): BrainItem? = withContext(Dispatchers.IO) {
        brainDao.getItemById(id)?.let { decryptForDisplay(it) }
    }

    suspend fun insert(item: BrainItem): Long = withContext(Dispatchers.IO) {
        brainDao.insertItem(encryptForStorage(item))
    }

    suspend fun update(item: BrainItem) = withContext(Dispatchers.IO) {
        brainDao.updateItem(encryptForStorage(item).copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun delete(item: BrainItem) = withContext(Dispatchers.IO) {
        brainDao.deleteItem(item)
    }

    suspend fun deleteById(id: Long) = withContext(Dispatchers.IO) {
        brainDao.deleteItemById(id)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        brainDao.deleteAll()
    }

    /**
     * Seeds initial memories and data representing a rich Digital Brain Clone
     * if the database is currently empty.
     */
    suspend fun seedInitialBrainDataIfEmpty() = withContext(Dispatchers.IO) {
        val currentItems = brainDao.getAllItems().first()
        if (currentItems.isNotEmpty()) return@withContext

        val initialBrainNodes = listOf(
            // Lobo Frontale: Decisioni, Obiettivi & Valori
            BrainItem(
                title = "Visione & Principi Guida Fondamentali",
                content = "1. Chiarezza di pensiero prima dell'azione.\n2. Curiosità instancabile verso le nuove tecnologie e l'Intelligenza Artificiale.\n3. Proteggere sempre la privacy e la sovranità dei dati personali con crittografia forte.\n4. Mantenere l'equilibrio tra salute fisica, crescita mentale e relazioni autentiche.",
                lobeType = BrainLobe.FRONTAL.id,
                category = "Filosofia di Vita",
                tags = "valori,principi,visione,focus",
                importance = 5,
                emotionLevel = 90,
                synapticLinks = "decisioni,etica,obiettivi"
            ),
            BrainItem(
                title = "Obiettivo Strategico: Padronanza AI & Architetture Cloud",
                content = "Entro fine anno: approfondire modelli di Machine Learning on-device, architetture crittografiche zero-knowledge e automazioni intelligenti per moltiplicare la produttività personale.",
                lobeType = BrainLobe.FRONTAL.id,
                category = "Obiettivo 2026",
                tags = "carriera,ai,studio,progetti",
                importance = 5,
                emotionLevel = 85,
                synapticLinks = "competenze,tecnologia"
            ),
            BrainItem(
                title = "Protocollo Decisionale per Grandi Scelte",
                content = "Regola del 10/10/10: Come influirà questa scelta tra 10 minuti? Tra 10 mesi? Tra 10 anni? Valutare sempre il costo opportunità e se l'azione è allineata ai valori del Lobo Frontale.",
                lobeType = BrainLobe.FRONTAL.id,
                category = "Framework Mentali",
                tags = "strategia,decisioni,logica",
                importance = 4,
                emotionLevel = 70,
                synapticLinks = "principi,logica"
            ),

            // Lobo Temporale: Memorie & Storie Autobiografiche
            BrainItem(
                title = "Ricordo del Viaggio in Giappone: Il Tempio di Kyoto all'Alba",
                content = "Quella mattina d'autunno a Kyoto: il silenzio nel giardino zen, i colori rossi e dorati degli aceri, e quella sensazione di pace profonda che mi ha ricordato quanto sia importante fermarsi a contemplare.",
                lobeType = BrainLobe.TEMPORAL.id,
                category = "Viaggi Indimenticabili",
                tags = "kyoto,giappone,viaggi,pace",
                photoUri = "preset_japan",
                importance = 5,
                emotionLevel = 95,
                synapticLinks = "emozioni,viaggi,natura"
            ),
            BrainItem(
                title = "La Prima Linea di Codice Funzionante",
                content = "La notte in cui per la prima volta un programma scritto da me ha compilato senza errori ed eseguito l'algoritmo atteso. L'emozione pura della creazione dal nulla attraverso la logica.",
                lobeType = BrainLobe.TEMPORAL.id,
                category = "Momenti Chiave",
                tags = "passione,coding,inizio,nostalgia",
                importance = 4,
                emotionLevel = 88,
                synapticLinks = "competenze,tecnologia"
            ),
            BrainItem(
                title = "Tradizione Familiare della Domenica",
                content = "Il pranzo della domenica insieme, le risate a tavola, la ricetta speciale della pasta fatta in casa e il profumo del caffè appena fatto con la moka. Radici e calore.",
                lobeType = BrainLobe.TEMPORAL.id,
                category = "Famiglia & Relazioni",
                tags = "famiglia,casa,tradizioni,affetti",
                importance = 5,
                emotionLevel = 98,
                synapticLinks = "radici,affetti"
            ),

            // Lobo Parietale: Conoscenze & Competenze
            BrainItem(
                title = "Architetture Moderne: Kotlin Coroutines & Clean Architecture",
                content = "Pattern Repository con Flow reattivi, separazione netta tra Data Layer, Domain e UI Layer. Gestione rigorosa dello stato immutabile e StateFlow per prevenire race conditions.",
                lobeType = BrainLobe.PARIETAL.id,
                category = "Sviluppo Software",
                tags = "kotlin,compose,architettura,pattern",
                importance = 4,
                emotionLevel = 60,
                synapticLinks = "tecnologia,studio"
            ),
            BrainItem(
                title = "Routine di Massima Energia Matutina",
                content = "1. Sveglia ore 06:30 + 500ml acqua con limone\n2. 15 min mobilità e respirazione diaframmatica\n3. 45 min deep work senza notifiche\n4. Colazione proteica e caffè di qualità.",
                lobeType = BrainLobe.PARIETAL.id,
                category = "Biohacking & Salute",
                tags = "routine,energia,focus,salute",
                importance = 4,
                emotionLevel = 75,
                synapticLinks = "abitudini,salute"
            ),
            BrainItem(
                title = "Principi di Crittografia E2EE & Zero-Knowledge",
                content = "AES-256 in modalità GCM fornisce sia riservatezza che integrità autenticata (AEAD). PBKDF2 con salt casuale protegge dalla rainbow table. La chiave non lascia mai il dispositivo locale.",
                lobeType = BrainLobe.PARIETAL.id,
                category = "Sicurezza Informatica",
                tags = "crittografia,aes,e2ee,privacy",
                importance = 5,
                emotionLevel = 80,
                synapticLinks = "sicurezza,caveau"
            ),

            // Lobo Occipitale: Galleria Visiva & Foto
            BrainItem(
                title = "Panorama delle Dolomiti - Trekking Tre Cime",
                content = "Scatto fotografico panoramico al tramonto: le cime rocciose illuminate di rosa (Enrosadira) e la vallata alpina. Promemoria visivo del legame con le montagne.",
                lobeType = BrainLobe.OCCIPITAL.id,
                category = "Fotografie",
                tags = "montagna,natura,foto,dolomiti",
                photoUri = "preset_mountains",
                importance = 4,
                emotionLevel = 90,
                synapticLinks = "viaggi,natura"
            ),
            BrainItem(
                title = "Schema Mappa Mentale: Struttura Cervello Digitale",
                content = "Diagramma ad albero dei 5 lobi cerebrali con connessioni sinaptiche e nodi di sincronizzazione crittografica verso i dispositivi remoti.",
                lobeType = BrainLobe.OCCIPITAL.id,
                category = "Schemi & Mappe",
                tags = "schema,mappa,brain,progetto",
                photoUri = "preset_neural_map",
                importance = 4,
                emotionLevel = 70,
                synapticLinks = "visione,progetto"
            ),

            // Caveau Neurale (E2EE Vault)
            BrainItem(
                title = "Credenziali Chiave Server & Master Seeds",
                content = "Master Seed di recupero: [ENCRYPTED_VAULT_NODE]\nChiave SSH Primaria: ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAI...\nServer Backup Port: 22022 (IP riservato protetto da VPN WireGuard).",
                lobeType = BrainLobe.NEURAL_VAULT.id,
                category = "Sicurezza Personale",
                tags = "password,ssh,seed,chiavi",
                importance = 5,
                emotionLevel = 60,
                synapticLinks = "sicurezza,crittografia",
                isEncrypted = true
            ),
            BrainItem(
                title = "Note Riservate & Accordi Finanziari",
                content = "Portafoglio investimenti e piano d'emergenza familiare: documento custodito sotto crittografia simmetrica AES-256.",
                lobeType = BrainLobe.NEURAL_VAULT.id,
                category = "Finanze & Riservato",
                tags = "finanze,segreto,vault,documenti",
                importance = 5,
                emotionLevel = 70,
                synapticLinks = "caveau,finanze",
                isEncrypted = true
            )
        )

        brainDao.insertItems(initialBrainNodes)
    }

    /**
     * Exports all brain items into an E2EE encrypted JSON payload string.
     */
    suspend fun exportEncryptedBackup(passphrase: String): String = withContext(Dispatchers.IO) {
        val items = brainDao.getAllItems().first()
        val rootJson = JSONObject()
        rootJson.put("version", "2.0")
        rootJson.put("exportedAt", System.currentTimeMillis())
        rootJson.put("nodeCount", items.size)

        val array = JSONArray()
        for (item in items) {
            val itemObj = JSONObject()
            itemObj.put("title", item.title)
            itemObj.put("content", item.content)
            itemObj.put("lobeType", item.lobeType)
            itemObj.put("category", item.category)
            itemObj.put("tags", item.tags)
            itemObj.put("photoUri", item.photoUri ?: "")
            itemObj.put("importance", item.importance)
            itemObj.put("emotionLevel", item.emotionLevel)
            itemObj.put("synapticLinks", item.synapticLinks)
            itemObj.put("createdAt", item.createdAt)
            itemObj.put("isEncrypted", item.isEncrypted)
            array.put(itemObj)
        }
        rootJson.put("memories", array)

        val plainJsonString = rootJson.toString()
        CryptoEngine.encrypt(plainJsonString, passphrase)
    }

    /**
     * Imports an E2EE encrypted JSON payload string into the database.
     */
    suspend fun importEncryptedBackup(encryptedPayload: String, passphrase: String): Result<Int> = withContext(Dispatchers.IO) {
        val decryptResult = CryptoEngine.decrypt(encryptedPayload, passphrase)
        if (decryptResult.isFailure) {
            return@withContext Result.failure(Exception("Passphrase non valida o archivio corrotto"))
        }

        try {
            val plainJson = decryptResult.getOrThrow()
            val rootJson = JSONObject(plainJson)
            val array = rootJson.getJSONArray("memories")
            val importedList = mutableListOf<BrainItem>()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val item = BrainItem(
                    title = obj.getString("title"),
                    content = obj.getString("content"),
                    lobeType = obj.optString("lobeType", BrainLobe.FRONTAL.id),
                    category = obj.optString("category", "Importati"),
                    tags = obj.optString("tags", ""),
                    photoUri = obj.optString("photoUri").takeIf { it.isNotBlank() },
                    importance = obj.optInt("importance", 3),
                    emotionLevel = obj.optInt("emotionLevel", 50),
                    synapticLinks = obj.optString("synapticLinks", ""),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                    isEncrypted = obj.optBoolean("isEncrypted", false)
                )
                importedList.add(item)
            }

            brainDao.insertItems(importedList)
            Result.success(importedList.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
