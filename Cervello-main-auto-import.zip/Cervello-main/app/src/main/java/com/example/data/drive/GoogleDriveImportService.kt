package com.example.data.drive

import android.content.Context
import android.net.Uri
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DriveFileItem(
    val id: String,
    val name: String,
    val mimeType: String,
    val modifiedTime: String,
    val size: Long = 0,
    val isFolder: Boolean = false,
    val iconType: String = "doc"
)

data class ImportedMemoryPreview(
    val title: String,
    val content: String,
    val targetLobe: BrainLobe,
    val category: String,
    val tags: List<String>,
    val sourceName: String,
    val sourceService: String = "Google Drive"
)

class GoogleDriveImportService(
    private val context: Context,
    private val httpClient: OkHttpClient = OkHttpClient()
) {

    /**
     * Lists files from Google Drive API given a valid OAuth2 Bearer Token.
     */
    suspend fun listDriveFiles(accessToken: String): Result<List<DriveFileItem>> = withContext(Dispatchers.IO) {
        try {
            val query = "trashed = false and (mimeType = 'application/vnd.google-apps.document' or mimeType = 'text/plain' or mimeType = 'text/markdown' or mimeType = 'application/json' or mimeType = 'application/pdf' or mimeType = 'application/vnd.google-apps.spreadsheet')"
            val url = "https://www.googleapis.com/drive/v3/files?q=${android.net.Uri.encode(query)}&pageSize=25&fields=files(id,name,mimeType,modifiedTime,size)&orderBy=modifiedTime%20desc"

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                return@withContext Result.failure(Exception("Drive API error ${response.code}: $errBody"))
            }

            val body = response.body?.string() ?: "{}"
            val json = JSONObject(body)
            val filesArray = json.optJSONArray("files") ?: JSONArray()
            val list = mutableListOf<DriveFileItem>()

            for (i in 0 until filesArray.length()) {
                val f = filesArray.getJSONObject(i)
                val mime = f.optString("mimeType", "")
                val icon = when {
                    mime.contains("document") -> "doc"
                    mime.contains("spreadsheet") -> "sheet"
                    mime.contains("pdf") -> "pdf"
                    else -> "text"
                }
                list.add(
                    DriveFileItem(
                        id = f.getString("id"),
                        name = f.optString("name", "Documento senza titolo"),
                        mimeType = mime,
                        modifiedTime = f.optString("modifiedTime", ""),
                        size = f.optLong("size", 0L),
                        iconType = icon
                    )
                )
            }

            Result.success(list)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    /**
     * Downloads file content or exports Google Docs to plain text.
     */
    suspend fun fetchFileContent(accessToken: String, file: DriveFileItem): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = if (file.mimeType == "application/vnd.google-apps.document") {
                // Export Google Docs as Plain Text
                "https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/plain"
            } else {
                // Direct download for txt/md/json
                "https://www.googleapis.com/drive/v3/files/${file.id}?alt=media"
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Download failed with HTTP ${response.code}"))
            }

            val text = response.body?.string() ?: ""
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Reads local files (TXT, MD, JSON, CSV, PDF, Notes) selected via Android Storage Access Framework (SAF).
     */
    suspend fun readLocalFileContent(uri: Uri): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val fileName = getFileNameFromUri(uri) ?: "file_importato.txt"

            val stringBuilder = StringBuilder()
            contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    var line = reader.readLine()
                    while (line != null) {
                        stringBuilder.appendLine(line)
                        line = reader.readLine()
                    }
                }
            }

            Result.success(Pair(fileName, stringBuilder.toString()))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var name: String? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) {
                    name = cursor.getString(nameIndex)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return name ?: uri.lastPathSegment
    }
}
