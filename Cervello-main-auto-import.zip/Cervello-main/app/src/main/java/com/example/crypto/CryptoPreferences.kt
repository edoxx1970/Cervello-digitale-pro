package com.example.crypto

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class CryptoPreferences(context: Context) {
    // In precedenza queste preferenze (hash del PIN, PIN di pairing remoto, token
    // OAuth di Google Drive...) venivano salvate con getSharedPreferences() normali,
    // cioè in chiaro in un XML leggibile da chiunque abbia accesso root/backup del
    // dispositivo — in forte contraddizione con il resto dell'app che si presenta
    // come "E2EE". Ora il file è cifrato con una chiave gestita da Android Keystore
    // tramite EncryptedSharedPreferences.
    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "brain_crypto_vault_prefs_enc",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback difensivo: se il Keystore non è disponibile (es. alcuni emulatori)
        // non blocchiamo l'app, ma logghiamo l'evento: non dovrebbe accadere su un
        // dispositivo reale con API 23+.
        Log.e("CryptoPreferences", "EncryptedSharedPreferences non disponibile, fallback a prefs non cifrate", e)
        context.getSharedPreferences("brain_crypto_vault_prefs", Context.MODE_PRIVATE)
    }

    companion object {
        private const val KEY_MASTER_PIN_HASH = "master_pin_hash"
        private const val KEY_MASTER_PASSPHRASE_HINT = "master_passphrase_hint"
        private const val KEY_IS_INITIALIZED = "is_vault_initialized"
        private const val KEY_APP_LOCK_ENABLED = "app_lock_enabled"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_REMOTE_PIN = "remote_pairing_pin"
        private const val KEY_CLONE_NAME = "clone_name"
        private const val KEY_DRIVE_OAUTH_TOKEN = "drive_oauth_token"
        private const val KEY_VAULT_SALT = "vault_key_salt"
        private const val KEY_WRAPPED_VAULT_KEY = "vault_key_wrapped_for_biometrics"
        private const val KEY_SYSTEM_DATA_SALT = "system_data_key_salt"
        private const val KEY_AUTO_INGEST_ENABLED = "auto_ingest_enabled"
        private const val KEY_AUTO_INGEST_LAST_RUN = "auto_ingest_last_run"
        private const val KEY_AUTO_INGEST_IMAGES = "auto_ingest_images_enabled"
        private const val KEY_AUTO_INGEST_DOCS = "auto_ingest_docs_enabled"
        private const val DEFAULT_PIN = "2026"
    }

    /**
     * Interruttore generale dell'Auto-Import (scansione periodica in background
     * di galleria/documenti). Spento di default: va attivato esplicitamente
     * dall'utente dalla schermata "Acquisizione" dopo aver concesso i permessi.
     */
    var isAutoIngestEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_INGEST_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_INGEST_ENABLED, value).apply()

    var isAutoIngestImagesEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_INGEST_IMAGES, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_INGEST_IMAGES, value).apply()

    var isAutoIngestDocsEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_INGEST_DOCS, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_INGEST_DOCS, value).apply()

    var lastAutoIngestRunMillis: Long
        get() = prefs.getLong(KEY_AUTO_INGEST_LAST_RUN, 0L)
        set(value) = prefs.edit().putLong(KEY_AUTO_INGEST_LAST_RUN, value).apply()

    var isInitialized: Boolean
        get() = prefs.getBoolean(KEY_IS_INITIALIZED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_INITIALIZED, value).apply()

    var isAppLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_APP_LOCK_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_APP_LOCK_ENABLED, value).apply()

    var masterPinHash: String
        get() = prefs.getString(KEY_MASTER_PIN_HASH, CryptoEngine.sha256(DEFAULT_PIN)) ?: CryptoEngine.sha256(DEFAULT_PIN)
        set(value) = prefs.edit().putString(KEY_MASTER_PIN_HASH, value).apply()

    var passphraseHint: String
        get() = prefs.getString(KEY_MASTER_PASSPHRASE_HINT, "PIN predefinito: 2026") ?: "PIN predefinito: 2026"
        set(value) = prefs.edit().putString(KEY_MASTER_PASSPHRASE_HINT, value).apply()

    var isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, value).apply()

    var remotePairingPin: String
        get() = prefs.getString(KEY_REMOTE_PIN, "849201") ?: "849201"
        set(value) = prefs.edit().putString(KEY_REMOTE_PIN, value).apply()

    var cloneName: String
        get() = prefs.getString(KEY_CLONE_NAME, "Alfredo Brain Clone") ?: "Alfredo Brain Clone"
        set(value) = prefs.edit().putString(KEY_CLONE_NAME, value).apply()

    var driveOAuthToken: String
        get() = prefs.getString(KEY_DRIVE_OAUTH_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_DRIVE_OAUTH_TOKEN, value).apply()

    /**
     * Salt fisso per-installazione usato per derivare la chiave AES del Caveau
     * Neurale dal PIN via PBKDF2. Creato al primo utilizzo e poi riusato sempre:
     * cambiarlo invaliderebbe tutti i contenuti già cifrati con la chiave derivata
     * dal salt precedente.
     */
    val vaultKeySaltBase64: String
        get() {
            val existing = prefs.getString(KEY_VAULT_SALT, null)
            if (existing != null) return existing
            val newSalt = android.util.Base64.encodeToString(CryptoEngine.generateSalt(), android.util.Base64.NO_WRAP)
            prefs.edit().putString(KEY_VAULT_SALT, newSalt).apply()
            return newSalt
        }

    /**
     * Chiave del caveau cifrata (wrapped) con la chiave Keystore, per permettere
     * lo sblocco biometrico senza richiedere il PIN ogni volta. Vuota finché
     * l'utente non ha sbloccato almeno una volta col PIN dopo questo aggiornamento.
     */
    var wrappedVaultKey: String
        get() = prefs.getString(KEY_WRAPPED_VAULT_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_WRAPPED_VAULT_KEY, value).apply()

    /**
     * Salt per-installazione per derivare UNA VOLTA la chiave "di sistema" usata
     * da foto cifrate e cronologia chat (masterPinHash, già ad alta entropia,
     * come input). Prima di questa modifica ogni singola foto o messaggio veniva
     * cifrato/decifrato rifacendo da capo l'intera derivazione PBKDF2 (costosa,
     * soprattutto dopo l'aumento a 600.000 iterazioni): con una galleria di più
     * foto o una chat lunga, l'app sarebbe diventata lentissima o si sarebbe
     * bloccata. Con questo salt fisso, EncryptedPhotoStorage e ChatRepository
     * derivano la chiave una sola volta e poi la riusano.
     */
    val systemDataKeySaltBase64: String
        get() {
            val existing = prefs.getString(KEY_SYSTEM_DATA_SALT, null)
            if (existing != null) return existing
            val newSalt = android.util.Base64.encodeToString(CryptoEngine.generateSalt(), android.util.Base64.NO_WRAP)
            prefs.edit().putString(KEY_SYSTEM_DATA_SALT, newSalt).apply()
            return newSalt
        }

    fun verifyPin(pin: String): Boolean {
        return CryptoEngine.sha256(pin) == masterPinHash
    }

    fun setMasterPin(newPin: String, hint: String = "") {
        masterPinHash = CryptoEngine.sha256(newPin)
        passphraseHint = hint
        isInitialized = true
    }

    fun regenerateRemotePin(): String {
        val newPin = CryptoEngine.generatePairingPin()
        remotePairingPin = newPin
        return newPin
    }
}
