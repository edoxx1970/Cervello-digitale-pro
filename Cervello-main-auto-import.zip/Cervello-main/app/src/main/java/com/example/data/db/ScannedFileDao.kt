package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ScannedFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ScannedFileDao {
    @Query("SELECT uriString FROM scanned_files")
    suspend fun getAllScannedUris(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ScannedFileEntity)

    @Query("SELECT COUNT(*) FROM scanned_files WHERE status = 'IMPORTED'")
    fun getImportedCount(): Flow<Int>

    @Query("SELECT * FROM scanned_files ORDER BY processedAt DESC LIMIT :limit")
    fun getRecent(limit: Int = 20): Flow<List<ScannedFileEntity>>

    @Query("DELETE FROM scanned_files")
    suspend fun clearAll()
}
