package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "brain_items")
data class BrainItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val lobeType: String, // FRONTAL, TEMPORAL, PARIETAL, OCCIPITAL, NEURAL_VAULT
    val category: String, // es. "Principi", "Obiettivo 2026", "Viaggi", "Tech", "Finanze", "Salute"
    val tags: String = "", // Comma-separated tags, es. "ia,futuro,focus"
    val photoUri: String? = null, // URI locale o identificativo immagine
    val importance: Int = 3, // 1 to 5
    val emotionLevel: Int = 50, // 0 to 100%
    val synapticLinks: String = "", // Link ad altre categorie o concetti
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isEncrypted: Boolean = false
) {
    fun getTagsList(): List<String> {
        if (tags.isBlank()) return emptyList()
        return tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun getLobe(): BrainLobe {
        return BrainLobe.fromId(lobeType)
    }
}
