package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity for storing encrypted chat messages in Room database.
 * The message payload is stored as an AES-256-GCM encrypted ciphertext with PBKDF2 key derivation.
 */
@Entity(tableName = "encrypted_chat_messages")
data class EncryptedChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "USER" or "CLONE"
    val encryptedPayload: String, // Base64 encoded AES-256-GCM ciphertext
    val timestamp: Long = System.currentTimeMillis(),
    val modelName: String = "gemini-3.5-flash",
    val isProtected: Boolean = true
)
