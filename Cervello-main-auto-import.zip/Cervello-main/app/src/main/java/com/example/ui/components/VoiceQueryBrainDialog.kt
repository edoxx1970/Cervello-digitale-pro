package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.audio.SpeechState
import com.example.audio.SpeechToTextManager
import com.example.audio.TextToSpeechManager
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceQueryBrainDialog(
    initialQuery: String = "",
    isQueryLoading: Boolean,
    aiAnswer: String?,
    matchedMemories: List<BrainItem>,
    onQuerySubmit: (String) -> Unit,
    onOpenMemoryDetail: (BrainItem) -> Unit,
    onNavigateToChat: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val speechManager = remember { SpeechToTextManager(context) }
    val ttsManager = remember { TextToSpeechManager(context) }

    val speechState by speechManager.speechState.collectAsState()
    val transcribedText by speechManager.transcribedText.collectAsState()
    val partialText by speechManager.partialText.collectAsState()
    val audioRmsDb by speechManager.audioRmsDb.collectAsState()
    val isTtsSpeaking by ttsManager.isSpeaking.collectAsState()

    var inputQuery by remember { mutableStateOf(initialQuery) }
    var selectedLang by remember { mutableStateOf("it-IT") }
    var autoSpeakAnswer by remember { mutableStateOf(true) }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            speechManager.selectedLanguage = selectedLang
            speechManager.startListening()
        }
    }

    // Auto-readout when new AI answer arrives
    LaunchedEffect(aiAnswer) {
        if (!aiAnswer.isNullOrBlank() && autoSpeakAnswer) {
            ttsManager.speak(aiAnswer, selectedLang)
        }
    }

    // When voice recognition finalizes, update text and automatically submit query
    LaunchedEffect(transcribedText) {
        if (transcribedText.isNotBlank()) {
            inputQuery = transcribedText
            onQuerySubmit(transcribedText)
        }
    }

    // Auto-start listening on open if no initial query
    LaunchedEffect(Unit) {
        if (initialQuery.isBlank()) {
            if (hasAudioPermission) {
                speechManager.selectedLanguage = selectedLang
                speechManager.startListening()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechManager.destroyRecognizer()
            ttsManager.shutdown()
        }
    }

    // Waveform & Pulse Animations
    val infiniteTransition = rememberInfiniteTransition(label = "voice_query_waves")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_pulse"
    )
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val sampleVoiceQueries = listOf(
        "Quali sono i miei obiettivi 2026?",
        "Qual è la mia visione e i miei principi?",
        "Cosa ho annotato riguardo a salute e biohacking?",
        "Mostrami i ricordi nel Lobo Temporale",
        "Quali competenze tecniche ho registrato?"
    )

    Dialog(
        onDismissRequest = {
            speechManager.destroyRecognizer()
            ttsManager.stop()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .imePadding()
                .clip(RoundedCornerShape(24.dp))
                .background(SurfaceCard)
                .border(1.dp, CyanNeon.copy(alpha = 0.6f), RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(CyanNeon.copy(alpha = 0.2f))
                                    .border(1.dp, CyanNeon, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Voice Query",
                                    tint = CyanNeon,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Interrogazione Neurale Vocale",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Chiedi a voce al tuo Cervello Digitale",
                                    fontSize = 11.5.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        IconButton(onClick = {
                            speechManager.destroyRecognizer()
                            ttsManager.stop()
                            onDismiss()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Chiudi",
                                tint = TextSecondary
                            )
                        }
                    }
                }

                // Interactive Pulsing Microphone Visualizer
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(
                                        SurfaceCardElevated,
                                        BackgroundDark
                                    )
                                )
                            )
                            .border(
                                1.dp,
                                if (speechState == SpeechState.LISTENING) CyanNeon else SurfaceCardBorder,
                                RoundedCornerShape(20.dp)
                            )
                            .padding(vertical = 18.dp, horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Pulsing Central Mic Button
                            Box(
                                modifier = Modifier
                                    .size(86.dp)
                                    .scale(if (speechState == SpeechState.LISTENING) (pulseScale + (audioRmsDb * 0.3f)) else 1f)
                                    .clip(CircleShape)
                                    .background(
                                        if (speechState == SpeechState.LISTENING)
                                            Brush.linearGradient(listOf(CyanNeon, VioletNeon))
                                        else
                                            Brush.linearGradient(listOf(SurfaceCardElevated, SurfaceCard))
                                    )
                                    .border(
                                        2.dp,
                                        if (speechState == SpeechState.LISTENING) CyanNeon else SurfaceCardBorder,
                                        CircleShape
                                    )
                                    .clickable {
                                        ttsManager.stop()
                                        if (!hasAudioPermission) {
                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        } else {
                                            if (speechState == SpeechState.LISTENING) {
                                                speechManager.stopListening()
                                            } else {
                                                speechManager.selectedLanguage = selectedLang
                                                speechManager.startListening()
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (speechState == SpeechState.LISTENING) Icons.Default.Mic else Icons.Default.MicOff,
                                    contentDescription = "Mic",
                                    tint = if (speechState == SpeechState.LISTENING) Color.Black else CyanNeon,
                                    modifier = Modifier.size(40.dp)
                                )
                            }

                            // Dynamic Equalizer Frequency Bars
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.height(34.dp)
                            ) {
                                for (i in 0 until 18) {
                                    val dynamicHeight = if (speechState == SpeechState.LISTENING) {
                                        val wave = (sin(wavePhase + i * 0.45f) + 1f) / 2f
                                        val dbFactor = (audioRmsDb * 26.dp.value)
                                        (5.dp.value + (wave * 15.dp.value) + dbFactor).coerceIn(4f, 32f).dp
                                    } else {
                                        4.dp
                                    }

                                    val barColor = when {
                                        speechState == SpeechState.LISTENING -> if (i % 2 == 0) CyanNeon else VioletNeon
                                        else -> TextMuted.copy(alpha = 0.35f)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .width(3.2.dp)
                                            .height(dynamicHeight)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(barColor)
                                    )
                                }
                            }

                            // Status Guide
                            Text(
                                text = when (speechState) {
                                    SpeechState.LISTENING -> "Ascolto attivo... Chiedi qualsiasi informazione!"
                                    SpeechState.PROCESSING -> "Elaborazione domanda vocale..."
                                    SpeechState.ERROR -> speechManager.errorMessage.value ?: "Errore microfono"
                                    else -> "Tocca il microfono per parlare al tuo Cervello"
                                },
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = when (speechState) {
                                    SpeechState.LISTENING -> EmeraldNeon
                                    SpeechState.PROCESSING -> AmberNeon
                                    SpeechState.ERROR -> PinkVault
                                    else -> TextSecondary
                                },
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Real-time Partial Speech Bubble
                if (partialText.isNotBlank()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyanNeon.copy(alpha = 0.12f))
                                .border(1.dp, CyanNeon.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "🗣️ \"$partialText...\"",
                                fontSize = 13.sp,
                                color = CyanNeon,
                                fontStyle = FontStyle.Italic
                            )
                        }
                    }
                }

                // Query Text Field (Spoken or Typed)
                item {
                    OutlinedTextField(
                        value = inputQuery,
                        onValueChange = { inputQuery = it },
                        placeholder = { Text("Es. Quali sono i miei principi o obiettivi?", fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = CyanNeon
                            )
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (inputQuery.isNotBlank()) {
                                        ttsManager.stop()
                                        onQuerySubmit(inputQuery)
                                    }
                                },
                                enabled = inputQuery.isNotBlank() && !isQueryLoading
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Invia",
                                    tint = if (inputQuery.isNotBlank()) CyanNeon else TextMuted
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = SurfaceCardElevated,
                            unfocusedContainerColor = SurfaceCardElevated
                        )
                    )
                }

                // Quick Prompt Suggestion Chips
                if (aiAnswer == null && matchedMemories.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "SUGGERIMENTI VOCALI RAPIDI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMuted,
                                letterSpacing = 0.5.sp
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                sampleVoiceQueries.forEach { prompt ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(SurfaceCardElevated)
                                            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(10.dp))
                                            .clickable {
                                                inputQuery = prompt
                                                ttsManager.stop()
                                                onQuerySubmit(prompt)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = prompt,
                                            fontSize = 11.5.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // AI Neural Synthesis Loading State
                if (isQueryLoading) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(VioletNeon.copy(alpha = 0.1f))
                                .border(1.dp, VioletNeon.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = VioletNeon,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "Interrogazione sinaptica e sintesi Gemini in corso...",
                                    fontSize = 12.5.sp,
                                    color = VioletNeon,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // AI Clone Cognitive Voice Answer Card
                if (!aiAnswer.isNullOrBlank()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            VioletNeon.copy(alpha = 0.18f),
                                            SurfaceCardElevated
                                        )
                                    )
                                )
                                .border(1.dp, VioletNeon, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "AI Answer",
                                            tint = CyanNeon,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "Sintesi Neurale Clone Digitale",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyanNeon
                                        )
                                    }

                                    // Voice Readout Controls
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                if (isTtsSpeaking) {
                                                    ttsManager.stop()
                                                } else {
                                                    ttsManager.speak(aiAnswer, selectedLang)
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (isTtsSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                                contentDescription = "Lettura Vocale",
                                                tint = if (isTtsSpeaking) AmberNeon else CyanNeon,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = aiAnswer,
                                    fontSize = 13.5.sp,
                                    color = TextPrimary,
                                    lineHeight = 19.sp
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            ttsManager.stop()
                                            onNavigateToChat(inputQuery)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Chat,
                                            contentDescription = "Chat",
                                            tint = VioletNeon,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Continua in Chat AI ➔",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VioletNeon
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Matching Brain Memories List Header
                if (matchedMemories.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SINAPSI CORRELATE (${matchedMemories.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Matching Brain Items
                    items(matchedMemories.take(5), key = { it.id }) { item ->
                        val lobe = BrainLobe.entries.find { it.id == item.lobeType } ?: BrainLobe.TEMPORAL

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(SurfaceCardElevated)
                                .border(1.dp, lobe.color.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                .clickable {
                                    ttsManager.stop()
                                    onOpenMemoryDetail(item)
                                }
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(lobe.color)
                                        )
                                        Text(
                                            text = lobe.title,
                                            fontSize = 10.5.sp,
                                            color = lobe.color,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    if (item.isEncrypted) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Encrypted",
                                            tint = PinkVault,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = item.title,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = item.content,
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
