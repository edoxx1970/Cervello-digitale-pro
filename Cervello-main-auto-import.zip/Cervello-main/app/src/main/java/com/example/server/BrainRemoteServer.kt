package com.example.server

import android.content.Context
import com.example.crypto.CryptoEngine
import com.example.crypto.CryptoPreferences
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.data.repository.BrainRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections

class BrainRemoteServer(
    private val context: Context,
    private val repository: BrainRepository,
    private val cryptoPrefs: CryptoPreferences
) {
    private var serverSocket: ServerSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // Sessioni valide emesse da /api/unlock: token -> timestamp di scadenza (ms epoch).
    // Senza questo, chiunque sulla stessa rete Wi-Fi poteva leggere/scrivere le memorie
    // senza mai passare da /api/unlock: le altre rotte non controllavano nulla.
    private val activeSessions = Collections.synchronizedMap(HashMap<String, Long>())
    private val sessionTtlMillis = 30 * 60 * 1000L // 30 minuti

    // Protezione anti-brute-force sul PIN: senza questo, chiunque sulla LAN poteva
    // provare migliaia di PIN al secondo su /api/unlock (un PIN a 4-6 cifre cade in
    // pochi secondi senza limiti). Blocchiamo un IP dopo troppi tentativi falliti.
    private data class AttemptTracker(var failCount: Int = 0, var lockedUntil: Long = 0L)
    private val loginAttempts = Collections.synchronizedMap(HashMap<String, AttemptTracker>())
    private val maxFailedAttempts = 5
    private val lockoutMillis = 2 * 60 * 1000L // 2 minuti di blocco dopo troppi tentativi

    private fun isLockedOut(clientIp: String): Boolean {
        val tracker = loginAttempts[clientIp] ?: return false
        return System.currentTimeMillis() < tracker.lockedUntil
    }

    private fun registerFailedAttempt(clientIp: String) {
        val tracker = loginAttempts.getOrPut(clientIp) { AttemptTracker() }
        tracker.failCount++
        if (tracker.failCount >= maxFailedAttempts) {
            tracker.lockedUntil = System.currentTimeMillis() + lockoutMillis
            tracker.failCount = 0
        }
    }

    private fun registerSuccessfulAttempt(clientIp: String) {
        loginAttempts.remove(clientIp)
    }

    private fun issueSessionToken(): String {
        val raw = ByteArray(32)
        java.security.SecureRandom().nextBytes(raw)
        val token = android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
        activeSessions[token] = System.currentTimeMillis() + sessionTtlMillis
        return token
    }

    private fun isTokenValid(token: String?): Boolean {
        if (token.isNullOrBlank()) return false
        val expiry = activeSessions[token] ?: return false
        if (System.currentTimeMillis() > expiry) {
            activeSessions.remove(token)
            return false
        }
        return true
    }

    private fun extractToken(headers: Map<String, String>, body: String): String? {
        val authHeader = headers["authorization"]
        if (!authHeader.isNullOrBlank() && authHeader.startsWith("Bearer ", ignoreCase = true)) {
            return authHeader.substringAfter(" ").trim()
        }
        return try {
            JSONObject(body).optString("token", "").takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            null
        }
    }

    var isRunning: Boolean = false
        private set

    var port: Int = 8888
        private set

    var connectedClientsCount: Int = 0
        private set

    var lastLogMessage: String = "Server pronto all'avvio"
        private set

    fun startServer(customPort: Int = 8888): Boolean {
        if (isRunning) return true
        port = customPort
        return try {
            serverSocket = ServerSocket(port)
            isRunning = true
            lastLogMessage = "Server attivo su http://${getLocalIpAddress()}:$port"

            scope.launch {
                while (isActive && isRunning) {
                    try {
                        val socket = serverSocket?.accept()
                        socket?.let {
                            scope.launch { handleClient(it) }
                        }
                    } catch (e: Exception) {
                        if (isRunning) e.printStackTrace()
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            lastLogMessage = "Errore avvio server: ${e.localizedMessage}"
            isRunning = false
            false
        }
    }

    fun stopServer() {
        try {
            isRunning = false
            serverSocket?.close()
            serverSocket = null
            lastLogMessage = "Server arrestato"
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val hostAddress = addr.hostAddress ?: ""
                        if (hostAddress.contains('.')) {
                            return hostAddress
                        }
                    }
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return "127.0.0.1"
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.use { s ->
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                val out = s.getOutputStream()

                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return

                val method = parts[0]
                val path = parts[1]

                var contentLength = 0
                val headers = HashMap<String, String>()
                while (true) {
                    val header = reader.readLine()
                    if (header.isNullOrEmpty()) break
                    val sepIndex = header.indexOf(':')
                    if (sepIndex > 0) {
                        headers[header.substring(0, sepIndex).trim().lowercase()] = header.substring(sepIndex + 1).trim()
                    }
                    if (header.startsWith("Content-Length:", ignoreCase = true)) {
                        contentLength = header.substringAfter(":").trim().toIntOrNull() ?: 0
                    }
                }

                val body = if (contentLength > 0) {
                    val chars = CharArray(contentLength)
                    reader.read(chars)
                    String(chars)
                } else ""

                val clientIp = s.inetAddress?.hostAddress ?: "Unknown"

                routeRequest(method, path, body, headers, out, clientIp)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun routeRequest(method: String, path: String, body: String, headers: Map<String, String>, out: OutputStream, clientIp: String) {
        try {
            val pathOnly = path.substringBefore('?')
            val query = path.substringAfter('?', "")
            val queryToken = query.split('&').firstOrNull { it.startsWith("token=") }?.substringAfter("token=")
            val token = extractToken(headers, body) ?: queryToken

            // Ogni rotta che tocca dati o azioni deve avere una sessione valida ottenuta da /api/unlock.
            val protectedRoutes = listOf("/api/memories", "/api/add-memory", "/api/clone-chat", "/api/export")
            if (protectedRoutes.any { pathOnly.startsWith(it) } && !isTokenValid(token)) {
                lastLogMessage = "Accesso remoto negato (token mancante o scaduto) da $clientIp"
                sendJsonResponse(out, 401, "{\"error\":\"Non autorizzato. Esegui prima /api/unlock e usa il token restituito.\"}")
                return
            }

            when {
                pathOnly == "/" || pathOnly.isEmpty() -> handleRoot(out, clientIp, pathOnly)
                pathOnly.startsWith("/api/status") -> handleStatus(out)
                pathOnly.startsWith("/api/unlock") -> handleUnlock(method, body, out, clientIp)
                pathOnly.startsWith("/api/memories") -> handleMemories(out)
                pathOnly.startsWith("/api/add-memory") -> handleAddMemory(method, body, out)
                pathOnly.startsWith("/api/clone-chat") -> handleCloneChat(method, body, out)
                pathOnly.startsWith("/api/export") -> handleExport(body, out, clientIp)
                else -> sendResponse(out, 404, "text/plain", "Not Found")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            sendResponse(out, 500, "text/plain", "Internal Server Error: ${e.message}")
        }
    }

    private fun handleRoot(out: OutputStream, clientIp: String, path: String) {
        lastLogMessage = "Richiesta da $clientIp: $path"
        connectedClientsCount++

        val html = BrainWebPortalHtml.generatePortalHtml(
            cloneName = cryptoPrefs.cloneName,
            ipAddress = getLocalIpAddress(),
            port = port
        )
        sendResponse(out, 200, "text/html; charset=UTF-8", html)
    }

    private fun handleStatus(out: OutputStream) {
        val response = JSONObject().apply {
            put("status", "ONLINE")
            put("cloneName", cryptoPrefs.cloneName)
            put("encryption", "AES-256-GCM + PBKDF2")
            put("version", "2.0")
            put("e2eeEnabled", true)
        }
        sendJsonResponse(out, 200, response.toString())
    }

    private fun handleUnlock(method: String, body: String, out: OutputStream, clientIp: String) {
        if (!method.equals("POST", ignoreCase = true)) {
            sendJsonResponse(out, 405, "{\"error\":\"Method not allowed\"}")
            return
        }

        if (isLockedOut(clientIp)) {
            lastLogMessage = "Blocco anti-brute-force attivo per $clientIp"
            sendJsonResponse(out, 429, "{\"success\":false,\"message\":\"Troppi tentativi falliti. Riprova tra qualche minuto.\"}")
            return
        }

        val json = JSONObject(body)
        val pinOrToken = json.optString("pin", "")

        val isValidPin = cryptoPrefs.verifyPin(pinOrToken)
        val isRemotePin = pinOrToken == cryptoPrefs.remotePairingPin

        if (isValidPin || isRemotePin) {
            registerSuccessfulAttempt(clientIp)
            lastLogMessage = "Accesso E2EE remoto autorizzato con successo"
            val response = JSONObject().apply {
                put("success", true)
                put("message", "Autenticazione E2EE autorizzata")
                put("token", issueSessionToken())
                put("expiresInSeconds", sessionTtlMillis / 1000)
            }
            sendJsonResponse(out, 200, response.toString())
        } else {
            registerFailedAttempt(clientIp)
            lastLogMessage = "Tentativo di accesso remoto fallito (PIN errato) da $clientIp"
            val response = JSONObject().apply {
                put("success", false)
                put("message", "Codice PIN o Passphrase E2EE non valida")
            }
            sendJsonResponse(out, 401, response.toString())
        }
    }

    private fun handleMemories(out: OutputStream) {
        runBlocking {
            val items = repository.allItems.first()
            val jsonArray = JSONArray()
            for (item in items) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("content", item.content)
                    put("lobeType", item.lobeType)
                    put("category", item.category)
                    put("tags", item.tags)
                    put("photoUri", item.photoUri ?: "")
                    put("importance", item.importance)
                    put("emotionLevel", item.emotionLevel)
                    put("synapticLinks", item.synapticLinks)
                    put("createdAt", item.createdAt)
                    put("isEncrypted", item.isEncrypted)
                }
                jsonArray.put(obj)
            }
            sendJsonResponse(out, 200, jsonArray.toString())
        }
    }

    private fun handleAddMemory(method: String, body: String, out: OutputStream) {
        if (!method.equals("POST", ignoreCase = true)) {
            sendJsonResponse(out, 405, "{\"error\":\"Method not allowed\"}")
            return
        }
        try {
            val json = JSONObject(body)
            val title = json.getString("title")
            val content = json.getString("content")
            val lobeType = json.optString("lobeType", BrainLobe.PARIETAL.id)
            val category = json.optString("category", "Da Web Remoto")
            val tags = json.optString("tags", "remoto,web")

            val item = BrainItem(
                title = title,
                content = content,
                lobeType = lobeType,
                category = category,
                tags = tags,
                importance = json.optInt("importance", 3),
                emotionLevel = json.optInt("emotionLevel", 50),
                createdAt = System.currentTimeMillis()
            )

            runBlocking {
                repository.insert(item)
            }
            lastLogMessage = "Nuovo ricordo '$title' aggiunto da dispositivo remoto"
            sendJsonResponse(out, 200, "{\"success\":true,\"message\":\"Ricordo salvato nel cervello\"}")
        } catch (e: Exception) {
            sendJsonResponse(out, 400, "{\"error\":\"${e.message}\"}")
        }
    }

    private fun handleCloneChat(method: String, body: String, out: OutputStream) {
        if (!method.equals("POST", ignoreCase = true)) {
            sendJsonResponse(out, 405, "{\"error\":\"Method not allowed\"}")
            return
        }
        val json = JSONObject(body)
        val userPrompt = json.optString("prompt", "")

        runBlocking {
            val memories = repository.allItems.first()
            val responseText = synthesizeCloneAnswer(userPrompt, memories)
            val resObj = JSONObject().apply {
                put("reply", responseText)
                put("cloneName", cryptoPrefs.cloneName)
            }
            sendJsonResponse(out, 200, resObj.toString())
        }
    }

    private fun handleExport(body: String, out: OutputStream, clientIp: String) {
        // In precedenza qui veniva usata la stringa fissa "2026" (identica al PIN di
        // default) come passphrase di cifratura del backup: chiunque intercettasse
        // l'export otteneva un archivio banalissimo da decifrare, indipendentemente
        // dal vero PIN master impostato dall'utente. Ora la passphrase deve essere
        // fornita esplicitamente dal chiamante e verificata contro il PIN reale.
        if (isLockedOut(clientIp)) {
            sendJsonResponse(out, 429, "{\"error\":\"Troppi tentativi falliti. Riprova tra qualche minuto.\"}")
            return
        }

        val json = try { JSONObject(body) } catch (e: Exception) { JSONObject() }
        val pin = json.optString("pin", "")

        if (!cryptoPrefs.verifyPin(pin)) {
            registerFailedAttempt(clientIp)
            sendJsonResponse(out, 401, "{\"error\":\"PIN master richiesto e non valido per l'export\"}")
            return
        }
        registerSuccessfulAttempt(clientIp)

        runBlocking {
            val encryptedBackup = repository.exportEncryptedBackup(pin)
            sendJsonResponse(out, 200, JSONObject().apply {
                put("encryptedBackup", encryptedBackup)
            }.toString())
        }
    }

    private fun synthesizeCloneAnswer(prompt: String, memories: List<BrainItem>): String {
        val lower = prompt.lowercase()
        val relevant = memories.filter { item ->
            lower.contains(item.title.lowercase()) ||
            lower.contains(item.category.lowercase()) ||
            item.getTagsList().any { lower.contains(it.lowercase()) } ||
            item.content.lowercase().split(" ").any { it.length > 4 && lower.contains(it) }
        }.take(3)

        val cloneName = cryptoPrefs.cloneName

        return if (relevant.isNotEmpty()) {
            val references = relevant.joinToString("\n• ") { "${it.title} (${it.getLobe().title}): ${it.content.take(120)}..." }
            "🧠 [Clone Cerebrale di $cloneName]:\nConsultando le mie memorie sinaptiche collegate a questa domanda, ecco cosa so e come penso:\n\n• $references\n\nIn base ai miei principi e ricordi archiviati sul dispositivo, procederei mantenendo il focus sulla qualità, sicurezza e coerenza con i miei valori."
        } else {
            "🧠 [Clone Cerebrale di $cloneName]:\nHo analizzato le mie ${memories.size} memorie sinaptiche locali. Per la tua domanda '$prompt', non ho ancora un ricordo specifico o una preferenza registrata nel Lobo Frontale o Temporale. Puoi aggiungere un nuovo pensiero o decisione sul dispositivo per arricchire il mio clone!"
        }
    }

    private fun sendJsonResponse(out: OutputStream, statusCode: Int, json: String) {
        sendResponse(out, statusCode, "application/json; charset=UTF-8", json)
    }

    private fun sendResponse(out: OutputStream, statusCode: Int, contentType: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val statusText = when (statusCode) {
            200 -> "OK"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            429 -> "Too Many Requests"
            else -> "Internal Server Error"
        }
        val response = StringBuilder()
            .append("HTTP/1.1 $statusCode $statusText\r\n")
            .append("Content-Type: $contentType\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
            .append("Access-Control-Allow-Headers: Content-Type, Authorization\r\n")
            .append("Content-Length: ${bytes.size}\r\n")
            .append("Connection: close\r\n")
            .append("\r\n")
            .toString()

        out.write(response.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }
}
