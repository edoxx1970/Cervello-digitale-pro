package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tiene traccia dei file del dispositivo (foto o documenti) già esaminati
 * dall'Auto-Import, per non rianalizzarli ad ogni scansione e non consumare
 * chiamate API Gemini inutili su contenuti già trasformati in memorie.
 *
 * `uriString` è la chiave primaria: per le foto è l'URI content:// di
 * MediaStore, per i documenti il path assoluto del file.
 */
@Entity(tableName = "scanned_files")
data class ScannedFileEntity(
    @PrimaryKey
    val uriString: String,
    val source: String, // "IMAGE" o "DOCUMENT"
    val fileName: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val processedAt: Long = System.currentTimeMillis(),
    val status: String, // "IMPORTED", "SKIPPED_TOO_LARGE", "SKIPPED_UNSUPPORTED", "ERROR"
    val brainItemId: Long? = null
)
