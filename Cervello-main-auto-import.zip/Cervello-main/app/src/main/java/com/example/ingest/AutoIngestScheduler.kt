package com.example.ingest

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Centralizza la pianificazione del worker di Auto-Import, così il
 * ViewModel non deve conoscere i dettagli di WorkManager (intervallo,
 * vincoli di rete/batteria, policy di sostituzione).
 */
object AutoIngestScheduler {

    // 6 ore è un compromesso tra "novità ragionevolmente fresca" e battery
    // drain: WorkManager comunque non garantisce puntualità esatta, decide
    // il sistema in base allo stato di batteria/Doze.
    private const val PERIODIC_INTERVAL_HOURS = 6L

    private fun constraints(): Constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED) // serve per chiamare Gemini
        .setRequiresBatteryNotLow(true)
        .build()

    fun enablePeriodicScan(context: Context) {
        val request = PeriodicWorkRequestBuilder<AutoIngestWorker>(
            PERIODIC_INTERVAL_HOURS, TimeUnit.HOURS
        )
            .setConstraints(constraints())
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            AutoIngestWorker.UNIQUE_PERIODIC_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    fun disablePeriodicScan(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(AutoIngestWorker.UNIQUE_PERIODIC_NAME)
    }

    fun runOnce(context: Context) {
        val request = OneTimeWorkRequestBuilder<AutoIngestWorker>()
            .setConstraints(constraints())
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            AutoIngestWorker.UNIQUE_ONE_TIME_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }
}
