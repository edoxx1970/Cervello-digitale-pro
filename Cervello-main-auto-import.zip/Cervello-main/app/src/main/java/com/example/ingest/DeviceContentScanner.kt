package com.example.ingest

import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Rappresenta un file candidato all'importazione: una foto trovata in
 * MediaStore o un documento trovato con la scansione del filesystem.
 */
data class DeviceFileCandidate(
    val uriString: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val source: String // "IMAGE" o "DOCUMENT"
)

/**
 * Individua i contenuti "nuovi" del dispositivo (non ancora nella tabella
 * scanned_files) da proporre all'Auto-Import.
 *
 * Foto: usa MediaStore, che su Android 13+ richiede solo READ_MEDIA_IMAGES
 * (o il permesso "parziale" di selezione foto) — nessun accesso allargato.
 *
 * Documenti: MediaStore da solo NON basta per leggere PDF/Word creati da
 * altre app (WhatsApp, browser, ecc.), perché dallo scoped storage in poi
 * un'app vede solo i propri file più le collezioni media pubbliche. Per una
 * vera scansione "di tutti i documenti del telefono" serve il permesso
 * speciale MANAGE_EXTERNAL_STORAGE ("Accesso a tutti i file"): se non è
 * concesso, la scansione documenti viene semplicemente saltata (nessun
 * crash, nessun dato mancante silenziosamente scambiato per "nessun file").
 */
class DeviceContentScanner(private val context: Context) {

    companion object {
        private val DOCUMENT_EXTENSIONS = setOf("pdf", "txt", "md", "csv", "json", "doc", "docx")
        // Cartelle pubbliche più probabili: evitiamo di scandagliare l'intera
        // radice (lento, e piena di cache/dati di altre app poco rilevanti).
        private val DOCUMENT_SCAN_SUBDIRS = listOf(
            "Download", "Documents", "WhatsApp/Media/WhatsApp Documents", "Telegram/Telegram Documents"
        )
        private const val MAX_DOCUMENT_SCAN_DEPTH = 4
        private const val MAX_CANDIDATES_PER_RUN = 25
    }

    fun hasAllFilesAccess(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()
    }

    /**
     * Foto/video più recenti dalla galleria non ancora scansionati.
     */
    fun findNewImages(alreadyScannedUris: Set<String>): List<DeviceFileCandidate> {
        val results = mutableListOf<DeviceFileCandidate>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_MODIFIED
        )

        try {
            context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val modCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)

                while (cursor.moveToNext() && results.size < MAX_CANDIDATES_PER_RUN) {
                    val id = cursor.getLong(idCol)
                    val uri = android.content.ContentUris.withAppendedId(collection, id).toString()
                    if (uri in alreadyScannedUris) continue

                    results.add(
                        DeviceFileCandidate(
                            uriString = uri,
                            fileName = cursor.getString(nameCol) ?: "foto_$id.jpg",
                            mimeType = cursor.getString(mimeCol) ?: "image/jpeg",
                            sizeBytes = cursor.getLong(sizeCol),
                            lastModified = cursor.getLong(modCol) * 1000L,
                            source = "IMAGE"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return results
    }

    /**
     * Documenti (PDF/testo) nelle cartelle pubbliche più comuni, solo se
     * l'app ha ottenuto "Accesso a tutti i file". Ritorna lista vuota
     * altrimenti (nessuna eccezione: è uno stato atteso, non un errore).
     */
    fun findNewDocuments(alreadyScannedUris: Set<String>): List<DeviceFileCandidate> {
        if (!hasAllFilesAccess()) return emptyList()

        val results = mutableListOf<DeviceFileCandidate>()
        val root = Environment.getExternalStorageDirectory()

        for (subdir in DOCUMENT_SCAN_SUBDIRS) {
            if (results.size >= MAX_CANDIDATES_PER_RUN) break
            val dir = File(root, subdir)
            if (!dir.exists() || !dir.isDirectory) continue
            scanDirectory(dir, depth = 0, alreadyScannedUris, results)
        }
        return results
    }

    private fun scanDirectory(
        dir: File,
        depth: Int,
        alreadyScannedUris: Set<String>,
        results: MutableList<DeviceFileCandidate>
    ) {
        if (depth > MAX_DOCUMENT_SCAN_DEPTH || results.size >= MAX_CANDIDATES_PER_RUN) return
        val entries = dir.listFiles() ?: return

        for (entry in entries) {
            if (results.size >= MAX_CANDIDATES_PER_RUN) return
            if (entry.isDirectory) {
                scanDirectory(entry, depth + 1, alreadyScannedUris, results)
                continue
            }
            val ext = entry.extension.lowercase()
            if (ext !in DOCUMENT_EXTENSIONS) continue
            if (entry.path in alreadyScannedUris) continue

            results.add(
                DeviceFileCandidate(
                    uriString = entry.path,
                    fileName = entry.name,
                    mimeType = mimeTypeForExtension(ext),
                    sizeBytes = entry.length(),
                    lastModified = entry.lastModified(),
                    source = "DOCUMENT"
                )
            )
        }
    }

    private fun mimeTypeForExtension(ext: String): String = when (ext) {
        "pdf" -> "application/pdf"
        "txt" -> "text/plain"
        "md" -> "text/markdown"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        else -> "application/octet-stream"
    }
}
