package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.BrainCloneEngine
import com.example.crypto.CryptoPreferences
import com.example.crypto.EncryptedPhotoStorage
import com.example.data.db.BrainDatabase
import com.example.data.model.BrainItem
import com.example.data.model.BrainLobe
import com.example.data.repository.BrainRepository
import com.example.data.repository.ChatRepository
import com.example.server.BrainRemoteServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab {
    DASHBOARD,
    LOBES,
    NEURAL_GRAPH,
    DECISION_SIMULATOR,
    SOCRATIC_INTERVIEW,
    DRIVE_IMPORT,
    GALLERY,
    CHAT,
    REMOTE_PORTAL,
    SECURITY,
    AUTO_IMPORT
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isProtected: Boolean = true,
    val modelUsed: String = "gemini-3.5-flash"
)

enum class MessageSender {
    USER,
    CLONE
}

class BrainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: android.content.Context = application.applicationContext
    private val database = BrainDatabase.getDatabase(application)
    val vaultSession = com.example.crypto.VaultSession()
    val repository = BrainRepository(database.brainDao(), vaultSession)
    val cryptoPrefs = CryptoPreferences(application)
    val photoStorage = EncryptedPhotoStorage(application, cryptoPrefs)
    val chatRepo = ChatRepository(database.chatDao(), cryptoPrefs)
    val remoteServer = BrainRemoteServer(application, repository, cryptoPrefs)
    val cloneEngine = BrainCloneEngine()
    val driveService = com.example.data.drive.GoogleDriveImportService(application)
    val authManager = com.example.auth.FirebaseAuthManager(application)
    val ingestScanner = com.example.ingest.DeviceContentScanner(application)

    // Auto-Import (scansione automatica galleria/documenti in background)
    private val _isAutoIngestEnabled = MutableStateFlow(cryptoPrefs.isAutoIngestEnabled)
    val isAutoIngestEnabled: StateFlow<Boolean> = _isAutoIngestEnabled.asStateFlow()

    private val _isAutoIngestImagesEnabled = MutableStateFlow(cryptoPrefs.isAutoIngestImagesEnabled)
    val isAutoIngestImagesEnabled: StateFlow<Boolean> = _isAutoIngestImagesEnabled.asStateFlow()

    private val _isAutoIngestDocsEnabled = MutableStateFlow(cryptoPrefs.isAutoIngestDocsEnabled)
    val isAutoIngestDocsEnabled: StateFlow<Boolean> = _isAutoIngestDocsEnabled.asStateFlow()

    private val _isManualScanRunning = MutableStateFlow(false)
    val isManualScanRunning: StateFlow<Boolean> = _isManualScanRunning.asStateFlow()

    val autoIngestImportedCount: StateFlow<Int> = database.scannedFileDao().getImportedCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val autoIngestRecentScans: StateFlow<List<com.example.data.model.ScannedFileEntity>> =
        database.scannedFileDao().getRecent(20)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setAutoIngestEnabled(enabled: Boolean) {
        cryptoPrefs.isAutoIngestEnabled = enabled
        _isAutoIngestEnabled.value = enabled
        if (enabled) {
            com.example.ingest.AutoIngestScheduler.enablePeriodicScan(appContext)
            _toastNotice.value = "Acquisizione automatica attivata"
        } else {
            com.example.ingest.AutoIngestScheduler.disablePeriodicScan(appContext)
            _toastNotice.value = "Acquisizione automatica disattivata"
        }
    }

    fun setAutoIngestImagesEnabled(enabled: Boolean) {
        cryptoPrefs.isAutoIngestImagesEnabled = enabled
        _isAutoIngestImagesEnabled.value = enabled
    }

    fun setAutoIngestDocsEnabled(enabled: Boolean) {
        cryptoPrefs.isAutoIngestDocsEnabled = enabled
        _isAutoIngestDocsEnabled.value = enabled
    }

    fun triggerManualIngestScan() {
        _isManualScanRunning.value = true
        com.example.ingest.AutoIngestScheduler.runOnce(appContext)
        _toastNotice.value = "Scansione avviata: foto e documenti nuovi verranno analizzati in background"
        viewModelScope.launch {
            kotlinx.coroutines.delay(3000)
            _isManualScanRunning.value = false
        }
    }

    fun getLastAutoIngestRunMillis(): Long = cryptoPrefs.lastAutoIngestRunMillis

    fun hasAllFilesAccess(): Boolean = ingestScanner.hasAllFilesAccess()

    // Auth State
    private val _currentUser = MutableStateFlow(authManager.auth?.currentUser)
    val currentUser: StateFlow<com.google.firebase.auth.FirebaseUser?> = _currentUser.asStateFlow()
    
    private val _isLoginSkipped = MutableStateFlow(false)
    val isLoginSkipped: StateFlow<Boolean> = _isLoginSkipped.asStateFlow()
    
    fun skipLogin() {
        _isLoginSkipped.value = true
    }

    // Navigation Tab
    private val _currentTab = MutableStateFlow(AppNavTab.DASHBOARD)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    // CameraX Dialog State
    private val _isCameraDialogOpen = MutableStateFlow(false)
    val isCameraDialogOpen: StateFlow<Boolean> = _isCameraDialogOpen.asStateFlow()

    private val _cameraTargetLobe = MutableStateFlow(BrainLobe.OCCIPITAL)
    val cameraTargetLobe: StateFlow<BrainLobe> = _cameraTargetLobe.asStateFlow()

    // Voice-to-Text Recording Dialog State
    private val _isVoiceDialogOpen = MutableStateFlow(false)
    val isVoiceDialogOpen: StateFlow<Boolean> = _isVoiceDialogOpen.asStateFlow()

    private val _voiceTargetLobe = MutableStateFlow(BrainLobe.TEMPORAL)
    val voiceTargetLobe: StateFlow<BrainLobe> = _voiceTargetLobe.asStateFlow()

    // Voice Query / Interrogazione Neurale Vocale State
    private val _isVoiceQueryDialogOpen = MutableStateFlow(false)
    val isVoiceQueryDialogOpen: StateFlow<Boolean> = _isVoiceQueryDialogOpen.asStateFlow()

    private val _voiceQueryPrompt = MutableStateFlow("")
    val voiceQueryPrompt: StateFlow<String> = _voiceQueryPrompt.asStateFlow()

    private val _voiceQueryAiAnswer = MutableStateFlow<String?>(null)
    val voiceQueryAiAnswer: StateFlow<String?> = _voiceQueryAiAnswer.asStateFlow()

    private val _isVoiceQueryLoading = MutableStateFlow(false)
    val isVoiceQueryLoading: StateFlow<Boolean> = _isVoiceQueryLoading.asStateFlow()

    private val _voiceQueryMatches = MutableStateFlow<List<BrainItem>>(emptyList())
    val voiceQueryMatches: StateFlow<List<BrainItem>> = _voiceQueryMatches.asStateFlow()

    // Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Selected Lobe Filter
    private val _selectedLobe = MutableStateFlow<BrainLobe?>(null)
    val selectedLobe: StateFlow<BrainLobe?> = _selectedLobe.asStateFlow()

    // Selected Category Filter
    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    // Selected Tag Filter
    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()

    // App-level Biometric Lock State (Cervello Digitale Access Protection)
    private val _isAppLocked = MutableStateFlow(cryptoPrefs.isAppLockEnabled)
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    // Vault Lock State
    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    // Remote Server UI State
    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverIp = MutableStateFlow(remoteServer.getLocalIpAddress())
    val serverIp: StateFlow<String> = _serverIp.asStateFlow()

    private val _remotePairingPin = MutableStateFlow(cryptoPrefs.remotePairingPin)
    val remotePairingPin: StateFlow<String> = _remotePairingPin.asStateFlow()

    // Protected Chat with AI Clone (Room Encrypted + Gemini)
    val chatMessages: StateFlow<List<ChatMessage>> = chatRepo.getDecryptedChatHistory()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            listOf(
                ChatMessage(
                    sender = MessageSender.CLONE,
                    text = "Ciao! Sono il tuo Clone Cerebrale Digitale alimentato da Gemini 3.5 Flash. Tutte le nostre conversazioni sono protette con crittografia end-to-end (AES-256-GCM) sul tuo dispositivo. Cosa vorresti approfondire o decidere oggi?"
                )
            )
        )

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _isPrivacyShieldActive = MutableStateFlow(true)
    val isPrivacyShieldActive: StateFlow<Boolean> = _isPrivacyShieldActive.asStateFlow()

    // Dialog & Detail states
    private val _activeDetailItem = MutableStateFlow<BrainItem?>(null)
    val activeDetailItem: StateFlow<BrainItem?> = _activeDetailItem.asStateFlow()

    private val _isAddMemoryDialogOpen = MutableStateFlow(false)
    val isAddMemoryDialogOpen: StateFlow<Boolean> = _isAddMemoryDialogOpen.asStateFlow()

    private val _memoryToEdit = MutableStateFlow<BrainItem?>(null)
    val memoryToEdit: StateFlow<BrainItem?> = _memoryToEdit.asStateFlow()

    private val _isUnlockDialogOpen = MutableStateFlow(false)
    val isUnlockDialogOpen: StateFlow<Boolean> = _isUnlockDialogOpen.asStateFlow()

    private val _toastNotice = MutableStateFlow<String?>(null)
    val toastNotice: StateFlow<String?> = _toastNotice.asStateFlow()

    // Decision Simulator State
    private val _decisionDilemma = MutableStateFlow("")
    val decisionDilemma: StateFlow<String> = _decisionDilemma.asStateFlow()

    private val _isSimulatingDecision = MutableStateFlow(false)
    val isSimulatingDecision: StateFlow<Boolean> = _isSimulatingDecision.asStateFlow()

    private val _decisionResult = MutableStateFlow<com.example.ai.DecisionSimulationResult?>(null)
    val decisionResult: StateFlow<com.example.ai.DecisionSimulationResult?> = _decisionResult.asStateFlow()

    // Socratic Interview & Automatic Memory Extraction State
    private val _socraticQuestions = MutableStateFlow<List<com.example.ai.SocraticQuestion>>(emptyList())
    val socraticQuestions: StateFlow<List<com.example.ai.SocraticQuestion>> = _socraticQuestions.asStateFlow()

    private val _isLoadingSocraticQuestions = MutableStateFlow(false)
    val isLoadingSocraticQuestions: StateFlow<Boolean> = _isLoadingSocraticQuestions.asStateFlow()

    private val _activeSocraticQuestion = MutableStateFlow<com.example.ai.SocraticQuestion?>(null)
    val activeSocraticQuestion: StateFlow<com.example.ai.SocraticQuestion?> = _activeSocraticQuestion.asStateFlow()

    private val _socraticAnswerText = MutableStateFlow("")
    val socraticAnswerText: StateFlow<String> = _socraticAnswerText.asStateFlow()

    private val _isExtractingMemory = MutableStateFlow(false)
    val isExtractingMemory: StateFlow<Boolean> = _isExtractingMemory.asStateFlow()

    private val _extractedMemoryResult = MutableStateFlow<com.example.ai.ExtractedMemoryResult?>(null)
    val extractedMemoryResult: StateFlow<com.example.ai.ExtractedMemoryResult?> = _extractedMemoryResult.asStateFlow()

    // Google Drive & Primary Services Import State
    private val _driveAccessToken = MutableStateFlow(cryptoPrefs.driveOAuthToken)
    val driveAccessToken: StateFlow<String> = _driveAccessToken.asStateFlow()

    private val _driveFiles = MutableStateFlow<List<com.example.data.drive.DriveFileItem>>(emptyList())
    val driveFiles: StateFlow<List<com.example.data.drive.DriveFileItem>> = _driveFiles.asStateFlow()

    private val _isLoadingDriveFiles = MutableStateFlow(false)
    val isLoadingDriveFiles: StateFlow<Boolean> = _isLoadingDriveFiles.asStateFlow()

    private val _isImportingDocument = MutableStateFlow(false)
    val isImportingDocument: StateFlow<Boolean> = _isImportingDocument.asStateFlow()

    private val _importedDocumentPreview = MutableStateFlow<com.example.ai.ExtractedMemoryResult?>(null)
    val importedDocumentPreview: StateFlow<com.example.ai.ExtractedMemoryResult?> = _importedDocumentPreview.asStateFlow()

    private val _importedSourceFileName = MutableStateFlow("")
    val importedSourceFileName: StateFlow<String> = _importedSourceFileName.asStateFlow()

    // Neural Graph Interactive State
    private val _selectedGraphNode = MutableStateFlow<BrainItem?>(null)
    val selectedGraphNode: StateFlow<BrainItem?> = _selectedGraphNode.asStateFlow()

    private val _graphLobeFilter = MutableStateFlow<BrainLobe?>(null)
    val graphLobeFilter: StateFlow<BrainLobe?> = _graphLobeFilter.asStateFlow()

    // All Items Stream
    val allItems: StateFlow<List<BrainItem>> = repository.allItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamic Categories Stream from Room with memory counts
    val availableCategories: StateFlow<List<Pair<String, Int>>> = repository.allItems.map { items ->
        val counts = mutableMapOf<String, Int>()
        for (item in items) {
            val cat = item.category.trim()
            if (cat.isNotEmpty()) {
                counts[cat] = (counts[cat] ?: 0) + 1
            }
        }
        counts.toList().sortedByDescending { it.second }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamic Tags Cloud Stream with occurrences counts
    val availableTags: StateFlow<List<Pair<String, Int>>> = repository.allItems.map { items ->
        val counts = mutableMapOf<String, Int>()
        for (item in items) {
            for (tag in item.getTagsList()) {
                val cleanTag = tag.trim().removePrefix("#").lowercase()
                if (cleanTag.isNotEmpty()) {
                    counts[cleanTag] = (counts[cleanTag] ?: 0) + 1
                }
            }
        }
        counts.toList().sortedByDescending { it.second }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Items for Dashboard & Lobes (combines Search, Lobe, Category, Tag)
    val filteredItems: StateFlow<List<BrainItem>> = combine(
        repository.allItems,
        _searchQuery,
        _selectedLobe,
        _selectedCategory,
        _selectedTag
    ) { items, query, lobe, category, tag ->
        items.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.content.contains(query, ignoreCase = true) ||
                item.tags.contains(query, ignoreCase = true) ||
                item.category.contains(query, ignoreCase = true)

            val matchesLobe = lobe == null || item.lobeType == lobe.id

            val matchesCategory = category == null || item.category.equals(category, ignoreCase = true)

            val matchesTag = tag == null || item.getTagsList().any { t ->
                val clean = t.trim().removePrefix("#").lowercase()
                val target = tag.trim().removePrefix("#").lowercase()
                clean == target || clean.contains(target)
            } || item.tags.contains(tag, ignoreCase = true)

            matchesQuery && matchesLobe && matchesCategory && matchesTag
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Lobe Count Map
    val lobeCounts: StateFlow<Map<BrainLobe, Int>> = repository.allItems.combine(_searchQuery) { items, _ ->
        BrainLobe.entries.associateWith { lobe ->
            items.count { it.lobeType == lobe.id }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        viewModelScope.launch {
            repository.seedInitialBrainDataIfEmpty()
        }
    }

    fun setNavTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectLobe(lobe: BrainLobe?) {
        _selectedLobe.value = if (_selectedLobe.value == lobe) null else lobe
    }

    fun selectCategory(category: String?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun selectTag(tag: String?) {
        val cleanTag = tag?.trim()?.removePrefix("#")?.lowercase()
        _selectedTag.value = if (_selectedTag.value == cleanTag) null else cleanTag
    }

    fun clearCategoryFilter() {
        _selectedCategory.value = null
    }

    fun clearTagFilter() {
        _selectedTag.value = null
    }

    fun clearAllFilters() {
        _searchQuery.value = ""
        _selectedLobe.value = null
        _selectedCategory.value = null
        _selectedTag.value = null
    }

    fun openDetail(item: BrainItem) {
        _activeDetailItem.value = item
    }

    fun closeDetail() {
        _activeDetailItem.value = null
    }

    fun openAddMemoryDialog(itemToEdit: BrainItem? = null) {
        _memoryToEdit.value = itemToEdit
        _isAddMemoryDialogOpen.value = true
    }

    fun closeAddMemoryDialog() {
        _memoryToEdit.value = null
        _isAddMemoryDialogOpen.value = false
    }

    fun saveMemory(item: BrainItem) {
        viewModelScope.launch {
            try {
                if (item.id != 0L) {
                    repository.update(item)
                    _toastNotice.value = "Sinapsi aggiornata"
                } else {
                    repository.insert(item)
                    _toastNotice.value = "Nuova sinapsi memorizzata nel ${item.getLobe().title}"
                }
                closeAddMemoryDialog()
                closeDetail()
            } catch (e: IllegalStateException) {
                _toastNotice.value = e.message ?: "Sblocca il Caveau Neurale prima di salvare un contenuto cifrato"
            }
        }
    }

    // CameraX Actions
    fun openCameraDialog(lobe: BrainLobe = BrainLobe.OCCIPITAL) {
        _cameraTargetLobe.value = lobe
        _isCameraDialogOpen.value = true
    }

    fun closeCameraDialog() {
        _isCameraDialogOpen.value = false
    }

    // Voice-to-Text Actions
    fun openVoiceDialog(lobe: BrainLobe = BrainLobe.TEMPORAL) {
        _voiceTargetLobe.value = lobe
        _isVoiceDialogOpen.value = true
    }

    fun closeVoiceDialog() {
        _isVoiceDialogOpen.value = false
    }

    fun saveVoiceMemory(
        title: String,
        content: String,
        lobe: BrainLobe,
        category: String,
        tags: String,
        isEncrypted: Boolean
    ) {
        viewModelScope.launch {
            val formattedTags = if (tags.contains("voce") || tags.contains("audio")) tags else "$tags, #voce, #audio-memo"
            val newItem = BrainItem(
                title = title,
                content = content,
                lobeType = lobe.id,
                category = category.ifBlank { "Pensiero Vocale" },
                tags = formattedTags,
                importance = 4,
                emotionLevel = 60,
                isEncrypted = isEncrypted || (lobe == BrainLobe.NEURAL_VAULT)
            )
            try {
                repository.insert(newItem)
                closeVoiceDialog()
                _toastNotice.value = "Pensiero vocale salvato nel ${lobe.title}"
            } catch (e: IllegalStateException) {
                _toastNotice.value = e.message ?: "Sblocca il Caveau Neurale prima di salvare un contenuto cifrato"
            }
        }
    }

    // Voice Query / Interrogazione Neurale Vocale Actions
    fun openVoiceQueryDialog(initialText: String = "") {
        _voiceQueryPrompt.value = initialText
        _voiceQueryAiAnswer.value = null
        _voiceQueryMatches.value = emptyList()
        _isVoiceQueryLoading.value = false
        _isVoiceQueryDialogOpen.value = true
        if (initialText.isNotBlank()) {
            executeVoiceBrainQuery(initialText)
        }
    }

    fun closeVoiceQueryDialog() {
        _isVoiceQueryDialogOpen.value = false
        _isVoiceQueryLoading.value = false
    }

    fun executeVoiceBrainQuery(spokenPrompt: String) {
        val query = spokenPrompt.trim()
        if (query.isBlank()) return

        _voiceQueryPrompt.value = query
        _isVoiceQueryLoading.value = true
        _voiceQueryAiAnswer.value = null

        viewModelScope.launch {
            try {
                // 1. Instant keyword & semantic filter over stored memories
                val allMemories = allItems.value
                val searchTerms = query.lowercase().split("\\s+".toRegex()).filter { it.length > 2 }
                
                val matched = allMemories.filter { item ->
                    val isVaultProtected = item.isEncrypted && !_isVaultUnlocked.value
                    if (isVaultProtected && _isPrivacyShieldActive.value) return@filter false

                    val textToSearch = "${item.title} ${item.content} ${item.category} ${item.tags}".lowercase()
                    searchTerms.any { term -> textToSearch.contains(term) } ||
                            query.contains(item.title, ignoreCase = true) ||
                            (item.category.isNotBlank() && query.contains(item.category, ignoreCase = true))
                }.sortedByDescending { it.importance }

                _voiceQueryMatches.value = matched

                // 2. Query the Brain Clone Engine with Gemini for intelligent cognitive voice synthesis
                val synthesisPrompt = "Rispondi in modo conciso, diretto e chiaro alla domanda vocale dell'utente basandoti sulle memorie e sinapsi salvate nel suo Cervello Digitale: \"$query\""
                
                val aiResponse = cloneEngine.queryBrainClone(
                    userPrompt = synthesisPrompt,
                    cloneName = cryptoPrefs.cloneName,
                    allMemories = allMemories,
                    recentHistory = emptyList(),
                    isPrivacyShieldActive = _isPrivacyShieldActive.value,
                    allowVaultGrounding = _isVaultUnlocked.value && !_isPrivacyShieldActive.value
                )

                _voiceQueryAiAnswer.value = aiResponse
            } catch (e: Exception) {
                _voiceQueryAiAnswer.value = "⚠️ Non sono riuscito ad elaborare la risposta: ${e.message}"
            } finally {
                _isVoiceQueryLoading.value = false
            }
        }
    }

    fun saveCapturedPhotoMemory(
        bytes: ByteArray,
        rotation: Int,
        title: String,
        content: String,
        lobe: BrainLobe,
        tags: String,
        isEncrypted: Boolean
    ) {
        viewModelScope.launch {
            try {
                // 1. Cifra e salva l'immagine in locale con AES-256
                val photoUri = photoStorage.saveEncryptedPhoto(bytes, rotation)

                // 2. Crea la sinapsi visiva nel database Room
                val newItem = BrainItem(
                    title = title,
                    content = content,
                    lobeType = lobe.id,
                    category = "Sinapsi Visiva",
                    tags = tags,
                    importance = 4,
                    emotionLevel = 70,
                    isEncrypted = isEncrypted || (lobe == BrainLobe.NEURAL_VAULT),
                    photoUri = photoUri
                )

                repository.insert(newItem)
                closeCameraDialog()
                _toastNotice.value = "Foto cifrata e salvata nel ${lobe.title} (AES-256-GCM)"
            } catch (e: Exception) {
                _toastNotice.value = "Errore salvataggio foto cifrata: ${e.message}"
            }
        }
    }

    fun deleteMemory(item: BrainItem) {
        viewModelScope.launch {
            item.photoUri?.let { uri ->
                if (uri.startsWith("enc_synapse://")) {
                    photoStorage.deletePhoto(uri)
                }
            }
            repository.delete(item)
            _toastNotice.value = "Sinapsi rimossa"
            closeDetail()
        }
    }

    // App-Level Biometric Lock Management
    fun unlockAppWithBiometrics() {
        _isAppLocked.value = false
        _toastNotice.value = "Accesso Neurale Autorizzato (Biometria)"
    }

    fun unlockAppWithPin(pin: String): Boolean {
        val valid = cryptoPrefs.verifyPin(pin)
        if (valid) {
            _isAppLocked.value = false
            _toastNotice.value = "Accesso Neurale Autorizzato (PIN Master)"
        }
        return valid
    }

    fun lockApp() {
        _isAppLocked.value = true
        _isVaultUnlocked.value = false
        vaultSession.clear()
        _toastNotice.value = "Cervello Digitale Bloccato"
    }

    fun toggleAppLockSetting(): Boolean {
        val newState = !cryptoPrefs.isAppLockEnabled
        cryptoPrefs.isAppLockEnabled = newState
        _toastNotice.value = if (newState) "Blocco all'avvio attivato" else "Blocco all'avvio disattivato"
        return newState
    }

    fun toggleBiometricSetting(): Boolean {
        val newState = !cryptoPrefs.isBiometricEnabled
        cryptoPrefs.isBiometricEnabled = newState
        _toastNotice.value = if (newState) "Sblocco biometrico abilitato" else "Sblocco biometrico disabilitato"
        return newState
    }

    // Vault Lock / Unlock
    fun openUnlockDialog() {
        _isUnlockDialogOpen.value = true
    }

    fun closeUnlockDialog() {
        _isUnlockDialogOpen.value = false
    }

    fun verifyAndUnlockVault(pin: String): Boolean {
        val valid = cryptoPrefs.verifyPin(pin)
        if (valid) {
            // Deriva la chiave AES del caveau dal PIN + salt persistente (PBKDF2,
            // fatto una sola volta qui, non ad ogni lettura). Prima di questa
            // modifica lo sblocco era solo un flag booleano di UI: i contenuti del
            // caveau restavano in chiaro nel database indipendentemente da questo.
            val salt = android.util.Base64.decode(cryptoPrefs.vaultKeySaltBase64, android.util.Base64.NO_WRAP)
            val derivedKey = com.example.crypto.CryptoEngine.deriveKey(pin, salt)
            vaultSession.set(derivedKey)
            persistWrappedVaultKeyForBiometrics(derivedKey)

            _isVaultUnlocked.value = true
            _isUnlockDialogOpen.value = false
            _toastNotice.value = "Caveau Neurale Sbloccato (AES-256)"
        }
        return valid
    }

    /**
     * Salva la chiave del caveau "avvolta" (cifrata) con una chiave residente
     * nell'Android Keystore, così un successivo sblocco biometrico può recuperarla
     * senza richiedere di nuovo il PIN. Se il wrapping fallisce per qualche motivo
     * (raro), lo sblocco via PIN appena avvenuto resta comunque valido: cambia solo
     * che la biometria richiederà un PIN una volta in più.
     */
    private fun persistWrappedVaultKeyForBiometrics(vaultKey: javax.crypto.SecretKey) {
        try {
            val wrappingKey = com.example.crypto.VaultKeystoreCipher.getOrCreateWrappingKey()
            val keyBase64 = android.util.Base64.encodeToString(vaultKey.encoded, android.util.Base64.NO_WRAP)
            cryptoPrefs.wrappedVaultKey = com.example.crypto.CryptoEngine.encryptWithKey(keyBase64, wrappingKey)
        } catch (e: Exception) {
            // Non blocchiamo lo sblocco già avvenuto per un problema sul solo wrapping biometrico.
        }
    }

    fun unlockWithBiometrics() {
        val wrapped = cryptoPrefs.wrappedVaultKey
        if (wrapped.isBlank()) {
            _toastNotice.value = "Prima sblocco: usa il PIN una volta per abilitare l'accesso biometrico al Caveau"
            return
        }
        try {
            val wrappingKey = com.example.crypto.VaultKeystoreCipher.getOrCreateWrappingKey()
            val keyBase64 = com.example.crypto.CryptoEngine.decryptWithKey(wrapped, wrappingKey).getOrThrow()
            val keyBytes = android.util.Base64.decode(keyBase64, android.util.Base64.NO_WRAP)
            vaultSession.set(javax.crypto.spec.SecretKeySpec(keyBytes, "AES"))

            _isVaultUnlocked.value = true
            _isUnlockDialogOpen.value = false
            _toastNotice.value = "Sblocco biometrico autorizzato"
        } catch (e: Exception) {
            _toastNotice.value = "Sblocco biometrico non riuscito: usa il PIN Master"
        }
    }

    fun lockVault() {
        vaultSession.clear()
        _isVaultUnlocked.value = false
        _toastNotice.value = "Caveau Neurale Bloccato"
    }

    // Remote Server Controls
    fun toggleRemoteServer() {
        if (_isServerRunning.value) {
            remoteServer.stopServer()
            _isServerRunning.value = false
            _toastNotice.value = "Server E2EE arrestato"
        } else {
            val started = remoteServer.startServer(8888)
            if (started) {
                _isServerRunning.value = true
                _serverIp.value = remoteServer.getLocalIpAddress()
                _toastNotice.value = "Server attivo su http://${_serverIp.value}:8888"
            } else {
                _toastNotice.value = "Errore durante l'avvio del server locale"
            }
        }
    }

    fun regeneratePairingPin() {
        val newPin = cryptoPrefs.regenerateRemotePin()
        _remotePairingPin.value = newPin
        _toastNotice.value = "Nuovo PIN di accoppiamento generato: $newPin"
    }

    fun togglePrivacyShield() {
        _isPrivacyShieldActive.value = !_isPrivacyShieldActive.value
        val stateText = if (_isPrivacyShieldActive.value) "Scudo Privacy Attivo (Dati Caveau esclusi)" else "Scudo Privacy Ridotto"
        _toastNotice.value = stateText
    }

    // AI Clone Chat with Protected Storage & Gemini
    fun sendChatMessage(prompt: String) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank() || _isChatLoading.value) return

        _isChatLoading.value = true

        viewModelScope.launch {
            try {
                // 1. Save and encrypt User message into local encrypted Room database
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.USER,
                    plainText = cleanPrompt,
                    modelName = cloneEngine.currentModel
                )

                // 2. Query Gemini API with cognitive memory context and privacy shield
                val currentMemories = allItems.value
                val history = chatMessages.value
                val replyText = cloneEngine.queryBrainClone(
                    userPrompt = cleanPrompt,
                    cloneName = cryptoPrefs.cloneName,
                    allMemories = currentMemories,
                    recentHistory = history,
                    isPrivacyShieldActive = _isPrivacyShieldActive.value,
                    allowVaultGrounding = _isVaultUnlocked.value && !_isPrivacyShieldActive.value
                )

                // 3. Save and encrypt AI Assistant response into local encrypted Room database
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.CLONE,
                    plainText = replyText,
                    modelName = cloneEngine.currentModel
                )
            } catch (e: Exception) {
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.CLONE,
                    plainText = "⚠️ [Errore]: ${e.message}",
                    modelName = cloneEngine.currentModel
                )
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    fun setDecisionDilemma(dilemma: String) {
        _decisionDilemma.value = dilemma
    }

    fun clearDecisionSimulation() {
        _decisionDilemma.value = ""
        _decisionResult.value = null
        _isSimulatingDecision.value = false
    }

    fun runDecisionSimulation(customDilemma: String? = null) {
        val dilemmaToRun = (customDilemma ?: _decisionDilemma.value).trim()
        if (dilemmaToRun.isBlank() || _isSimulatingDecision.value) return

        _decisionDilemma.value = dilemmaToRun
        _isSimulatingDecision.value = true
        _decisionResult.value = null

        viewModelScope.launch {
            try {
                val memories = allItems.value
                val result = cloneEngine.simulateDecision(
                    dilemma = dilemmaToRun,
                    cloneName = cryptoPrefs.cloneName,
                    allMemories = memories,
                    isPrivacyShieldActive = _isPrivacyShieldActive.value
                )
                _decisionResult.value = result
            } catch (e: Exception) {
                _toastNotice.value = "Errore simulazione: ${e.message}"
            } finally {
                _isSimulatingDecision.value = false
            }
        }
    }

    fun saveDecisionAsMemory(dilemma: String, result: com.example.ai.DecisionSimulationResult) {
        viewModelScope.launch {
            val contentText = buildString {
                appendLine("⚖️ DILEMMA VALUTATO: $dilemma")
                appendLine("🎯 VERDETTO: ${result.verdict} (Allineamento: ${result.alignmentScore}%)")
                appendLine("\n🧠 Analisi Lobi:")
                appendLine("• Frontale: ${result.frontalAnalysis}")
                appendLine("• Parietale: ${result.parietalAnalysis}")
                appendLine("• Temporale: ${result.temporalAnalysis}")
                appendLine("\n✅ Pro: ${result.pros.joinToString("; ")}")
                appendLine("⚠️ Rischi: ${result.cons.joinToString("; ")}")
                appendLine("\n💡 Raccomandazione Finale: ${result.recommendation}")
            }

            val newItem = BrainItem(
                title = "Decisione: ${dilemma.take(45)}...",
                content = contentText,
                lobeType = BrainLobe.FRONTAL.id,
                category = "Decisioni",
                tags = "decisione, sim_neurale, clone_ai, ${result.verdict.lowercase().replace(" ", "_")}",
                isEncrypted = false
            )
            repository.insert(newItem)
            _toastNotice.value = "Decisione archiviata nel Lobo Frontale con successo!"
        }
    }

    fun selectGraphNode(item: BrainItem?) {
        _selectedGraphNode.value = item
    }

    fun setGraphLobeFilter(lobe: BrainLobe?) {
        _graphLobeFilter.value = if (_graphLobeFilter.value == lobe) null else lobe
    }

    // Socratic Interview Actions
    fun loadSocraticQuestions() {
        if (_isLoadingSocraticQuestions.value) return
        _isLoadingSocraticQuestions.value = true
        viewModelScope.launch {
            try {
                val questions = cloneEngine.generateSocraticQuestions(
                    cloneName = cryptoPrefs.cloneName,
                    allMemories = allItems.value
                )
                _socraticQuestions.value = questions
                if (_activeSocraticQuestion.value == null && questions.isNotEmpty()) {
                    _activeSocraticQuestion.value = questions.first()
                }
            } catch (e: Exception) {
                _toastNotice.value = "Errore caricamento intervista: ${e.message}"
            } finally {
                _isLoadingSocraticQuestions.value = false
            }
        }
    }

    fun selectSocraticQuestion(question: com.example.ai.SocraticQuestion) {
        _activeSocraticQuestion.value = question
        _socraticAnswerText.value = ""
        _extractedMemoryResult.value = null
    }

    fun setSocraticAnswerText(text: String) {
        _socraticAnswerText.value = text
    }

    fun extractAndSynthesizeMemory() {
        val question = _activeSocraticQuestion.value ?: return
        val answer = _socraticAnswerText.value.trim()
        if (answer.isBlank() || _isExtractingMemory.value) return

        _isExtractingMemory.value = true
        _extractedMemoryResult.value = null

        viewModelScope.launch {
            try {
                val result = cloneEngine.extractMemoryFromSocraticAnswer(
                    question = question,
                    userAnswer = answer,
                    cloneName = cryptoPrefs.cloneName
                )
                _extractedMemoryResult.value = result
            } catch (e: Exception) {
                _toastNotice.value = "Errore estrazione memoria: ${e.message}"
            } finally {
                _isExtractingMemory.value = false
            }
        }
    }

    fun commitExtractedMemoryToBrain(result: com.example.ai.ExtractedMemoryResult) {
        viewModelScope.launch {
            val contentText = buildString {
                appendLine(result.content)
                if (result.keyInsights.isNotEmpty()) {
                    appendLine("\n✨ **Principi Chiave Astratti:**")
                    result.keyInsights.forEach { appendLine("• $it") }
                }
                appendLine("\n💫 **Risonanza Emotiva:** ${result.emotionalResonance}")
                if (!result.suggestedAction.isNullOrBlank()) {
                    appendLine("📌 **Direttiva di Vita:** ${result.suggestedAction}")
                }
            }

            val targetLobeEnum = try {
                BrainLobe.valueOf(result.targetLobe)
            } catch (e: Exception) {
                BrainLobe.TEMPORAL
            }

            val newItem = BrainItem(
                title = result.title,
                content = contentText,
                lobeType = targetLobeEnum.id,
                category = result.category,
                tags = result.tags.joinToString(", "),
                isEncrypted = false
            )

            repository.insert(newItem)
            _toastNotice.value = "Ricordo sintetizzato e memorizzato nel ${targetLobeEnum.title}!"
            _extractedMemoryResult.value = null
            _socraticAnswerText.value = ""
        }
    }

    // Google Drive & Primary Services Import Actions
    fun setDriveAccessToken(token: String) {
        _driveAccessToken.value = token
        cryptoPrefs.driveOAuthToken = token
    }

    fun loadDriveFiles() {
        val token = _driveAccessToken.value.trim()
        if (token.isBlank()) {
            _toastNotice.value = "Nessun token OAuth Google Drive attivo"
            return
        }

        _isLoadingDriveFiles.value = true
        viewModelScope.launch {
            val result = driveService.listDriveFiles(token)
            result.onSuccess { files ->
                _driveFiles.value = files
                _isLoadingDriveFiles.value = false
            }.onFailure { err ->
                _toastNotice.value = "Errore lettura Google Drive: ${err.message}"
                _isLoadingDriveFiles.value = false
            }
        }
    }

    fun importDriveFile(file: com.example.data.drive.DriveFileItem) {
        val token = _driveAccessToken.value.trim()
        if (token.isBlank()) {
            _toastNotice.value = "Token OAuth mancante"
            return
        }

        _isImportingDocument.value = true
        _importedSourceFileName.value = file.name
        _importedDocumentPreview.value = null

        viewModelScope.launch {
            val contentResult = driveService.fetchFileContent(token, file)
            contentResult.onSuccess { textContent ->
                if (textContent.isBlank()) {
                    _toastNotice.value = "Il file selezionato è vuoto"
                    _isImportingDocument.value = false
                    return@launch
                }
                val extracted = cloneEngine.analyzeAndCategorizeDocument(
                    fileName = file.name,
                    fileContent = textContent,
                    cloneName = cryptoPrefs.cloneName
                )
                _importedDocumentPreview.value = extracted
                _isImportingDocument.value = false
            }.onFailure { err ->
                _toastNotice.value = "Errore download file da Drive: ${err.message}"
                _isImportingDocument.value = false
            }
        }
    }

    fun importLocalFile(uri: android.net.Uri) {
        _isImportingDocument.value = true
        _importedDocumentPreview.value = null

        viewModelScope.launch {
            val fileRes = driveService.readLocalFileContent(uri)
            fileRes.onSuccess { (name, content) ->
                _importedSourceFileName.value = name
                if (content.isBlank()) {
                    _toastNotice.value = "Il file selezionato è vuoto"
                    _isImportingDocument.value = false
                    return@launch
                }
                val extracted = cloneEngine.analyzeAndCategorizeDocument(
                    fileName = name,
                    fileContent = content,
                    cloneName = cryptoPrefs.cloneName
                )
                _importedDocumentPreview.value = extracted
                _isImportingDocument.value = false
            }.onFailure { err ->
                _toastNotice.value = "Errore lettura file locale: ${err.message}"
                _isImportingDocument.value = false
            }
        }
    }

    fun commitImportedDocumentToBrain(result: com.example.ai.ExtractedMemoryResult) {
        viewModelScope.launch {
            val contentText = buildString {
                appendLine(result.content)
                if (result.keyInsights.isNotEmpty()) {
                    appendLine("\n✨ **Punti Salienti & Dati Estratti:**")
                    result.keyInsights.forEach { appendLine("• $it") }
                }
                appendLine("\n📁 **Fonte Esterna:** ${_importedSourceFileName.value}")
                appendLine("💫 **Risonanza:** ${result.emotionalResonance}")
                if (!result.suggestedAction.isNullOrBlank()) {
                    appendLine("📌 **Azione Consigliata:** ${result.suggestedAction}")
                }
            }

            val targetLobeEnum = try {
                BrainLobe.valueOf(result.targetLobe)
            } catch (e: Exception) {
                BrainLobe.FRONTAL
            }

            val newItem = BrainItem(
                title = result.title,
                content = contentText,
                lobeType = targetLobeEnum.id,
                category = result.category,
                tags = result.tags.joinToString(", "),
                isEncrypted = false
            )

            repository.insert(newItem)
            _toastNotice.value = "Documento '${result.title}' integrato nel ${targetLobeEnum.title}!"
            _importedDocumentPreview.value = null
            _importedSourceFileName.value = ""
        }
    }

    fun clearImportPreview() {
        _importedDocumentPreview.value = null
        _importedSourceFileName.value = ""
    }

    fun clearChat() {
        viewModelScope.launch {
            chatRepo.clearHistory()
            chatRepo.saveEncryptedMessage(
                sender = MessageSender.CLONE,
                plainText = "Memoria di dialogo azzerata e bonificata crittograficamente (AES-256). Sono pronto per una nuova conversazione!",
                modelName = cloneEngine.currentModel
            )
            _toastNotice.value = "Cronologia chat cancellata in sicurezza"
        }
    }

    fun clearToastNotice() {
        _toastNotice.value = null
    }

    fun resetBrainToDefaults() {
        viewModelScope.launch {
            repository.clearAll()
            repository.seedInitialBrainDataIfEmpty()
            _toastNotice.value = "Cervello Digitale ripristinato con sinapsi di default"
        }
    }

    // Auth actions
    fun signInWithGoogle() {
        viewModelScope.launch {
            val result = authManager.signInWithGoogle()
            result.onSuccess { user ->
                _currentUser.value = user
                _toastNotice.value = "Accesso effettuato: ${user.displayName}"
            }.onFailure { err ->
                _toastNotice.value = "Errore di accesso: ${err.message}"
            }
        }
    }

    fun signOut() {
        authManager.signOut()
        _currentUser.value = null
        _toastNotice.value = "Disconnessione effettuata"
    }
}

