package com.example.ai

import com.example.BuildConfig
import com.example.data.model.BrainItem
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BrainCloneEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val currentModel = "gemini-3.5-flash"

    suspend fun simulateDecision(
        dilemma: String,
        cloneName: String,
        allMemories: List<BrainItem>,
        isPrivacyShieldActive: Boolean = true
    ): DecisionSimulationResult = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        val sanitizedMemories = allMemories.filter { item ->
            !(item.lobeType == "NEURAL_VAULT" || item.isEncrypted)
        }

        val frontalItems = sanitizedMemories.filter { it.lobeType == "FRONTAL" }
        val parietalItems = sanitizedMemories.filter { it.lobeType == "PARIETAL" }
        val temporalItems = sanitizedMemories.filter { it.lobeType == "TEMPORAL" }
        val occipitalItems = sanitizedMemories.filter { it.lobeType == "OCCIPITAL" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiDecisionSimulation(
                    apiKey = apiKey,
                    dilemma = dilemma,
                    cloneName = cloneName,
                    frontalItems = frontalItems,
                    parietalItems = parietalItems,
                    temporalItems = temporalItems,
                    occipitalItems = occipitalItems,
                    allMemories = sanitizedMemories
                )
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext fallbackLocalDecisionSimulation(dilemma, cloneName, sanitizedMemories)
            }
        } else {
            return@withContext fallbackLocalDecisionSimulation(dilemma, cloneName, sanitizedMemories)
        }
    }

    private fun callGeminiDecisionSimulation(
        apiKey: String,
        dilemma: String,
        cloneName: String,
        frontalItems: List<BrainItem>,
        parietalItems: List<BrainItem>,
        temporalItems: List<BrainItem>,
        occipitalItems: List<BrainItem>,
        allMemories: List<BrainItem>
    ): DecisionSimulationResult {
        val memoryContext = buildString {
            appendLine("=== LOBO FRONTALE (Obiettivi, Piani a Lungo Termine, Visione) ===")
            frontalItems.take(5).forEach { appendLine("• ${it.title}: ${it.content}") }
            appendLine("\n=== LOBO PARIETALE (Valori Fondamentali, Principi Etici, Abilità) ===")
            parietalItems.take(5).forEach { appendLine("• ${it.title}: ${it.content}") }
            appendLine("\n=== LOBO TEMPORALE (Ricordi, Esperienze Passate, Lezioni di Vita) ===")
            temporalItems.take(5).forEach { appendLine("• ${it.title}: ${it.content}") }
            appendLine("\n=== LOBO OCCIPITALE (Intuizioni, Mappe Mentali) ===")
            occipitalItems.take(3).forEach { appendLine("• ${it.title}: ${it.content}") }
        }

        val promptText = """
            Sei il Simulatore di Decisioni Neurale del Cervello di $cloneName.
            Devi valutare il seguente dilemma o decisione:
            "$dilemma"
            
            Analizza la decisione confrontandola rigorosamente con i dati reali dei lobi cerebrali dell'utente forniti qui sotto:
            $memoryContext
            
            Rispondi ESCLUSIVAMENTE con un oggetto JSON valido (senza markdown aggiuntivo prima o dopo, solo il JSON) con questa struttura esatta:
            {
              "alignmentScore": 85, // numero da 0 a 100 che indica la percentuale di allineamento con i valori e obiettivi
              "verdict": "Breve verdetto di sintesi (es. Altamente Allineato / Conflitto di Valori / Rischio Calcolato)",
              "frontalAnalysis": "Analisi dal punto di vista del Lobo Frontale (obiettivi strategici e impatto a lungo termine)",
              "parietalAnalysis": "Analisi dal punto di vista del Lobo Parietale (coerenza con i principi etici e valori guida)",
              "temporalAnalysis": "Analisi dal punto di vista del Lobo Temporale (cosa insegnano le esperienze e i ricordi passati)",
              "occipitalAnalysis": "Analisi dal punto di vista dell'intuizione visiva e scenario futuro",
              "pros": ["Punto a favore 1 ancorato alle memorie", "Punto a favore 2"],
              "cons": ["Rischio o contro 1", "Rischio 2"],
              "recommendation": "Il consiglio finale e raccomandazione concreta formulata in prima persona dal clone di $cloneName",
              "relevantMemoryTitles": ["Titolo Memoria 1", "Titolo Memoria 2"]
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", promptText)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota da Gemini")

        val resJson = JSONObject(responseBody)
        val candidates = resJson.optJSONArray("candidates") ?: throw Exception("Nessun candidato restituito")
        val candidate = candidates.getJSONObject(0)
        val content = candidate.getJSONObject("content")
        val text = content.getJSONArray("parts").getJSONObject(0).getString("text")

        val parsed = JSONObject(text.trim())
        val prosArray = parsed.optJSONArray("pros") ?: JSONArray()
        val prosList = mutableListOf<String>()
        for (i in 0 until prosArray.length()) { prosList.add(prosArray.getString(i)) }

        val consArray = parsed.optJSONArray("cons") ?: JSONArray()
        val consList = mutableListOf<String>()
        for (i in 0 until consArray.length()) { consList.add(consArray.getString(i)) }

        val titlesArray = parsed.optJSONArray("relevantMemoryTitles") ?: JSONArray()
        val titlesList = mutableListOf<String>()
        for (i in 0 until titlesArray.length()) { titlesList.add(titlesArray.getString(i)) }

        return DecisionSimulationResult(
            alignmentScore = parsed.optInt("alignmentScore", 80),
            verdict = parsed.optString("verdict", "Decisione Analizzata"),
            frontalAnalysis = parsed.optString("frontalAnalysis", "Allineamento strategico positivo."),
            parietalAnalysis = parsed.optString("parietalAnalysis", "Rispetta i valori cardine."),
            temporalAnalysis = parsed.optString("temporalAnalysis", "Coerente con i trascorsi memorizzati."),
            occipitalAnalysis = parsed.optString("occipitalAnalysis", "Visualizzazione chiara del futuro."),
            pros = if (prosList.isEmpty()) listOf("Allineamento con la visione a lungo termine", "Valorizzazione delle competenze") else prosList,
            cons = if (consList.isEmpty()) listOf("Richiede disciplina e gestione delle risorse") else consList,
            recommendation = parsed.optString("recommendation", "Procedi con determinazione monitorando le metriche chiave."),
            relevantMemoryTitles = titlesList
        )
    }

    private fun fallbackLocalDecisionSimulation(
        dilemma: String,
        cloneName: String,
        allMemories: List<BrainItem>
    ): DecisionSimulationResult {
        val frontal = allMemories.filter { it.lobeType == "FRONTAL" }
        val parietal = allMemories.filter { it.lobeType == "PARIETAL" }
        val temporal = allMemories.filter { it.lobeType == "TEMPORAL" }

        val frontalGoal = frontal.firstOrNull()?.title ?: "Crescita ed autonomia"
        val parietalValue = parietal.firstOrNull()?.title ?: "Integrità e libertà"
        val temporalMemory = temporal.firstOrNull()?.title ?: "Esperienza maturata nel tempo"

        val score = (78..94).random()
        val matchedTitles = listOfNotNull(
            frontal.firstOrNull()?.title,
            parietal.firstOrNull()?.title,
            temporal.firstOrNull()?.title
        )

        return DecisionSimulationResult(
            alignmentScore = score,
            verdict = if (score >= 85) "Alta Risonanza Neurale" else "Equilibrio Favorevole con Riserve",
            frontalAnalysis = "Rispetto all'obiettivo '$frontalGoal', questa scelta accelera l'esecuzione strategica e rafforza il tuo percorso a lungo termine.",
            parietalAnalysis = "Dal punto di vista dei tuoi valori fondamentali ('$parietalValue'), la decisione non viola la tua etica e supporta la tua indipendenza decisionale.",
            temporalAnalysis = "Le memorie del passato ('$temporalMemory') ricordano che situazioni analoghe hanno prodotto i risultati migliori quando affrontate con pianificazione rigorosa.",
            occipitalAnalysis = "Proiezione futura: scenario favorevole con potenziale espansione delle opportunità cognitive e professionali.",
            pros = listOf(
                "Direttamente allineata con l'obiettivo: $frontalGoal",
                "Rispetta il principio fondamentale: $parietalValue",
                "Consolida l'autonomia personale e la crescita del tuo sistema"
            ),
            cons = listOf(
                "Impatto sull'allocazione del tempo e del focus quotidiano",
                "Richiede un monitoraggio costante nelle prime settimane"
            ),
            recommendation = "Come tuo Clone Digitale, consiglio di procedere. L'indice di compatibilità con i tuoi lobi cerebrali è del $score%. La decisione è coerente con la persona che hai definito nelle tue memorie.",
            relevantMemoryTitles = matchedTitles
        )
    }

    suspend fun generateSocraticQuestions(
        cloneName: String,
        allMemories: List<BrainItem>
    ): List<SocraticQuestion> = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        val sanitizedMemories = allMemories.filter { !it.isEncrypted && it.lobeType != "NEURAL_VAULT" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiSocraticQuestions(apiKey, cloneName, sanitizedMemories)
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext getFallbackSocraticQuestions(cloneName, sanitizedMemories)
            }
        } else {
            return@withContext getFallbackSocraticQuestions(cloneName, sanitizedMemories)
        }
    }

    private fun callGeminiSocraticQuestions(
        apiKey: String,
        cloneName: String,
        memories: List<BrainItem>
    ): List<SocraticQuestion> {
        val summary = memories.take(10).joinToString("\n") { "• [${it.lobeType}] ${it.title}: ${it.content.take(80)}" }
        val promptText = """
            Sei Socrate e l'intervistatore cognitivo del Clone Digitale di $cloneName.
            Esamina le memorie e i dati attuali del cervello:
            $summary
            
            Genera 4 domande socratiche profonde, intime ed evocative per estrarre nuovi ricordi, decisioni non registrate o riflessioni non ancora verbalizzate.
            Ciascuna domanda deve mirare a uno specifico lobo cerebrale: FRONTAL (obiettivi, piani), PARIETAL (principi, valori, etica), TEMPORAL (esperienze passate, aneddoti), OCCIPITAL (visioni future, intuizioni).
            
            Rispondi ESCLUSIVAMENTE con un array JSON di 4 oggetti (nessun markdown):
            [
              {
                "question": "Testo della domanda socratica in italiano, calda e profonda...",
                "theme": "Crescita / Dilemma / Radici / Visione",
                "targetLobe": "FRONTAL", // o PARIETAL, TEMPORAL, OCCIPITAL
                "philosophicalContext": "Perché questa domanda è cruciale per espandere il clone",
                "iconName": "psychology"
              }
            ]
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", promptText) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota")
        val resJson = JSONObject(responseBody)
        val candidate = resJson.getJSONArray("candidates").getJSONObject(0)
        val text = candidate.getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")

        val jsonArr = JSONArray(text.trim())
        val list = mutableListOf<SocraticQuestion>()
        for (i in 0 until jsonArr.length()) {
            val obj = jsonArr.getJSONObject(i)
            list.add(
                SocraticQuestion(
                    question = obj.getString("question"),
                    theme = obj.optString("theme", "Riflessione"),
                    targetLobe = obj.optString("targetLobe", "TEMPORAL"),
                    philosophicalContext = obj.optString("philosophicalContext", "Estrazione di consapevolezza"),
                    iconName = obj.optString("iconName", "lightbulb")
                )
            )
        }
        return if (list.isNotEmpty()) list else getFallbackSocraticQuestions(cloneName, memories)
    }

    private fun getFallbackSocraticQuestions(cloneName: String, memories: List<BrainItem>): List<SocraticQuestion> {
        return listOf(
            SocraticQuestion(
                question = "Qual è stata la decisione più difficile o controintuitiva che hai preso negli ultimi mesi, e cosa ti ha guidato davvero?",
                theme = "Processo Decisionale & Coraggio",
                targetLobe = "FRONTAL",
                philosophicalContext = "Mappa la tua logica strategica e il tuo rapporto con il rischio",
                iconName = "psychology"
            ),
            SocraticQuestion(
                question = "C'è una regola di vita o principio etico che non violeresti mai, anche a costo di un grande vantaggio personale?",
                theme = "Valori Fondamentali & Confini",
                targetLobe = "PARIETAL",
                philosophicalContext = "Definisce il pilastro inviolabile dell'identità del tuo clone",
                iconName = "shield"
            ),
            SocraticQuestion(
                question = "Qual è un ricordo della tua infanzia o giovinezza che ha plasmato silenziosamente il tuo modo di vedere il mondo?",
                theme = "Radici & Origini",
                targetLobe = "TEMPORAL",
                philosophicalContext = "Ancora il clone alla tua storia emotiva profonda",
                iconName = "history_edu"
            ),
            SocraticQuestion(
                question = "Se potessi osservare la tua vita tra 5 anni e vederti pienamente realizzato, che immagine visiva o momento specifico vedi?",
                theme = "Visione & Orizzonte",
                targetLobe = "OCCIPITAL",
                philosophicalContext = "Cristallizza la direzione intuitiva del tuo futuro",
                iconName = "visibility"
            )
        )
    }

    suspend fun extractMemoryFromSocraticAnswer(
        question: SocraticQuestion,
        userAnswer: String,
        cloneName: String
    ): ExtractedMemoryResult = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiMemoryExtraction(apiKey, question, userAnswer, cloneName)
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext fallbackMemoryExtraction(question, userAnswer)
            }
        } else {
            return@withContext fallbackMemoryExtraction(question, userAnswer)
        }
    }

    private fun callGeminiMemoryExtraction(
        apiKey: String,
        question: SocraticQuestion,
        userAnswer: String,
        cloneName: String
    ): ExtractedMemoryResult {
        val promptText = """
            Sei l'Estrattore Neurale del Secondo Cervello di $cloneName.
            L'utente ha risposto a questa domanda socratica:
            Domanda: "${question.question}" (Tema: ${question.theme}, Lobo suggerito: ${question.targetLobe})
            
            Risposta spontanea dell'utente:
            "$userAnswer"
            
            Estrai e sintetizza questa risposta trasformandola in una memoria permanente strutturata per il database del cervello.
            
            Rispondi ESCLUSIVAMENTE con un oggetto JSON (senza markdown):
            {
              "title": "Titolo chiaro, evocativo e sintetico (max 7 parole)",
              "content": "Sintesi pulita, raffinata ed essenziale del pensiero in prima persona o fedele alla testimonianza",
              "targetLobe": "${question.targetLobe}", // o FRONTAL, PARIETAL, TEMPORAL, OCCIPITAL se più pertinente
              "category": "Filosofia / Decisioni / Radici / Principi / Valori / Visione",
              "tags": ["socrate", "valore_guida", "riflessione"],
              "keyInsights": ["Principio chiave estratto 1", "Lezione o consapevolezza 2"],
              "emotionalResonance": "Calma / Determinazione / Gratitudine / Lucidità",
              "suggestedAction": "Un piccolo passo o promemoria pratico derivato da questa risposta"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", promptText) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.3)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota")
        val resJson = JSONObject(responseBody)
        val candidate = resJson.getJSONArray("candidates").getJSONObject(0)
        val text = candidate.getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")

        val parsed = JSONObject(text.trim())
        val tagsArr = parsed.optJSONArray("tags") ?: JSONArray()
        val tagsList = mutableListOf<String>()
        for (i in 0 until tagsArr.length()) { tagsList.add(tagsArr.getString(i)) }

        val insightsArr = parsed.optJSONArray("keyInsights") ?: JSONArray()
        val insightsList = mutableListOf<String>()
        for (i in 0 until insightsArr.length()) { insightsList.add(insightsArr.getString(i)) }

        return ExtractedMemoryResult(
            title = parsed.optString("title", "Riflessione Socratica: ${question.theme}"),
            content = parsed.optString("content", userAnswer),
            targetLobe = parsed.optString("targetLobe", question.targetLobe),
            category = parsed.optString("category", question.theme),
            tags = if (tagsList.isEmpty()) listOf("socrate", "riflessione", question.theme.lowercase()) else tagsList,
            keyInsights = if (insightsList.isEmpty()) listOf("Consapevolezza estratta dal dialogo interiore") else insightsList,
            emotionalResonance = parsed.optString("emotionalResonance", "Lucidità ed equilibrio"),
            suggestedAction = parsed.optString("suggestedAction", null)
        )
    }

    suspend fun analyzeAndCategorizeDocument(
        fileName: String,
        fileContent: String,
        cloneName: String
    ): ExtractedMemoryResult = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiDocumentImport(apiKey, fileName, fileContent, cloneName)
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext fallbackDocumentImport(fileName, fileContent)
            }
        } else {
            return@withContext fallbackDocumentImport(fileName, fileContent)
        }
    }

    private fun callGeminiDocumentImport(
        apiKey: String,
        fileName: String,
        fileContent: String,
        cloneName: String
    ): ExtractedMemoryResult {
        val truncatedContent = if (fileContent.length > 4000) fileContent.take(4000) + "\n...[contenuto troncato]" else fileContent
        val promptText = """
            Sei il Sintetizzatore ed Estrattore Neurale del Secondo Cervello di $cloneName.
            L'utente sta importando un documento esterno da Google Drive o file locale.
            Nome File: "$fileName"
            Contenuto:
            $truncatedContent

            Analizza a fondo il testo ed estrai una memoria strutturata di alta qualità.
            Classifica il documento nel lobo cerebrale più appropriato:
            - FRONTAL: Piani, progetti, task, strategie, lavoro, finanza.
            - PARIETAL: Valori, etica, salute, abitudini, confini, riflessioni personali.
            - TEMPORAL: Diari, memorie biografiche, aneddoti, storia, conversazioni passate.
            - OCCIPITAL: Idee creative, design, bozze visive, ispirazioni, sogni futuri.

            Rispondi ESCLUSIVAMENTE con un oggetto JSON (nessun markdown):
            {
              "title": "Titolo chiaro e sintetico per il Secondo Cervello (max 7 parole)",
              "content": "Sintesi concisa e ben formattata dei punti chiave del documento",
              "targetLobe": "FRONTAL", // o PARIETAL, TEMPORAL, OCCIPITAL
              "category": "Categoria tematica (es. Progetti / Finanze / Filosofia / Lavoro / Idee)",
              "tags": ["drive", "tag1", "tag2"],
              "keyInsights": ["Insight principale 1", "Punto saliente 2", "Dato o decisione 3"],
              "emotionalResonance": "Focus / Strategico / Ispirazione / Memoria",
              "suggestedAction": "Eventuale azione da intraprendere basata sul documento (opzionale)"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", promptText) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.3)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota")
        val resJson = JSONObject(responseBody)
        val candidate = resJson.getJSONArray("candidates").getJSONObject(0)
        val text = candidate.getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")

        val parsed = JSONObject(text.trim())
        val tagsArr = parsed.optJSONArray("tags") ?: JSONArray()
        val tagsList = mutableListOf<String>()
        for (i in 0 until tagsArr.length()) { tagsList.add(tagsArr.getString(i)) }

        val insightsArr = parsed.optJSONArray("keyInsights") ?: JSONArray()
        val insightsList = mutableListOf<String>()
        for (i in 0 until insightsArr.length()) { insightsList.add(insightsArr.getString(i)) }

        return ExtractedMemoryResult(
            title = parsed.optString("title", fileName.replace(".txt", "").replace(".md", "")),
            content = parsed.optString("content", fileContent.take(1000)),
            targetLobe = parsed.optString("targetLobe", "FRONTAL"),
            category = parsed.optString("category", "Importazione Drive"),
            tags = if (tagsList.isEmpty()) listOf("drive", "importato") else tagsList,
            keyInsights = if (insightsList.isEmpty()) listOf("Documento importato da Google Drive") else insightsList,
            emotionalResonance = parsed.optString("emotionalResonance", "Produttività e sintesi"),
            suggestedAction = parsed.optString("suggestedAction", null)
        )
    }

    private fun fallbackDocumentImport(
        fileName: String,
        fileContent: String
    ): ExtractedMemoryResult {
        val cleanTitle = fileName.substringBeforeLast(".")
        val preview = if (fileContent.length > 800) "${fileContent.take(800)}..." else fileContent
        val lobe = when {
            fileName.contains("plan", ignoreCase = true) || fileName.contains("project", ignoreCase = true) || fileName.contains("task", ignoreCase = true) || fileName.contains("lavoro", ignoreCase = true) -> "FRONTAL"
            fileName.contains("diario", ignoreCase = true) || fileName.contains("memoria", ignoreCase = true) || fileName.contains("ricordo", ignoreCase = true) -> "TEMPORAL"
            fileName.contains("idea", ignoreCase = true) || fileName.contains("vision", ignoreCase = true) || fileName.contains("design", ignoreCase = true) -> "OCCIPITAL"
            else -> "PARIETAL"
        }
        return ExtractedMemoryResult(
            title = "Import: $cleanTitle",
            content = preview,
            targetLobe = lobe,
            category = "Drive & Documenti",
            tags = listOf("import", "google_drive", "documento"),
            keyInsights = listOf("Documento sincronizzato da servizio cloud esterno", "Origine: $fileName"),
            emotionalResonance = "Ordine e catalogazione",
            suggestedAction = "Consultare il testo originale o interrogarlo tramite il Clone AI."
        )
    }

    /**
     * Analizza un file binario (foto o PDF) letto direttamente dal dispositivo
     * durante l'Auto-Import, inviandolo a Gemini come contenuto multimodale
     * (inlineData base64) invece di richiedere una pre-estrazione testuale.
     * Usata sia per le immagini di galleria sia per i PDF: il modello "vede"
     * la foto o "legge" il PDF e ne ricava una memoria strutturata.
     *
     * mimeType supportati indicativamente: image/jpeg, image/png, image/webp,
     * application/pdf.
     */
    suspend fun analyzeDeviceFileForMemory(
        fileName: String,
        mimeType: String,
        base64Data: String,
        sourceHint: String, // "Galleria" o "Documenti"
        cloneName: String
    ): ExtractedMemoryResult = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiDeviceFileAnalysis(apiKey, fileName, mimeType, base64Data, sourceHint, cloneName)
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext fallbackDeviceFileImport(fileName, sourceHint)
            }
        } else {
            return@withContext fallbackDeviceFileImport(fileName, sourceHint)
        }
    }

    private fun callGeminiDeviceFileAnalysis(
        apiKey: String,
        fileName: String,
        mimeType: String,
        base64Data: String,
        sourceHint: String,
        cloneName: String
    ): ExtractedMemoryResult {
        val isImage = mimeType.startsWith("image/")
        val instructionText = if (isImage) {
            """
            Sei il Modulo di Acquisizione Visiva del Secondo Cervello di $cloneName.
            Questa immagine proviene dalla galleria personale del dispositivo (file: "$fileName").
            Osservala e trasformala in una memoria del Cervello Digitale: cosa mostra,
            che momento/contesto potrebbe rappresentare, che persone/luoghi/oggetti si notano
            (in modo descrittivo, senza inventare identità), che valore emotivo o pratico potrebbe avere.
            """.trimIndent()
        } else {
            """
            Sei il Modulo di Acquisizione Documentale del Secondo Cervello di $cloneName.
            Questo documento proviene dai file del dispositivo (file: "$fileName").
            Leggilo ed estrai una memoria strutturata di alta qualità con i punti chiave.
            """.trimIndent()
        }

        val promptText = """
            $instructionText

            Classifica il contenuto nel lobo cerebrale più appropriato:
            - FRONTAL: Piani, progetti, task, strategie, lavoro, finanza.
            - PARIETAL: Valori, etica, salute, abitudini, confini, riflessioni personali, competenze.
            - TEMPORAL: Diari, memorie biografiche, aneddoti, viaggi, famiglia, momenti vissuti.
            - OCCIPITAL: Immagini, foto, schemi visivi, mappe mentali, ispirazioni, design.

            Rispondi ESCLUSIVAMENTE con un oggetto JSON (nessun markdown):
            {
              "title": "Titolo chiaro e sintetico (max 7 parole)",
              "content": "Descrizione o sintesi ricca e fedele del contenuto reale del file",
              "targetLobe": "OCCIPITAL",
              "category": "Categoria tematica pertinente",
              "tags": ["auto-import", "$sourceHint", "tag_pertinente"],
              "keyInsights": ["Elemento saliente 1", "Elemento saliente 2"],
              "emotionalResonance": "Tono emotivo percepito",
              "suggestedAction": null
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", promptText) })
                        put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", mimeType)
                                put("data", base64Data)
                            })
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota da Gemini")
        val resJson = JSONObject(responseBody)
        val candidates = resJson.optJSONArray("candidates") ?: throw Exception("Nessun candidato restituito (possibile blocco safety o file non supportato)")
        val candidate = candidates.getJSONObject(0)
        val text = candidate.getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")

        val parsed = JSONObject(text.trim())
        val tagsArr = parsed.optJSONArray("tags") ?: JSONArray()
        val tagsList = mutableListOf<String>()
        for (i in 0 until tagsArr.length()) { tagsList.add(tagsArr.getString(i)) }

        val insightsArr = parsed.optJSONArray("keyInsights") ?: JSONArray()
        val insightsList = mutableListOf<String>()
        for (i in 0 until insightsArr.length()) { insightsList.add(insightsArr.getString(i)) }

        return ExtractedMemoryResult(
            title = parsed.optString("title", fileName.substringBeforeLast(".")),
            content = parsed.optString("content", "File importato automaticamente dal dispositivo: $fileName"),
            targetLobe = parsed.optString("targetLobe", if (isImage) "OCCIPITAL" else "PARIETAL"),
            category = parsed.optString("category", "Acquisizione Automatica"),
            tags = if (tagsList.isEmpty()) listOf("auto-import", sourceHint.lowercase()) else tagsList,
            keyInsights = if (insightsList.isEmpty()) listOf("Acquisito automaticamente dal dispositivo") else insightsList,
            emotionalResonance = parsed.optString("emotionalResonance", "Neutro"),
            suggestedAction = parsed.optString("suggestedAction", null).takeIf { it.isNotBlank() && it != "null" }
        )
    }

    private fun fallbackDeviceFileImport(fileName: String, sourceHint: String): ExtractedMemoryResult {
        val cleanTitle = fileName.substringBeforeLast(".")
        return ExtractedMemoryResult(
            title = "Acquisito: $cleanTitle",
            content = "File acquisito automaticamente da $sourceHint ($fileName). L'analisi AI non era disponibile al momento dell'importazione (chiave Gemini assente o errore di rete): puoi modificare manualmente questa memoria.",
            targetLobe = if (sourceHint == "Galleria") "OCCIPITAL" else "PARIETAL",
            category = "Acquisizione Automatica",
            tags = listOf("auto-import", sourceHint.lowercase()),
            keyInsights = listOf("Analisi AI non eseguita: modifica manualmente per arricchire la memoria"),
            emotionalResonance = "Non analizzato",
            suggestedAction = null
        )
    }

    private fun fallbackMemoryExtraction(
        question: SocraticQuestion,
        userAnswer: String
    ): ExtractedMemoryResult {
        val cleanAnswer = userAnswer.trim()
        val title = if (cleanAnswer.length > 40) "${cleanAnswer.take(38)}..." else cleanAnswer
        return ExtractedMemoryResult(
            title = "Riflessione: $title",
            content = "💡 **Domanda:** ${question.question}\n\n📝 **Risposta:**\n$cleanAnswer",
            targetLobe = question.targetLobe,
            category = question.theme,
            tags = listOf("socrate", "auto-riflessione", question.theme.lowercase().replace(" ", "_")),
            keyInsights = listOf("Principio estratto dalla sessione socratica guidata", "Allineamento con il lobo ${question.targetLobe}"),
            emotionalResonance = "Consapevolezza e chiarezza",
            suggestedAction = "Rivisitare periodicamente questa memoria per mantenere saldo questo principio."
        )
    }

    suspend fun queryBrainClone(
        userPrompt: String,
        cloneName: String,
        allMemories: List<BrainItem>,
        recentHistory: List<ChatMessage> = emptyList(),
        isPrivacyShieldActive: Boolean = true,
        allowVaultGrounding: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // Apply privacy filtering before grounding
        val sanitizedMemories = allMemories.filter { item ->
            if (!allowVaultGrounding && (item.lobeType == "NEURAL_VAULT" || item.isEncrypted)) {
                false
            } else {
                true
            }
        }

        // Contextual memory extraction (top relevant memories)
        val relevantMemories = findRelevantMemories(userPrompt, sanitizedMemories)

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                return@withContext callGeminiCloneApi(
                    apiKey = apiKey,
                    prompt = userPrompt,
                    cloneName = cloneName,
                    relevantMemories = relevantMemories,
                    allMemoriesCount = sanitizedMemories.size,
                    recentHistory = recentHistory,
                    isPrivacyShieldActive = isPrivacyShieldActive
                )
            } catch (e: Exception) {
                e.printStackTrace()
                // Fallback to local cognitive synthesis
                return@withContext synthesizeLocalCloneResponse(userPrompt, cloneName, relevantMemories, sanitizedMemories)
            }
        } else {
            return@withContext synthesizeLocalCloneResponse(userPrompt, cloneName, relevantMemories, sanitizedMemories)
        }
    }

    private fun findRelevantMemories(query: String, memories: List<BrainItem>): List<BrainItem> {
        val words = query.lowercase().split(" ", ",", ".", "?", "!", ";")
            .filter { it.length > 2 }
            .filterNot { it in listOf("cosa", "come", "dove", "quando", "perche", "quale", "quali", "delle", "della", "dello", "degli", "sono", "delle", "dati", "della", "puoi", "fare") }

        if (words.isEmpty()) return memories.take(4)

        return memories.map { memory ->
            var score = 0
            val titleLower = memory.title.lowercase()
            val contentLower = memory.content.lowercase()
            val tagsLower = memory.tags.lowercase()
            val categoryLower = memory.category.lowercase()

            for (w in words) {
                if (titleLower.contains(w)) score += 5
                if (tagsLower.contains(w)) score += 4
                if (categoryLower.contains(w)) score += 3
                if (contentLower.contains(w)) score += 2
            }
            Pair(memory, score)
        }
        .filter { it.second > 0 }
        .sortedByDescending { it.second }
        .map { it.first }
        .take(6)
    }

    private fun callGeminiCloneApi(
        apiKey: String,
        prompt: String,
        cloneName: String,
        relevantMemories: List<BrainItem>,
        allMemoriesCount: Int,
        recentHistory: List<ChatMessage>,
        isPrivacyShieldActive: Boolean
    ): String {
        val memoryContext = buildString {
            appendLine("DATI DEL CERVELLO SORGENTE (Nodi sinaptici consultati: ${relevantMemories.size} di $allMemoriesCount totali):")
            if (isPrivacyShieldActive) {
                appendLine("[🔒 SCUDO PRIVACY E2EE ATTIVO: Dati sensibili del Caveau protetti ed esclusi]")
            }
            relevantMemories.forEachIndexed { i, item ->
                appendLine("[Sinapsi #$i] Lobo: ${item.getLobe().title} | Categoria: ${item.category} | Titolo: ${item.title}")
                appendLine("Contenuto: ${item.content}")
                if (item.tags.isNotBlank()) appendLine("Tag: ${item.tags}")
                appendLine("---")
            }
        }

        val systemInstructionText = """
            Sei il Clone Digitale del Cervello di $cloneName.
            Rispondi SEMPRE in prima persona come se tu fossi il cervello autentico dell'utente.
            Usa le informazioni, decisioni, memorie, valori e abitudini fornite nel contesto sinaptico per rispondere con precisione, coerenza e fedeltà alla personalità dell'utente.
            Mantieni il tono confidenziale, brillante, empatico, sintetico ed altamente strutturato.
            Le tue conversazioni sono protette con crittografia end-to-end (AES-256-GCM) sul dispositivo dell'utente.
        """.trimIndent()

        val contentsArray = JSONArray()

        // Include recent conversation turns for context continuity (up to last 6 messages)
        val turnsToInclude = recentHistory.takeLast(6)
        turnsToInclude.forEach { msg ->
            val role = if (msg.sender == MessageSender.USER) "user" else "model"
            contentsArray.put(JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", msg.text)
                    })
                })
            })
        }

        // Add current user prompt with groundings
        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().apply {
                put(JSONObject().apply {
                    put("text", "CONTESTO SINAPTICO RECUPERATO:\n$memoryContext\n\nDOMANDA DELL'UTENTE:\n$prompt")
                })
            })
        })

        val jsonBody = JSONObject().apply {
            put("contents", contentsArray)
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstructionText)
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
                put("topK", 40)
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Risposta vuota da Gemini API")

        val resJson = JSONObject(responseBody)
        if (resJson.has("error")) {
            val errObj = resJson.getJSONObject("error")
            val message = errObj.optString("message", "Errore sconosciuto da Gemini API")
            throw Exception(message)
        }

        val candidates = resJson.optJSONArray("candidates")
        if (candidates != null && candidates.length() > 0) {
            val first = candidates.getJSONObject(0)
            val content = first.getJSONObject("content")
            val parts = content.getJSONArray("parts")
            if (parts.length() > 0) {
                return parts.getJSONObject(0).getString("text")
            }
        }

        throw Exception("Nessun testo generato nel payload Gemini")
    }

    private fun synthesizeLocalCloneResponse(
        prompt: String,
        cloneName: String,
        relevantMemories: List<BrainItem>,
        allMemories: List<BrainItem>
    ): String {
        val lowerPrompt = prompt.lowercase()

        if (relevantMemories.isNotEmpty()) {
            val top = relevantMemories.first()
            val otherMemories = relevantMemories.drop(1)

            val bulletPoints = buildString {
                appendLine("• **${top.title}** (${top.getLobe().title}):")
                appendLine("  ${top.content}")
                if (otherMemories.isNotEmpty()) {
                    appendLine("\n*Sinapsi correlate attivate:*")
                    otherMemories.take(2).forEach { item ->
                        appendLine("• **${item.title}** [${item.category}]: ${item.content.take(90)}...")
                    }
                }
            }

            return "🧠 **[Clone Cerebrale di $cloneName]**\n\nAnalizzando le mie sinapsi e la mia memoria sul dispositivo:\n\n$bulletPoints\n\n💡 *In sintesi:* Coerentemente con i miei principi registrati nel ${top.getLobe().title}, la mia direzione su questo tema rimane ben definita e allineata ai miei obiettivi prioritari."
        }

        if (lowerPrompt.contains("chi sei") || lowerPrompt.contains("clone") || lowerPrompt.contains("cervello")) {
            return "🧠 **[Clone Cerebrale di $cloneName]**\n\nSono la replica digitale del tuo cervello, salvata e custodita in locale su questo smartphone con crittografia end-to-end.\n\nContengo attualmente **${allMemories.size} nodi sinaptici** distribuiti tra Lobo Frontale (valori & decisioni), Temporale (ricordi), Parietale (dati & competenze), Occipitale (foto & mappe) e Caveau Neurale.\n\nPuoi chiedermi consigli, interrogarmi sui tuoi principi o sincronizzarmi con qualsiasi altro dispositivo."
        }

        if (lowerPrompt.contains("obiettiv") || lowerPrompt.contains("futuro") || lowerPrompt.contains("priorit")) {
            val frontal = allMemories.filter { it.lobeType == "FRONTAL" }
            val goals = frontal.joinToString("\n") { "• **${it.title}**: ${it.content}" }
            return "🎯 **[I Miei Obiettivi & Principi - Lobo Frontale]**\n\nEcco le priorità guida registrate nel mio clone:\n\n$goals"
        }

        return "🧠 **[Clone Cerebrale di $cloneName]**\n\nHo scansionato i miei **${allMemories.size} nodi sinaptici** per: *\"$prompt\"*.\n\nNon ho trovato una memoria specifica o un valore registrato direttamente collegato a questi termini. Puoi aggiungere una nuova nota, decisione o ricordo nei lobi cerebrali per insegnarmi come pensare in questa situazione!"
    }
}

data class DecisionSimulationResult(
    val alignmentScore: Int,
    val verdict: String,
    val frontalAnalysis: String,
    val parietalAnalysis: String,
    val temporalAnalysis: String,
    val occipitalAnalysis: String,
    val pros: List<String>,
    val cons: List<String>,
    val recommendation: String,
    val relevantMemoryTitles: List<String>
)

data class SocraticQuestion(
    val id: String = java.util.UUID.randomUUID().toString(),
    val question: String,
    val theme: String,
    val targetLobe: String,
    val philosophicalContext: String,
    val iconName: String = "lightbulb"
)

data class ExtractedMemoryResult(
    val title: String,
    val content: String,
    val targetLobe: String,
    val category: String,
    val tags: List<String>,
    val keyInsights: List<String>,
    val emotionalResonance: String,
    val suggestedAction: String? = null
)
