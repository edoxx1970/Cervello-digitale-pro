package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ai.ExtractedMemoryResult
import com.example.ai.SocraticQuestion
import com.example.audio.SpeechState
import com.example.audio.SpeechToTextManager
import com.example.audio.TextToSpeechManager
import com.example.data.model.BrainLobe
import com.example.ui.theme.AmberNeon
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PinkVault
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletNeon
import com.example.ui.viewmodel.BrainViewModel
import kotlinx.coroutines.launch
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SocraticInterviewScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val questions by viewModel.socraticQuestions.collectAsState()
    val isLoadingQuestions by viewModel.isLoadingSocraticQuestions.collectAsState()
    val activeQuestion by viewModel.activeSocraticQuestion.collectAsState()
    val answerText by viewModel.socraticAnswerText.collectAsState()
    val isExtracting by viewModel.isExtractingMemory.collectAsState()
    val extractedResult by viewModel.extractedMemoryResult.collectAsState()

    val speechManager = remember { SpeechToTextManager(context) }
    val speechState by speechManager.speechState.collectAsState()
    val transcribedText by speechManager.transcribedText.collectAsState()
    val audioRmsDb by speechManager.audioRmsDb.collectAsState()

    val ttsManager = remember { TextToSpeechManager(context) }
    val isSpeaking by ttsManager.isSpeaking.collectAsState()

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            speechManager.startListening("it-IT")
        }
    }

    // Initialize Questions on mount
    LaunchedEffect(Unit) {
        if (questions.isEmpty()) {
            viewModel.loadSocraticQuestions()
        }
    }

    // Sync transcribed text into answer field
    LaunchedEffect(transcribedText) {
        if (transcribedText.isNotBlank()) {
            val current = viewModel.socraticAnswerText.value
            val updated = if (current.isBlank()) transcribedText else "$current $transcribedText"
            viewModel.setSocraticAnswerText(updated)
            speechManager.appendText("")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechManager.destroyRecognizer()
            ttsManager.shutdown()
        }
    }

    // Pulsing mic animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "micScale"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Banner: Socratic Extraction Engine
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                AmberNeon.copy(alpha = 0.16f),
                                VioletNeon.copy(alpha = 0.12f),
                                BackgroundDark
                            )
                        )
                    )
                    .border(1.dp, AmberNeon.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AmberNeon.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = AmberNeon,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "INTERVISTA SOCRATICA",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberNeon,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Maieutica & Estrazione Automatica dei Ricordi",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.loadSocraticQuestions() },
                        enabled = !isLoadingQuestions,
                        modifier = Modifier.size(32.dp)
                    ) {
                        if (isLoadingQuestions) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = AmberNeon, strokeWidth = 2.dp)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Nuove Domande",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Socrate interroga la tua coscienza. Rispondi con la tua voce o per iscritto: l'AI estrarrà i principi chiave, assegnerà il lobo biologico appropriato e salverà automaticamente la memoria nel tuo Secondo Cervello.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )
            }
        }

        // Horizontal Carousel of Socratic Questions
        item {
            Column {
                Text(
                    text = "SCEGLI UNA DOMANDA GUIDA",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    questions.forEach { q ->
                        val isSelected = activeQuestion?.id == q.id
                        val lobeColor = when (q.targetLobe) {
                            "FRONTAL" -> CyanNeon
                            "PARIETAL" -> VioletNeon
                            "TEMPORAL" -> AmberNeon
                            else -> EmeraldNeon
                        }

                        Box(
                            modifier = Modifier
                                .width(230.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) SurfaceCardElevated else SurfaceCard)
                                .border(
                                    if (isSelected) 1.5.dp else 1.dp,
                                    if (isSelected) lobeColor else SurfaceCardBorder,
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { viewModel.selectSocraticQuestion(q) }
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = q.theme.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = lobeColor
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(lobeColor.copy(alpha = 0.2f))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = q.targetLobe,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = lobeColor
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = q.question,
                                    fontSize = 12.sp,
                                    color = if (isSelected) TextPrimary else TextSecondary,
                                    maxLines = 3,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active Question Spotlight Card
        if (activeQuestion != null) {
            val q = activeQuestion!!
            val lobeColor = when (q.targetLobe) {
                "FRONTAL" -> CyanNeon
                "PARIETAL" -> VioletNeon
                "TEMPORAL" -> AmberNeon
                else -> EmeraldNeon
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SurfaceCard)
                        .border(1.dp, lobeColor.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "DOMANDA ATTIVA • ${q.theme}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = lobeColor,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = q.question,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                lineHeight = 21.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "🎯 ${q.philosophicalContext}",
                                fontSize = 11.sp,
                                color = TextMuted,
                                lineHeight = 15.sp
                            )
                        }

                        // TTS Voice Reader Button
                        IconButton(
                            onClick = {
                                if (isSpeaking) {
                                    ttsManager.stop()
                                } else {
                                    ttsManager.speak(q.question)
                                }
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SurfaceCardElevated)
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.GraphicEq else Icons.Default.VolumeUp,
                                contentDescription = "Ascolta Domanda",
                                tint = if (isSpeaking) AmberNeon else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Answer Input Field
                    OutlinedTextField(
                        value = answerText,
                        onValueChange = { viewModel.setSocraticAnswerText(it) },
                        placeholder = {
                            Text(
                                text = "Rispondi spontaneamente... parla delle tue ragioni intime, aneddoti, paure o decisioni...",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = lobeColor,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = BackgroundDark,
                            unfocusedContainerColor = BackgroundDark
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Audio Recording Bar & Voice Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Dictation Button
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (speechState == SpeechState.LISTENING) AmberNeon.copy(alpha = 0.2f) else SurfaceCardElevated)
                                .border(1.dp, if (speechState == SpeechState.LISTENING) AmberNeon else SurfaceCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    if (!hasAudioPermission) {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        if (speechState == SpeechState.LISTENING) {
                                            speechManager.stopListening()
                                        } else {
                                            speechManager.startListening("it-IT")
                                        }
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (speechState == SpeechState.LISTENING) Icons.Default.Mic else Icons.Default.MicOff,
                                contentDescription = null,
                                tint = if (speechState == SpeechState.LISTENING) AmberNeon else TextSecondary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .then(if (speechState == SpeechState.LISTENING) Modifier.scale(pulseScale) else Modifier)
                            )
                            Text(
                                text = if (speechState == SpeechState.LISTENING) "In ascolto..." else "Dettatura Vocale",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (speechState == SpeechState.LISTENING) AmberNeon else TextSecondary
                            )
                        }

                        if (answerText.isNotBlank()) {
                            Text(
                                text = "${answerText.split(" ").filter { it.isNotBlank() }.size} parole",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Extract Memory CTA Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (answerText.isNotBlank() && !isExtracting) {
                                    Brush.horizontalGradient(listOf(AmberNeon, VioletNeon))
                                } else {
                                    Brush.horizontalGradient(listOf(SurfaceCardElevated, SurfaceCardElevated))
                                }
                            )
                            .clickable(enabled = answerText.isNotBlank() && !isExtracting) {
                                speechManager.stopListening()
                                viewModel.extractAndSynthesizeMemory()
                            }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isExtracting) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.Black,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "Estrazione Neurale del Ricordo...",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = if (answerText.isNotBlank()) Color.Black else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Estrai & Sintetizza Ricordo con Gemini",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (answerText.isNotBlank()) Color.Black else TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Extracted Memory Result Card
        if (extractedResult != null) {
            val res = extractedResult!!
            val targetLobeEnum = try {
                BrainLobe.valueOf(res.targetLobe)
            } catch (e: Exception) {
                BrainLobe.TEMPORAL
            }
            val lobeColor = when (targetLobeEnum) {
                BrainLobe.FRONTAL -> CyanNeon
                BrainLobe.PARIETAL -> VioletNeon
                BrainLobe.TEMPORAL -> AmberNeon
                BrainLobe.OCCIPITAL -> EmeraldNeon
                BrainLobe.NEURAL_VAULT -> PinkVault
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SurfaceCard)
                        .border(1.5.dp, lobeColor, RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RICORDO ESTRATTO CON SUCCESSO",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = lobeColor,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = res.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        // Lobe Tag Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(lobeColor.copy(alpha = 0.2f))
                                .border(1.dp, lobeColor, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = targetLobeEnum.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = lobeColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Content Summary
                    Text(
                        text = res.content,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Key Insights Bullet List
                    if (res.keyInsights.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceCardElevated)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "✨ Principi & Consapevolezze Estratte:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberNeon
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            res.keyInsights.forEach { insight ->
                                Text(
                                    text = "• $insight",
                                    fontSize = 11.5.sp,
                                    color = TextPrimary,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(vertical = 1.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tags and Resonance
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(VioletNeon.copy(alpha = 0.15f))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "💫 ${res.emotionalResonance}",
                                fontSize = 10.sp,
                                color = VioletNeon
                            )
                        }

                        res.tags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SurfaceCardElevated)
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "#$tag",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Save to Brain Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.horizontalGradient(listOf(lobeColor, EmeraldNeon)))
                            .clickable {
                                viewModel.commitExtractedMemoryToBrain(res)
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BookmarkAdd,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Salva Ricordo nel ${targetLobeEnum.title}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
