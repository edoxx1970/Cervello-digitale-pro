package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.LobeFrontalColor
import com.example.ui.theme.LobeOccipitalColor
import com.example.ui.theme.LobeParietalColor
import com.example.ui.theme.LobeTemporalColor
import com.example.ui.theme.LobeVaultColor

enum class BrainLobe(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val iconName: String,
    val color: Color
) {
    FRONTAL(
        id = "FRONTAL",
        title = "Lobo Frontale",
        subtitle = "Decisioni, Obiettivi & Valori",
        description = "La corteccia esecutiva: gestisce il piano di vita, i principi morali, le strategie e le scelte decisive.",
        iconName = "Psychology",
        color = LobeFrontalColor
    ),
    TEMPORAL(
        id = "TEMPORAL",
        title = "Lobo Temporale",
        subtitle = "Memorie, Storie & Esperienze",
        description = "La memoria autobiografica: custodisce ricordi d'infanzia, viaggi, relazioni, momenti epici ed emozioni vissute.",
        iconName = "AutoAwesome",
        color = LobeTemporalColor
    ),
    PARIETAL(
        id = "PARIETAL",
        title = "Lobo Parietale",
        subtitle = "Conoscenze, Competenze & Dati",
        description = "Il database cognitivo: abilità tecniche, studi, nozioni scientifiche, appunti e abitudini quotidiane.",
        iconName = "Hub",
        color = LobeParietalColor
    ),
    OCCIPITAL(
        id = "OCCIPITAL",
        title = "Lobo Occipitale",
        subtitle = "Galleria Visiva, Foto & Schemi",
        description = "La percezione visiva: archivio di foto ricordi, mappe mentali, screenshot chiave e documenti visivi.",
        iconName = "PhotoLibrary",
        color = LobeOccipitalColor
    ),
    NEURAL_VAULT(
        id = "NEURAL_VAULT",
        title = "Caveau Neurale",
        subtitle = "Dati Riservati & E2EE Vault",
        description = "Area protetta da crittografia end-to-end AES-256: credenziali, codici di sicurezza, contratti e pensieri segreti.",
        iconName = "Lock",
        color = LobeVaultColor
    );

    companion object {
        fun fromId(id: String): BrainLobe {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: FRONTAL
        }
    }
}
