package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.EncryptedChatMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM encrypted_chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<EncryptedChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: EncryptedChatMessage): Long

    @Query("DELETE FROM encrypted_chat_messages")
    suspend fun deleteAllMessages()

    @Query("DELETE FROM encrypted_chat_messages WHERE id = :id")
    suspend fun deleteMessageById(id: Long)

    @Query("SELECT COUNT(*) FROM encrypted_chat_messages")
    fun getMessageCount(): Flow<Int>
}
