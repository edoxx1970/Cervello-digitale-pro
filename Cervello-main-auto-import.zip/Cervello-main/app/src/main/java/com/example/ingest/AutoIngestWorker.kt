package com.example.ingest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.ai.BrainCloneEngine
import com.example.crypto.CryptoPreferences
import com.example.crypto.VaultSession
import com.example.data.db.BrainDatabase
import com.example.data.model.BrainItem
import com.example.data.model.ScannedFileEntity
import com.example.data.repository.BrainRepository
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Esegue una singola passata di Auto-Import: cerca foto/documenti nuovi sul
 * dispositivo, li fa analizzare a Gemini (BrainCloneEngine) e salva il
 * risultato come nuova memoria non cifrata (fuori dal Caveau Neurale, che
 * resta riservato a ciò che l'utente marca esplicitamente come tale).
 *
 * Girare come CoroutineWorker (invece che dentro una Activity/ViewModel)
 * permette alla scansione di proseguire anche se l'utente chiude l'app,
 * rispettando comunque le finestre di esecuzione che il sistema concede al
 * WorkManager per il risparmio energetico.
 */
class AutoIngestWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        const val TAG = "AutoIngestWorker"
        const val UNIQUE_PERIODIC_NAME = "auto_ingest_periodic"
        const val UNIQUE_ONE_TIME_NAME = "auto_ingest_manual"

        private const val MAX_ITEMS_PER_RUN = 8
        private const val MAX_IMAGE_BYTES_RAW = 15L * 1024 * 1024 // oltre, ridimensioniamo prima di inviarla
        private const val MAX_DOCUMENT_BYTES = 15L * 1024 * 1024 // oltre, saltiamo (limite pratico upload Gemini)
        private const val TARGET_IMAGE_MAX_DIMENSION = 1280
    }

    override suspend fun doWork(): Result {
        val cryptoPrefs = CryptoPreferences(applicationContext)
        if (!cryptoPrefs.isAutoIngestEnabled) {
            return Result.success()
        }

        val database = BrainDatabase.getDatabase(applicationContext)
        val repository = BrainRepository(database.brainDao(), VaultSession())
        val scannedDao = database.scannedFileDao()
        val scanner = DeviceContentScanner(applicationContext)
        val cloneEngine = BrainCloneEngine()
        val cloneName = cryptoPrefs.cloneName

        try {
            val alreadyScanned = scannedDao.getAllScannedUris().toSet()
            var processedCount = 0

            if (cryptoPrefs.isAutoIngestImagesEnabled) {
                val newImages = scanner.findNewImages(alreadyScanned)
                for (candidate in newImages) {
                    if (processedCount >= MAX_ITEMS_PER_RUN) break
                    processImageCandidate(candidate, repository, scannedDao, cloneEngine, cloneName)
                    processedCount++
                }
            }

            if (cryptoPrefs.isAutoIngestDocsEnabled && processedCount < MAX_ITEMS_PER_RUN) {
                val newDocs = scanner.findNewDocuments(alreadyScanned)
                for (candidate in newDocs) {
                    if (processedCount >= MAX_ITEMS_PER_RUN) break
                    processDocumentCandidate(candidate, repository, scannedDao, cloneEngine, cloneName)
                    processedCount++
                }
            }

            cryptoPrefs.lastAutoIngestRunMillis = System.currentTimeMillis()
            Log.i(TAG, "Auto-Import completato: $processedCount elementi processati")
            return Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Auto-Import fallito", e)
            return Result.retry()
        }
    }

    private suspend fun processImageCandidate(
        candidate: DeviceFileCandidate,
        repository: BrainRepository,
        scannedDao: com.example.data.db.ScannedFileDao,
        cloneEngine: BrainCloneEngine,
        cloneName: String
    ) {
        try {
            val bytes = loadAndDownscaleImage(candidate.uriString)
            if (bytes == null) {
                markScanned(scannedDao, candidate, "ERROR", null)
                return
            }

            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val result = cloneEngine.analyzeDeviceFileForMemory(
                fileName = candidate.fileName,
                mimeType = "image/jpeg",
                base64Data = base64,
                sourceHint = "Galleria",
                cloneName = cloneName
            )

            val item = BrainItem(
                title = result.title,
                content = result.content,
                lobeType = result.targetLobe,
                category = result.category,
                tags = (result.tags + listOf("auto-import", "galleria")).distinct().joinToString(","),
                photoUri = candidate.uriString,
                importance = 3,
                emotionLevel = 50,
                synapticLinks = result.keyInsights.joinToString(","),
                createdAt = candidate.lastModified,
                isEncrypted = false
            )
            val newId = repository.insert(item)
            markScanned(scannedDao, candidate, "IMPORTED", newId)
        } catch (e: Exception) {
            Log.e(TAG, "Errore analisi immagine ${candidate.fileName}", e)
            markScanned(scannedDao, candidate, "ERROR", null)
        }
    }

    private suspend fun processDocumentCandidate(
        candidate: DeviceFileCandidate,
        repository: BrainRepository,
        scannedDao: com.example.data.db.ScannedFileDao,
        cloneEngine: BrainCloneEngine,
        cloneName: String
    ) {
        if (candidate.sizeBytes > MAX_DOCUMENT_BYTES) {
            markScanned(scannedDao, candidate, "SKIPPED_TOO_LARGE", null)
            return
        }

        try {
            val file = File(candidate.uriString)
            if (!file.exists() || !file.canRead()) {
                markScanned(scannedDao, candidate, "ERROR", null)
                return
            }

            val isPlainText = candidate.mimeType in setOf(
                "text/plain", "text/markdown", "text/csv", "application/json"
            )

            val result = if (isPlainText) {
                val textContent = file.readText().take(20_000)
                cloneEngine.analyzeAndCategorizeDocument(candidate.fileName, textContent, cloneName)
            } else if (candidate.mimeType == "application/pdf") {
                val base64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
                cloneEngine.analyzeDeviceFileForMemory(
                    fileName = candidate.fileName,
                    mimeType = candidate.mimeType,
                    base64Data = base64,
                    sourceHint = "Documenti",
                    cloneName = cloneName
                )
            } else {
                // .doc/.docx: nessun estrattore di testo disponibile in app e
                // Gemini non accetta questo mimeType come allegato diretto.
                markScanned(scannedDao, candidate, "SKIPPED_UNSUPPORTED", null)
                return
            }

            val item = BrainItem(
                title = result.title,
                content = result.content,
                lobeType = result.targetLobe,
                category = result.category,
                tags = (result.tags + listOf("auto-import", "documenti")).distinct().joinToString(","),
                importance = 3,
                emotionLevel = 50,
                synapticLinks = result.keyInsights.joinToString(","),
                createdAt = candidate.lastModified,
                isEncrypted = false
            )
            val newId = repository.insert(item)
            markScanned(scannedDao, candidate, "IMPORTED", newId)
        } catch (e: Exception) {
            Log.e(TAG, "Errore analisi documento ${candidate.fileName}", e)
            markScanned(scannedDao, candidate, "ERROR", null)
        }
    }

    /**
     * Legge la foto dal MediaStore e la ridimensiona/ricomprime se necessario,
     * per tenere il payload base64 verso Gemini entro dimensioni ragionevoli
     * (le foto moderne da 12-48MP sarebbero altrimenti enormi da inviare).
     */
    private fun loadAndDownscaleImage(uriString: String): ByteArray? {
        return try {
            val uri = android.net.Uri.parse(uriString)
            val resolver = applicationContext.contentResolver

            val originalBitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: return null

            val scale = TARGET_IMAGE_MAX_DIMENSION.toFloat() / maxOf(originalBitmap.width, originalBitmap.height)
            val finalBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    originalBitmap,
                    (originalBitmap.width * scale).toInt().coerceAtLeast(1),
                    (originalBitmap.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                originalBitmap
            }

            val stream = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 82, stream)
            stream.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Impossibile leggere/ridimensionare $uriString", e)
            null
        }
    }

    private suspend fun markScanned(
        dao: com.example.data.db.ScannedFileDao,
        candidate: DeviceFileCandidate,
        status: String,
        brainItemId: Long?
    ) {
        dao.insert(
            ScannedFileEntity(
                uriString = candidate.uriString,
                source = candidate.source,
                fileName = candidate.fileName,
                sizeBytes = candidate.sizeBytes,
                lastModified = candidate.lastModified,
                status = status,
                brainItemId = brainItemId
            )
        )
    }
}
