package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Abyss Backgrounds & Surfaces
val BackgroundDark = Color(0xFF080B11)
val SurfaceDark = Color(0xFF101622)
val SurfaceCard = Color(0xFF161E30)
val SurfaceCardElevated = Color(0xFF1E2942)
val SurfaceCardBorder = Color(0xFF263553)

// Vibrant Neural Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanGlow = Color(0x3300E5FF)
val VioletNeon = Color(0xFFA855F7)
val VioletGlow = Color(0x33A855F7)
val EmeraldNeon = Color(0xFF10B981)
val AmberNeon = Color(0xFFF59E0B)
val PinkVault = Color(0xFFF43F5E)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Lobe Dedicated Colors
val LobeFrontalColor = Color(0xFF00E5FF)   // Decisions & Goals
val LobeTemporalColor = Color(0xFFA855F7)  // Memories & Stories
val LobeParietalColor = Color(0xFF10B981)  // Knowledge & Data
val LobeOccipitalColor = Color(0xFFF59E0B) // Visual & Photos
val LobeVaultColor = Color(0xFFF43F5E)     // E2EE Cryptographic Vault
