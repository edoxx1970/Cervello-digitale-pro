package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    var speechRate: Float = 1.0f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var speechPitch: Float = 1.0f
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            _isReady.value = false
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            _isReady.value = true

            // Prefer Italian, fallback to Default
            val italianResult = tts?.setLanguage(Locale.ITALIAN)
            if (italianResult == TextToSpeech.LANG_MISSING_DATA || italianResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
        } else {
            isInitialized = false
            _isReady.value = false
        }
    }

    fun speak(text: String, languageCode: String = "it-IT") {
        if (!isInitialized || tts == null) {
            return
        }

        stop()

        val locale = when (languageCode) {
            "en-US" -> Locale.US
            "es-ES" -> Locale("es", "ES")
            else -> Locale.ITALIAN
        }

        tts?.setLanguage(locale)
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)

        // Clean markdown characters for cleaner audio readout
        val cleanText = text
            .replace(Regex("[*#_`~>]"), "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            .trim()

        val utteranceId = "voice_query_${System.currentTimeMillis()}"
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        _isSpeaking.value = true
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (ignored: Exception) {
        } finally {
            _isSpeaking.value = false
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (ignored: Exception) {
        } finally {
            tts = null
            isInitialized = false
            _isSpeaking.value = false
            _isReady.value = false
        }
    }
}
