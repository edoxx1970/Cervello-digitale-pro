package com.example.server

object BrainWebPortalHtml {

    fun generatePortalHtml(cloneName: String, ipAddress: String, port: Int): String {
        return """
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cervello Digitale - E2EE Remote Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-base: #070a0f;
            --bg-card: #101622;
            --bg-card-hover: #182236;
            --border-glow: #1e2d4a;
            --cyan: #00e5ff;
            --cyan-glow: rgba(0, 229, 255, 0.25);
            --violet: #a855f7;
            --violet-glow: rgba(168, 85, 247, 0.25);
            --emerald: #10b981;
            --amber: #f59e0b;
            --rose: #f43f5e;
            --text: #f8fafc;
            --text-muted: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-base);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(0, 229, 255, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(168, 85, 247, 0.05) 0%, transparent 40%);
        }

        header {
            border-bottom: 1px solid var(--border-glow);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(16, 22, 34, 0.85);
            backdrop-filter: blur(12px);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-badge {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: linear-gradient(135deg, #00e5ff 0%, #a855f7 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 20px var(--cyan-glow);
            font-size: 22px;
        }

        .brand-text h1 {
            font-size: 1.25rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            background: linear-gradient(90deg, #00e5ff, #c084fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-text p {
            font-size: 0.75rem;
            color: var(--text-muted);
            font-family: 'JetBrains Mono', monospace;
        }

        .badge-e2ee {
            background: rgba(16, 185, 129, 0.15);
            color: var(--emerald);
            border: 1px solid rgba(16, 185, 129, 0.3);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .badge-dot {
            width: 8px;
            height: 8px;
            background-color: var(--emerald);
            border-radius: 50%;
            box-shadow: 0 0 8px var(--emerald);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.7; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.7; }
        }

        .main-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            width: 100%;
            flex: 1;
        }

        /* Lock Screen Modal */
        #lock-screen {
            position: fixed;
            inset: 0;
            background: rgba(7, 10, 15, 0.96);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            padding: 1.5rem;
        }

        .lock-box {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 24px;
            padding: 2.5rem;
            max-width: 440px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6), 0 0 30px var(--cyan-glow);
        }

        .lock-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .lock-box h2 {
            font-size: 1.6rem;
            margin-bottom: 0.5rem;
        }

        .lock-box p {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-bottom: 1.8rem;
            line-height: 1.4;
        }

        .pin-input {
            width: 100%;
            background: #090e17;
            border: 2px solid var(--border-glow);
            border-radius: 14px;
            padding: 14px;
            font-size: 1.3rem;
            color: var(--cyan);
            text-align: center;
            letter-spacing: 0.3em;
            font-family: 'JetBrains Mono', monospace;
            margin-bottom: 1.2rem;
            outline: none;
            transition: all 0.2s ease;
        }

        .pin-input:focus {
            border-color: var(--cyan);
            box-shadow: 0 0 15px var(--cyan-glow);
        }

        .btn-unlock {
            width: 100%;
            background: linear-gradient(135deg, var(--cyan) 0%, var(--violet) 100%);
            border: none;
            color: #000;
            font-weight: 700;
            font-size: 1rem;
            padding: 14px;
            border-radius: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-unlock:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 229, 255, 0.4);
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 340px;
            gap: 2rem;
        }

        @media (max-width: 900px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        .hero-banner {
            background: linear-gradient(135deg, rgba(0, 229, 255, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
            border: 1px solid var(--border-glow);
            border-radius: 20px;
            padding: 1.8rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .hero-title {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 0.4rem;
        }

        .hero-desc {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .lobe-pills {
            display: flex;
            gap: 8px;
            overflow-x: auto;
            padding-bottom: 12px;
            margin-bottom: 1.5rem;
        }

        .lobe-pill {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            color: var(--text-muted);
            padding: 8px 16px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
            transition: all 0.2s ease;
        }

        .lobe-pill.active, .lobe-pill:hover {
            background: rgba(0, 229, 255, 0.15);
            color: var(--cyan);
            border-color: var(--cyan);
        }

        .memories-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.2rem;
        }

        .memory-card {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 16px;
            padding: 1.4rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: all 0.2s ease;
        }

        .memory-card:hover {
            border-color: rgba(0, 229, 255, 0.4);
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.8rem;
        }

        .card-category {
            font-size: 0.75rem;
            text-transform: uppercase;
            font-weight: 700;
            color: var(--cyan);
            letter-spacing: 0.05em;
        }

        .card-lobe {
            font-size: 0.7rem;
            background: rgba(255,255,255,0.06);
            padding: 3px 8px;
            border-radius: 6px;
            color: var(--text-muted);
        }

        .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 0.6rem;
            line-height: 1.3;
        }

        .card-content {
            color: var(--text-muted);
            font-size: 0.88rem;
            line-height: 1.5;
            margin-bottom: 1rem;
            display: -webkit-box;
            -webkit-line-clamp: 4;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255,255,255,0.05);
            padding-top: 0.8rem;
            font-size: 0.75rem;
            color: var(--text-muted);
        }

        /* Sidebar AI Chat */
        .sidebar {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 20px;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            height: fit-content;
        }

        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .chat-box {
            background: #090e17;
            border: 1px solid var(--border-glow);
            border-radius: 14px;
            height: 300px;
            overflow-y: auto;
            padding: 1rem;
            margin: 1rem 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
            font-size: 0.88rem;
        }

        .chat-msg {
            padding: 10px 14px;
            border-radius: 12px;
            max-width: 85%;
            line-height: 1.4;
        }

        .msg-user {
            background: rgba(0, 229, 255, 0.2);
            color: var(--text);
            align-self: flex-end;
            border-bottom-right-radius: 2px;
        }

        .msg-clone {
            background: rgba(168, 85, 247, 0.2);
            color: var(--text);
            align-self: flex-start;
            border-bottom-left-radius: 2px;
        }

        .chat-input-row {
            display: flex;
            gap: 8px;
        }

        .chat-input {
            flex: 1;
            background: #090e17;
            border: 1px solid var(--border-glow);
            border-radius: 10px;
            padding: 10px 12px;
            color: #fff;
            outline: none;
        }

        .chat-btn {
            background: var(--cyan);
            border: none;
            color: #000;
            font-weight: 700;
            padding: 0 16px;
            border-radius: 10px;
            cursor: pointer;
        }

        /* Modal Add */
        #add-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(10px);
            z-index: 200;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }

        .modal-content {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 20px;
            padding: 2rem;
            max-width: 500px;
            width: 100%;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-label {
            display: block;
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 0.4rem;
        }

        .form-control {
            width: 100%;
            background: #090e17;
            border: 1px solid var(--border-glow);
            border-radius: 10px;
            padding: 10px 14px;
            color: #fff;
            font-family: inherit;
            outline: none;
        }

        textarea.form-control {
            height: 100px;
            resize: vertical;
        }
    </style>
</head>
<body>

    <!-- LOCK SCREEN OVERLAY -->
    <div id="lock-screen">
        <div class="lock-box">
            <div class="lock-icon">🧠 🔒</div>
            <h2>Cervello Digitale E2EE</h2>
            <p>Accesso protetto da crittografia end-to-end AES-256. Inserisci il PIN o la Passphrase di accoppiamento mostrata sullo smartphone.</p>
            <input type="password" id="pin-input" class="pin-input" placeholder="••••" maxlength="12" autofocus>
            <button class="btn-unlock" onclick="unlockVault()">Sblocca Clone Cerebrale</button>
            <div id="lock-err" style="color:var(--rose); font-size:0.8rem; margin-top:10px;"></div>
        </div>
    </div>

    <!-- MAIN HEADER -->
    <header>
        <div class="brand">
            <div class="logo-badge">🧠</div>
            <div class="brand-text">
                <h1>$cloneName</h1>
                <p>E2EE Synchronized Node • $ipAddress:$port</p>
            </div>
        </div>
        <div style="display: flex; gap: 12px; align-items: center;">
            <button class="lobe-pill" onclick="openAddModal()">➕ Aggiungi al Cervello</button>
            <div class="badge-e2ee">
                <div class="badge-dot"></div>
                Crittografato E2EE
            </div>
        </div>
    </header>

    <main class="main-container">
        <div class="hero-banner">
            <div>
                <div class="hero-title">Clone Neurale Connesso</div>
                <div class="hero-desc">Memorie, dati personali e foto risiedono fisicamente sul tuo smartphone Android e sono accessibili tramite questo ponte cifrato.</div>
            </div>
            <div>
                <button class="lobe-pill" onclick="exportEncrypted()">💾 Esporta Backup E2EE</button>
            </div>
        </div>

        <div class="dashboard-grid">
            <div>
                <div class="lobe-pills">
                    <button class="lobe-pill active" onclick="filterLobe('ALL', this)">Tutte le Sinapsi</button>
                    <button class="lobe-pill" onclick="filterLobe('FRONTAL', this)">Lobo Frontale</button>
                    <button class="lobe-pill" onclick="filterLobe('TEMPORAL', this)">Lobo Temporale</button>
                    <button class="lobe-pill" onclick="filterLobe('PARIETAL', this)">Lobo Parietale</button>
                    <button class="lobe-pill" onclick="filterLobe('OCCIPITAL', this)">Lobo Occipitale (Foto)</button>
                    <button class="lobe-pill" onclick="filterLobe('NEURAL_VAULT', this)">Caveau Neurale</button>
                </div>

                <div class="memories-grid" id="memories-container">
                    <!-- Loaded dynamically -->
                </div>
            </div>

            <!-- SIDEBAR AI CLONE CHAT -->
            <div class="sidebar">
                <div class="sidebar-title">🤖 Parla con il Clone</div>
                <p style="font-size:0.8rem; color:var(--text-muted);">Interroga il clone del tuo cervello in base alle memorie registrate sul dispositivo.</p>
                <div class="chat-box" id="chat-box">
                    <div class="chat-msg msg-clone">Ciao! Sono il tuo Clone Cerebrale. Chiedimi qualunque cosa su principi, ricordi, decisioni o dati salvati!</div>
                </div>
                <div class="chat-input-row">
                    <input type="text" id="chat-input" class="chat-input" placeholder="Es. Qual è il mio obiettivo 2026?..." onkeypress="handleChatKey(event)">
                    <button class="chat-btn" onclick="sendChat()">Invia</button>
                </div>
            </div>
        </div>
    </main>

    <!-- MODAL ADD MEMORY -->
    <div id="add-modal">
        <div class="modal-content">
            <h3 style="margin-bottom:1rem; font-size:1.3rem;">➕ Aggiungi Sinapsi al Cervello</h3>
            <div class="form-group">
                <label class="form-label">Titolo Pensiero o Dato</label>
                <input type="text" id="add-title" class="form-control" placeholder="Es. Nuova idea di progetto...">
            </div>
            <div class="form-group">
                <label class="form-label">Lobo Cerebrale di Destinazione</label>
                <select id="add-lobe" class="form-control">
                    <option value="FRONTAL">Lobo Frontale (Decisioni & Obiettivi)</option>
                    <option value="TEMPORAL">Lobo Temporale (Ricordi & Storie)</option>
                    <option value="PARIETAL" selected>Lobo Parietale (Conoscenza & Dati)</option>
                    <option value="OCCIPITAL">Lobo Occipitale (Foto & Schemi)</option>
                    <option value="NEURAL_VAULT">Caveau Neurale (Cifrato E2EE)</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Categoria</label>
                <input type="text" id="add-category" class="form-control" placeholder="Es. Progetti, Salute, Tech...">
            </div>
            <div class="form-group">
                <label class="form-label">Contenuto & Note Dettagliate</label>
                <textarea id="add-content" class="form-control" placeholder="Scrivi qui tutte le informazioni..."></textarea>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:1.5rem;">
                <button class="lobe-pill" onclick="closeAddModal()">Annulla</button>
                <button class="btn-unlock" style="width:auto; padding:10px 20px;" onclick="submitNewMemory()">Salva nel Cervello</button>
            </div>
        </div>
    </div>

    <script>
        let allMemories = [];
        let currentFilter = 'ALL';
        // Token di sessione ottenuto da /api/unlock: senza autenticazione valida
        // il dispositivo ora rifiuta con 401 tutte le chiamate ai dati (vedi
        // BrainRemoteServer.kt). Il PIN non viene più tenuto in memoria dopo
        // l'unlock, tranne per il tempo necessario a un export esplicito.
        let sessionToken = '';

        function authHeaders() {
            return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sessionToken };
        }

        async function unlockVault() {
            const pin = document.getElementById('pin-input').value;
            const errDiv = document.getElementById('lock-err');
            errDiv.innerText = '';

            try {
                const res = await fetch('/api/unlock', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ pin: pin })
                });
                const data = await res.json();
                if (res.ok && data.success) {
                    sessionToken = data.token || '';
                    document.getElementById('lock-screen').style.display = 'none';
                    loadMemories();
                } else {
                    errDiv.innerText = data.message || 'PIN o Passphrase errata';
                }
            } catch (e) {
                errDiv.innerText = 'Errore di connessione con il dispositivo Android';
            }
        }

        async function loadMemories() {
            try {
                const res = await fetch('/api/memories', { headers: authHeaders() });
                if (res.status === 401) { location.reload(); return; }
                allMemories = await res.json();
                renderMemories();
            } catch (e) {
                console.error(e);
            }
        }

        function renderMemories() {
            const container = document.getElementById('memories-container');
            container.innerHTML = '';

            const filtered = currentFilter === 'ALL' 
                ? allMemories 
                : allMemories.filter(m => m.lobeType === currentFilter);

            if (filtered.length === 0) {
                container.innerHTML = '<div style="color:var(--text-muted); padding:2rem; grid-column:1/-1; text-align:center;">Nessuna sinapsi trovata in questo lobo cerebrale.</div>';
                return;
            }

            filtered.forEach(m => {
                const card = document.createElement('div');
                card.className = 'memory-card';
                card.innerHTML = `
                    <div>
                        <div class="card-header">
                            <span class="card-category">${'$'}{m.category || 'Generale'}</span>
                            <span class="card-lobe">${'$'}{m.lobeType}</span>
                        </div>
                        <div class="card-title">${'$'}{m.title}</div>
                        <div class="card-content">${'$'}{m.content}</div>
                    </div>
                    <div class="card-footer">
                        <span>⭐ Importanza: ${'$'}{m.importance}/5</span>
                        <span>⚡ Emozione: ${'$'}{m.emotionLevel}%</span>
                    </div>
                `;
                container.appendChild(card);
            });
        }

        function filterLobe(lobe, btn) {
            currentFilter = lobe;
            document.querySelectorAll('.lobe-pills .lobe-pill').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderMemories();
        }

        function handleChatKey(e) {
            if (e.key === 'Enter') sendChat();
        }

        async function sendChat() {
            const input = document.getElementById('chat-input');
            const txt = input.value.trim();
            if (!txt) return;

            const chatBox = document.getElementById('chat-box');
            chatBox.innerHTML += `<div class="chat-msg msg-user">${'$'}{txt}</div>`;
            input.value = '';
            chatBox.scrollTop = chatBox.scrollHeight;

            try {
                const res = await fetch('/api/clone-chat', {
                    method: 'POST',
                    headers: authHeaders(),
                    body: JSON.stringify({ prompt: txt })
                });
                const data = await res.json();
                chatBox.innerHTML += `<div class="chat-msg msg-clone">${'$'}{data.reply.replace(/\\n/g, '<br>')}</div>`;
                chatBox.scrollTop = chatBox.scrollHeight;
            } catch (e) {
                chatBox.innerHTML += `<div class="chat-msg msg-clone" style="color:var(--rose)">Errore nella comunicazione neurale con il dispositivo.</div>`;
            }
        }

        function openAddModal() {
            document.getElementById('add-modal').style.display = 'flex';
        }

        function closeAddModal() {
            document.getElementById('add-modal').style.display = 'none';
        }

        async function submitNewMemory() {
            const title = document.getElementById('add-title').value.trim();
            const content = document.getElementById('add-content').value.trim();
            const lobeType = document.getElementById('add-lobe').value;
            const category = document.getElementById('add-category').value.trim();

            if (!title || !content) {
                alert('Inserisci almeno titolo e contenuto');
                return;
            }

            try {
                const res = await fetch('/api/add-memory', {
                    method: 'POST',
                    headers: authHeaders(),
                    body: JSON.stringify({ title, content, lobeType, category })
                });
                if (res.ok) {
                    closeAddModal();
                    loadMemories();
                }
            } catch (e) {
                alert('Errore durante il salvataggio');
            }
        }

        async function exportEncrypted() {
            const pin = prompt('Inserisci di nuovo il PIN master per firmare il backup cifrato:');
            if (!pin) return;
            try {
                const res = await fetch('/api/export', {
                    method: 'POST',
                    headers: authHeaders(),
                    body: JSON.stringify({ pin: pin })
                });
                if (!res.ok) {
                    const errData = await res.json().catch(() => ({}));
                    alert(errData.error || 'PIN non valido per l\'export');
                    return;
                }
                const data = await res.json();
                const blob = new Blob([data.encryptedBackup], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'cervello-digitale-e2ee-backup.brain';
                a.click();
            } catch (e) {
                alert('Errore esportazione backup');
            }
        }
    </script>
</body>
</html>
        """.trimIndent()
    }
}
