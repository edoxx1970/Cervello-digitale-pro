package com.example.crypto

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CryptoEngine {
    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    private const val IV_LENGTH_BYTE = 12
    private const val SALT_LENGTH_BYTE = 16
    // OWASP (2023+) raccomanda >= 600.000 iterazioni per PBKDF2-HMAC-SHA256.
    // Il valore precedente (10.000) risale a linee guida ormai datate e rende
    // un attacco a forza bruta offline sul PIN/passphrase molto più economico.
    // NB: alzare questo valore rende illeggibili i backup/dati cifrati con la
    // versione precedente: è una scelta consapevole, da comunicare come "breaking
    // change" se esistono già export in produzione.
    private const val ITERATION_COUNT = 600000
    private const val KEY_LENGTH_BIT = 256

    private val secureRandom = SecureRandom()

    /**
     * Derives a 256-bit AES SecretKey from a user passphrase and salt using PBKDF2.
     */
    fun deriveKey(passphrase: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH_BIT)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * Generates a random cryptographic salt.
     */
    fun generateSalt(): ByteArray {
        val salt = ByteArray(SALT_LENGTH_BYTE)
        secureRandom.nextBytes(salt)
        return salt
    }

    /**
     * Encrypts plaintext string using AES-256-GCM.
     * Output format: Base64(salt[16] + iv[12] + ciphertext)
     */
    fun encrypt(plainText: String, passphrase: String): String {
        val salt = generateSalt()
        val key = deriveKey(passphrase, salt)
        val iv = ByteArray(IV_LENGTH_BYTE)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance(ALGORITHM)
        val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)

        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        // Combine salt + iv + cipherText
        val combined = ByteArray(salt.size + iv.size + cipherText.size)
        System.arraycopy(salt, 0, combined, 0, salt.size)
        System.arraycopy(iv, 0, combined, salt.size, iv.size)
        System.arraycopy(cipherText, 0, combined, salt.size + iv.size, cipherText.size)

        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Encrypts raw byte arrays (e.g. JPEG camera photos) using AES-256-GCM.
     * Output: salt[16] + iv[12] + ciphertext
     */
    fun encryptBytes(plainBytes: ByteArray, passphrase: String): ByteArray {
        val salt = generateSalt()
        val key = deriveKey(passphrase, salt)
        val iv = ByteArray(IV_LENGTH_BYTE)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance(ALGORITHM)
        val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)

        val cipherBytes = cipher.doFinal(plainBytes)

        val combined = ByteArray(salt.size + iv.size + cipherBytes.size)
        System.arraycopy(salt, 0, combined, 0, salt.size)
        System.arraycopy(iv, 0, combined, salt.size, iv.size)
        System.arraycopy(cipherBytes, 0, combined, salt.size + iv.size, cipherBytes.size)

        return combined
    }

    /**
     * Decrypts raw encrypted byte array into original photo bytes (e.g. Bitmap bytes).
     */
    fun decryptBytes(encryptedBytes: ByteArray, passphrase: String): Result<ByteArray> {
        return try {
            if (encryptedBytes.size < SALT_LENGTH_BYTE + IV_LENGTH_BYTE) {
                return Result.failure(IllegalArgumentException("Payload foto corrotto o troppo corto"))
            }

            val salt = ByteArray(SALT_LENGTH_BYTE)
            val iv = ByteArray(IV_LENGTH_BYTE)
            val cipherTextSize = encryptedBytes.size - SALT_LENGTH_BYTE - IV_LENGTH_BYTE
            val cipherText = ByteArray(cipherTextSize)

            System.arraycopy(encryptedBytes, 0, salt, 0, SALT_LENGTH_BYTE)
            System.arraycopy(encryptedBytes, SALT_LENGTH_BYTE, iv, 0, IV_LENGTH_BYTE)
            System.arraycopy(encryptedBytes, SALT_LENGTH_BYTE + IV_LENGTH_BYTE, cipherText, 0, cipherTextSize)

            val key = deriveKey(passphrase, salt)
            val cipher = Cipher.getInstance(ALGORITHM)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            val decryptedBytes = cipher.doFinal(cipherText)
            Result.success(decryptedBytes)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Decrypts AES-256-GCM payload encrypted with encrypt().
     */
    fun decrypt(encryptedBase64: String, passphrase: String): Result<String> {
        return try {
            val combined = Base64.decode(encryptedBase64, Base64.NO_WRAP)
            if (combined.size < SALT_LENGTH_BYTE + IV_LENGTH_BYTE) {
                return Result.failure(IllegalArgumentException("Payload troppo corto o corrotto"))
            }

            val salt = ByteArray(SALT_LENGTH_BYTE)
            val iv = ByteArray(IV_LENGTH_BYTE)
            val cipherTextSize = combined.size - SALT_LENGTH_BYTE - IV_LENGTH_BYTE
            val cipherText = ByteArray(cipherTextSize)

            System.arraycopy(combined, 0, salt, 0, SALT_LENGTH_BYTE)
            System.arraycopy(combined, SALT_LENGTH_BYTE, iv, 0, IV_LENGTH_BYTE)
            System.arraycopy(combined, SALT_LENGTH_BYTE + IV_LENGTH_BYTE, cipherText, 0, cipherTextSize)

            val key = deriveKey(passphrase, salt)
            val cipher = Cipher.getInstance(ALGORITHM)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            val decryptedBytes = cipher.doFinal(cipherText)
            Result.success(String(decryptedBytes, Charsets.UTF_8))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Cifra un testo usando una SecretKey già derivata (niente PBKDF2 qui: quello
     * va fatto UNA SOLA VOLTA allo sblocco del caveau, non ad ogni riga letta o
     * scritta, altrimenti ogni operazione costerebbe centinaia di migliaia di
     * iterazioni). Output: Base64(iv[12] + ciphertext).
     */
    fun encryptWithKey(plainText: String, key: SecretKey): String {
        val iv = ByteArray(IV_LENGTH_BYTE)
        secureRandom.nextBytes(iv)
        val cipher = Cipher.getInstance(ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BIT, iv))
        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        val combined = ByteArray(iv.size + cipherText.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(cipherText, 0, combined, iv.size, cipherText.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Decifra un payload prodotto da encryptWithKey(), con la stessa SecretKey.
     */
    fun decryptWithKey(encryptedBase64: String, key: SecretKey): Result<String> {
        return try {
            val combined = Base64.decode(encryptedBase64, Base64.NO_WRAP)
            if (combined.size < IV_LENGTH_BYTE) {
                return Result.failure(IllegalArgumentException("Payload troppo corto o corrotto"))
            }
            val iv = combined.copyOfRange(0, IV_LENGTH_BYTE)
            val cipherText = combined.copyOfRange(IV_LENGTH_BYTE, combined.size)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BIT, iv))
            Result.success(String(cipher.doFinal(cipherText), Charsets.UTF_8))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Varianti per byte[] di encryptWithKey/decryptWithKey (foto, allegati binari):
     * stessa idea, nessuna nuova derivazione PBKDF2 ad ogni chiamata.
     */
    fun encryptBytesWithKey(plainBytes: ByteArray, key: SecretKey): ByteArray {
        val iv = ByteArray(IV_LENGTH_BYTE)
        secureRandom.nextBytes(iv)
        val cipher = Cipher.getInstance(ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BIT, iv))
        val cipherBytes = cipher.doFinal(plainBytes)
        val combined = ByteArray(iv.size + cipherBytes.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
        return combined
    }

    fun decryptBytesWithKey(encryptedBytes: ByteArray, key: SecretKey): Result<ByteArray> {
        return try {
            if (encryptedBytes.size < IV_LENGTH_BYTE) {
                return Result.failure(IllegalArgumentException("Payload troppo corto o corrotto"))
            }
            val iv = encryptedBytes.copyOfRange(0, IV_LENGTH_BYTE)
            val cipherText = encryptedBytes.copyOfRange(IV_LENGTH_BYTE, encryptedBytes.size)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_LENGTH_BIT, iv))
            Result.success(cipher.doFinal(cipherText))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Computes SHA-256 hash for fast zero-knowledge password matching.
     */
    fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    /**
     * Generates a 6-digit cryptographic pairing code for remote device sync.
     */
    fun generatePairingPin(): String {
        val pin = secureRandom.nextInt(900000) + 100000
        return pin.toString()
    }
}
