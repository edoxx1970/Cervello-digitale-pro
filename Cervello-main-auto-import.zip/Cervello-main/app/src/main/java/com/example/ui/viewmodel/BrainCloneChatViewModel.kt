package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.BrainCloneEngine
import com.example.crypto.CryptoPreferences
import com.example.data.db.BrainDatabase
import com.example.data.model.BrainItem
import com.example.data.repository.BrainRepository
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val isPrivacyShieldActive: Boolean = true,
    val allowVaultGrounding: Boolean = false,
    val activeModel: String = "gemini-3.5-flash",
    val errorNotice: String? = null,
    val lastPrompt: String? = null,
    val totalProtectedMessages: Int = 0
)

class BrainCloneChatViewModel(application: Application) : AndroidViewModel(application) {

    private val database = BrainDatabase.getDatabase(application)
    // NB: questo ViewModel non risulta usato da nessuna schermata (l'app passa
    // sempre BrainViewModel a BrainCloneChatScreen) — codice orfano, probabile
    // residuo di un refactor. Lo lascio compilabile ma vale la pena valutare se
    // rimuoverlo per evitare che diverga in futuro dalla logica "vera".
    private val brainRepo = BrainRepository(database.brainDao(), com.example.crypto.VaultSession())
    val cryptoPrefs = CryptoPreferences(application)
    val chatRepo = ChatRepository(database.chatDao(), cryptoPrefs)
    val cloneEngine = BrainCloneEngine()

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    // Persistent Decrypted Chat History stream
    val decryptedHistory: StateFlow<List<ChatMessage>> = chatRepo.getDecryptedChatHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All synaptic memories for grounding
    val allBrainItems: StateFlow<List<BrainItem>> = brainRepo.allItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            // Seed welcome message if chat is completely empty
            chatRepo.getDecryptedChatHistory().collect { history ->
                if (history.isEmpty()) {
                    chatRepo.saveEncryptedMessage(
                        sender = MessageSender.CLONE,
                        plainText = "Ciao! Sono il tuo Clone Cerebrale Digitale alimentato da Gemini 3.5 Flash. Tutte le nostre conversazioni sono protette con crittografia end-to-end (AES-256-GCM) sul tuo dispositivo. Cosa vorresti chiedermi o analizzare oggi?",
                        modelName = cloneEngine.currentModel
                    )
                }
            }
        }
    }

    fun sendMessage(prompt: String) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank() || _uiState.value.isLoading) return

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            errorNotice = null,
            lastPrompt = cleanPrompt
        )

        viewModelScope.launch {
            try {
                // 1. Save and encrypt User message to local protected Room store
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.USER,
                    plainText = cleanPrompt,
                    modelName = cloneEngine.currentModel
                )

                // 2. Fetch latest memory nodes
                val memories = allBrainItems.value
                val history = decryptedHistory.value

                // 3. Connect to AI Clone via Gemini / Firebase AI Engine with privacy protections
                val reply = cloneEngine.queryBrainClone(
                    userPrompt = cleanPrompt,
                    cloneName = cryptoPrefs.cloneName,
                    allMemories = memories,
                    recentHistory = history,
                    isPrivacyShieldActive = _uiState.value.isPrivacyShieldActive,
                    allowVaultGrounding = _uiState.value.allowVaultGrounding
                )

                // 4. Save and encrypt AI Assistant Response to local protected Room store
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.CLONE,
                    plainText = reply,
                    modelName = cloneEngine.currentModel
                )

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorNotice = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorNotice = "Errore connessione Clone AI: ${e.localizedMessage ?: e.message}"
                )
                // Save fallback notification as clone response
                chatRepo.saveEncryptedMessage(
                    sender = MessageSender.CLONE,
                    plainText = "⚠️ [Protezione Attiva]: Impossibile completare la sintesi neurale remota (${e.message}). Verifica la connessione o l'API key.",
                    modelName = cloneEngine.currentModel
                )
            }
        }
    }

    fun retryLastMessage() {
        val last = _uiState.value.lastPrompt
        if (!last.isNullOrBlank()) {
            sendMessage(last)
        }
    }

    fun togglePrivacyShield() {
        _uiState.value = _uiState.value.copy(
            isPrivacyShieldActive = !_uiState.value.isPrivacyShieldActive
        )
    }

    fun setAllowVaultGrounding(allow: Boolean) {
        _uiState.value = _uiState.value.copy(
            allowVaultGrounding = allow
        )
    }

    fun clearChat() {
        viewModelScope.launch {
            chatRepo.clearHistory()
            chatRepo.saveEncryptedMessage(
                sender = MessageSender.CLONE,
                plainText = "Memoria di dialogo azzerata e bonificata crittograficamente. Sono pronto per una nuova conversazione protetta!",
                modelName = cloneEngine.currentModel
            )
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorNotice = null)
    }
}
