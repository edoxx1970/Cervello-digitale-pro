package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.data.model.BrainLobe
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.VioletNeon
import kotlin.math.cos
import kotlin.math.sin

data class NeuralNode(
    val lobe: BrainLobe,
    val relativeX: Float,
    val relativeY: Float,
    val radiusDp: Float,
    val count: Int
)

@Composable
fun NeuralSynapseCanvas(
    selectedLobe: BrainLobe?,
    lobeCounts: Map<BrainLobe, Int>,
    onLobeSelected: (BrainLobe) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "synapse_anim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    // Node layout positions across canvas
    val nodes = remember {
        listOf(
            NeuralNode(BrainLobe.FRONTAL, 0.50f, 0.22f, 26f, 0),
            NeuralNode(BrainLobe.TEMPORAL, 0.22f, 0.52f, 24f, 0),
            NeuralNode(BrainLobe.PARIETAL, 0.78f, 0.52f, 24f, 0),
            NeuralNode(BrainLobe.OCCIPITAL, 0.34f, 0.82f, 22f, 0),
            NeuralNode(BrainLobe.NEURAL_VAULT, 0.66f, 0.82f, 22f, 0)
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val w = size.width
                        val h = size.height
                        // Check which node was tapped
                        nodes.forEach { node ->
                            val cx = node.relativeX * w
                            val cy = node.relativeY * h
                            val dist = (offset.x - cx) * (offset.x - cx) + (offset.y - cy) * (offset.y - cy)
                            if (dist < 45.dp.toPx() * 45.dp.toPx()) {
                                onLobeSelected(node.lobe)
                            }
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Calculate actual points
            val points = nodes.map { node ->
                Offset(node.relativeX * w, node.relativeY * h)
            }

            // Draw Central Neural Core Halo
            val center = Offset(w * 0.5f, h * 0.5f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyanNeon.copy(alpha = 0.15f * pulse),
                        VioletNeon.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = w * 0.45f
                ),
                center = center,
                radius = w * 0.45f
            )

            // Draw Synaptic Connecting Lines between lobes
            val connections = listOf(
                Pair(0, 1), Pair(0, 2), Pair(1, 2),
                Pair(1, 3), Pair(2, 4), Pair(3, 4),
                Pair(0, 3), Pair(0, 4)
            )

            for ((i1, i2) in connections) {
                val p1 = points[i1]
                val p2 = points[i2]
                val isHighlighted = selectedLobe == null || 
                    selectedLobe == nodes[i1].lobe || 
                    selectedLobe == nodes[i2].lobe

                val alpha = if (isHighlighted) 0.55f else 0.15f
                val strokeW = if (isHighlighted) 2.5f.dp.toPx() else 1.2f.dp.toPx()

                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            nodes[i1].lobe.color.copy(alpha = alpha),
                            nodes[i2].lobe.color.copy(alpha = alpha)
                        ),
                        start = p1,
                        end = p2
                    ),
                    start = p1,
                    end = p2,
                    strokeWidth = strokeW,
                    cap = StrokeCap.Round
                )

                // Draw moving impulse electrical spark
                val progress = (sin(wavePhase + (i1 + i2)) + 1f) / 2f
                val sparkX = p1.x + (p2.x - p1.x) * progress
                val sparkY = p1.y + (p2.y - p1.y) * progress
                drawCircle(
                    color = Color.White.copy(alpha = if (isHighlighted) 0.9f else 0.3f),
                    radius = 3.5f.dp.toPx(),
                    center = Offset(sparkX, sparkY)
                )
            }

            // Draw Synaptic Nodes
            nodes.forEachIndexed { index, node ->
                val p = points[index]
                val isSelected = selectedLobe == node.lobe
                val nodeColor = node.lobe.color
                val baseRadius = node.radiusDp.dp.toPx() * (if (isSelected) 1.2f else 1.0f) * pulse

                // Outer Glowing Aura
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            nodeColor.copy(alpha = if (isSelected) 0.45f else 0.25f),
                            nodeColor.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = p,
                        radius = baseRadius * 1.8f
                    ),
                    center = p,
                    radius = baseRadius * 1.8f
                )

                // Node Base Circle
                drawCircle(
                    color = Color(0xFF101622),
                    radius = baseRadius,
                    center = p
                )

                // Node Border
                drawCircle(
                    color = if (isSelected) Color.White else nodeColor,
                    radius = baseRadius,
                    center = p,
                    style = Stroke(width = if (isSelected) 3.5f.dp.toPx() else 2.dp.toPx())
                )

                // Inner core energy dot
                drawCircle(
                    color = nodeColor,
                    radius = baseRadius * 0.45f,
                    center = p
                )
            }
        }
    }
}
