package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = Color(0xFF002029),
    primaryContainer = Color(0xFF003644),
    onPrimaryContainer = Color(0xFF99F0FF),
    
    secondary = VioletNeon,
    onSecondary = Color(0xFF2A0054),
    secondaryContainer = Color(0xFF450D7A),
    onSecondaryContainer = Color(0xFFE9D5FF),
    
    tertiary = AmberNeon,
    onTertiary = Color(0xFF3E2000),
    tertiaryContainer = Color(0xFF683800),
    onTertiaryContainer = Color(0xFFFFDDB8),
    
    background = BackgroundDark,
    onBackground = TextPrimary,
    
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    
    outline = SurfaceCardBorder,
    outlineVariant = Color(0xFF334155),
    
    error = PinkVault,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme(
    // We maintain a sleek premium high-contrast dark theme by default for the cybernetic digital brain
    primary = CyanNeon,
    onPrimary = Color(0xFF002029),
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep cohesive cyber-neural aesthetic
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
