package com.example.crypto

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class EncryptedPhotoStorage(
    private val context: Context,
    private val cryptoPrefs: CryptoPreferences
) {
    private val storageDir: File
        get() {
            val dir = File(context.filesDir, "encrypted_synapses")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    private val masterKey: String
        get() = cryptoPrefs.masterPinHash.ifEmpty { "neural_synapse_e2ee_master_key_2026" }

    // Deriva la chiave AES una sola volta (PBKDF2 è volutamente costoso) e la
    // riusa per tutte le foto della sessione, invece di rifare la derivazione
    // ad ogni singolo scatto/apertura come accadeva prima.
    private val cachedPhotoKey: javax.crypto.SecretKey by lazy {
        val salt = android.util.Base64.decode(cryptoPrefs.systemDataKeySaltBase64, android.util.Base64.NO_WRAP)
        CryptoEngine.deriveKey(masterKey, salt)
    }

    /**
     * Encrypts and saves raw photo bytes (from CameraX) to a private encrypted file.
     * Returns the relative internal path/identifier (e.g. "enc_photo_12345.enc")
     */
    suspend fun saveEncryptedPhoto(
        photoBytes: ByteArray,
        rotationDegrees: Int = 0
    ): String = withContext(Dispatchers.IO) {
        // Adjust rotation if needed
        val processedBytes = if (rotationDegrees != 0) {
            val bitmap = BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.size)
            if (bitmap != null) {
                val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
                val rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                val stream = ByteArrayOutputStream()
                rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
                stream.toByteArray()
            } else {
                photoBytes
            }
        } else {
            photoBytes
        }

        val encryptedBytes = CryptoEngine.encryptBytesWithKey(processedBytes, cachedPhotoKey)
        val fileName = "synapse_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.enc"
        val destFile = File(storageDir, fileName)

        FileOutputStream(destFile).use { out ->
            out.write(encryptedBytes)
            out.flush()
        }

        "enc_synapse://$fileName"
    }

    /**
     * Decrypts an encrypted photo identified by "enc_synapse://filename" and returns the Bitmap.
     */
    suspend fun loadDecryptedBitmap(photoUri: String): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val fileName = photoUri.removePrefix("enc_synapse://")
            val file = File(storageDir, fileName)
            if (!file.exists()) return@withContext null

            val encryptedBytes = file.readBytes()
            // Prova prima il formato veloce (chiave in cache, niente PBKDF2 ripetuto).
            // Se il file è stato salvato PRIMA di questo aggiornamento (formato
            // legacy con salt+iv+ciphertext), ricade sul metodo precedente così le
            // foto già scattate restano leggibili invece di andare perse.
            val fastResult = CryptoEngine.decryptBytesWithKey(encryptedBytes, cachedPhotoKey)
            val result = if (fastResult.isSuccess) fastResult else CryptoEngine.decryptBytes(encryptedBytes, masterKey)

            if (result.isSuccess) {
                val decryptedBytes = result.getOrNull() ?: return@withContext null
                BitmapFactory.decodeByteArray(decryptedBytes, 0, decryptedBytes.size)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Deletes the encrypted photo file when a memory is deleted.
     */
    suspend fun deletePhoto(photoUri: String) = withContext(Dispatchers.IO) {
        try {
            if (photoUri.startsWith("enc_synapse://")) {
                val fileName = photoUri.removePrefix("enc_synapse://")
                val file = File(storageDir, fileName)
                if (file.exists()) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
