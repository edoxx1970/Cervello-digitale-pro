package com.example.audio

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class SpeechState {
    IDLE,
    INITIALIZING,
    LISTENING,
    PROCESSING,
    ERROR
}

class SpeechToTextManager(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _speechState = MutableStateFlow(SpeechState.IDLE)
    val speechState: StateFlow<SpeechState> = _speechState.asStateFlow()

    private val _transcribedText = MutableStateFlow("")
    val transcribedText: StateFlow<String> = _transcribedText.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _audioRmsDb = MutableStateFlow(0f)
    val audioRmsDb: StateFlow<Float> = _audioRmsDb.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    var selectedLanguage: String = "it-IT"

    fun hasRecordPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun startListening(initialPrefix: String = "") {
        _errorMessage.value = null
        _partialText.value = ""
        if (initialPrefix.isNotBlank()) {
            _transcribedText.value = initialPrefix
        }

        if (!hasRecordPermission()) {
            _speechState.value = SpeechState.ERROR
            _errorMessage.value = "Permesso microfono non concesso"
            return
        }

        destroyRecognizer()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(createRecognitionListener(initialPrefix))
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLanguage)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLanguage)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, selectedLanguage)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }

            _speechState.value = SpeechState.LISTENING
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _speechState.value = SpeechState.ERROR
            _errorMessage.value = e.localizedMessage ?: "Errore nell'avvio del riconoscimento vocale"
        }
    }

    fun stopListening() {
        try {
            _speechState.value = SpeechState.PROCESSING
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            _speechState.value = SpeechState.IDLE
        }
    }

    fun cancelListening() {
        try {
            speechRecognizer?.cancel()
        } catch (ignored: Exception) {
        }
        _speechState.value = SpeechState.IDLE
        _audioRmsDb.value = 0f
        _partialText.value = ""
    }

    fun resetTranscript() {
        _transcribedText.value = ""
        _partialText.value = ""
        _errorMessage.value = null
        _audioRmsDb.value = 0f
        _speechState.value = SpeechState.IDLE
    }

    fun appendText(text: String) {
        _transcribedText.value = text
    }

    fun destroyRecognizer() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (ignored: Exception) {
        } finally {
            speechRecognizer = null
        }
    }

    private fun createRecognitionListener(initialPrefix: String): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _speechState.value = SpeechState.LISTENING
            }

            override fun onBeginningOfSpeech() {
                _speechState.value = SpeechState.LISTENING
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Normalize dB from ~ -2dB..12dB into 0f..1f range
                val normalized = ((rmsdB + 2f) / 14f).coerceIn(0f, 1f)
                _audioRmsDb.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _speechState.value = SpeechState.PROCESSING
                _audioRmsDb.value = 0f
            }

            override fun onError(errorCode: Int) {
                _audioRmsDb.value = 0f
                val message = when (errorCode) {
                    SpeechRecognizer.ERROR_AUDIO -> "Errore audio durante la registrazione"
                    SpeechRecognizer.ERROR_CLIENT -> "Errore client interno"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permessi microfono mancanti"
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Problema di connessione per la trascrizione"
                    SpeechRecognizer.ERROR_NO_MATCH -> "Nessuna parola rilevata. Parla vicino al microfono."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Servizio vocale occupato. Riprova."
                    SpeechRecognizer.ERROR_SERVER -> "Errore del server di trascrizione"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nessun audio rilevato (timeout)."
                    else -> "Errore di riconoscimento vocale ($errorCode)"
                }
                _speechState.value = SpeechState.ERROR
                _errorMessage.value = message
            }

            override fun onResults(results: Bundle?) {
                _audioRmsDb.value = 0f
                _speechState.value = SpeechState.IDLE
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val recognized = matches[0]
                    val existing = if (initialPrefix.isNotBlank()) "$initialPrefix " else ""
                    val updated = (existing + recognized).trim()
                    _transcribedText.value = updated
                    _partialText.value = ""
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    _partialText.value = matches[0]
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
